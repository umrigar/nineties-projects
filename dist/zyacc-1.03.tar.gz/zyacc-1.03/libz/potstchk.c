/*

File:	 potstchk.c
Purpose: Check tables for parseopt test.

Copyright (C) 1995, 1997 Zerksis D. Umrigar

See the file LICENSE for copying and distribution conditions.
THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.

*/

static long rangeSpec[]= { 0, -2, 5 };
static long primeSpec[]= { 6, 2, 3, 5, 7, 11 };
static ConstString nameSpec[]= { "mary", "marge", "marty", NULL };

