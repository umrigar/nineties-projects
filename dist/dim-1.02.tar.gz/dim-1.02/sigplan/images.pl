# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate images original text with physical files.

$key = q/{_inline}$ldots${_inline}/;
$cached_env_img{$key} = ' <IMG WIDTH=18 HEIGHT=2 ALIGN=BOTTOM ALT="tex2html_wrap_inline290" SRC="img2.gif"  > '; 
$key = q/{figure}footnotesize<verbatim_mark>verbatim4labelFig:Dec{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=300 HEIGHT=437 ALIGN=BOTTOM ALT="figure87" SRC="img1.gif"  > '; 
$key = q/{figure}footnotesize<verbatim_mark>verbatim5labelFig:Code{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=371 HEIGHT=593 ALIGN=BOTTOM ALT="figure124" SRC="img3.gif"  > '; 

1;

