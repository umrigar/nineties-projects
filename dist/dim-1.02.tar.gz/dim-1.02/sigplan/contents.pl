# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate contents original text with physical files.

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '0%:%sigplan.html%:%Fully Static Dimensional Analysis with C++ ' unless ($toc_section_info{$key}); 
$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node1.html%:%Introduction' unless ($toc_section_info{$key}); 
$key = q/0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node10.html%:%  About this document ... ' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node2.html%:%The Basic Idea' unless ($toc_section_info{$key}); 
$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node3.html%:%But is it ?' unless ($toc_section_info{$key}); 
$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node4.html%:%An Example' unless ($toc_section_info{$key}); 
$key = q/0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node5.html%:%Analysis of the Method' unless ($toc_section_info{$key}); 
$key = q/0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node6.html%:%Conclusions' unless ($toc_section_info{$key}); 
$key = q/0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node7.html%:%Note%:%<tex2html_star_mark>' unless ($toc_section_info{$key}); 
$key = q/0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node8.html%:%Acknowledgments%:%<tex2html_star_mark>' unless ($toc_section_info{$key}); 
$key = q/0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node9.html%:%References' unless ($toc_section_info{$key}); 

1;

