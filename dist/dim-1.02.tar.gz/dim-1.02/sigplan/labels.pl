# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate labels original text with physical files.

$key = q/FigCode/;
$external_labels{$key} = 'node4.html'; 
$key = q/FigDec/;
$external_labels{$key} = 'node4.html'; 
$key = q/SecBasic/;
$external_labels{$key} = 'node2.html'; 
$key = q/SecExample/;
$external_labels{$key} = 'node4.html'; 

1;

