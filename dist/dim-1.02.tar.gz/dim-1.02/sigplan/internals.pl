# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate internals original text with physical files.

$key = q/FigCode/;
$ref_files{$key} = 'node4.html'; 
$key = q/FigDec/;
$ref_files{$key} = 'node4.html'; 
$key = q/SecBasic/;
$ref_files{$key} = 'node2.html'; 
$key = q/SecExample/;
$ref_files{$key} = 'node4.html'; 

1;

