typedef int T;

int f() {
  T (*b);
  f (*b);
}

typedef signed int t;
typedef int plain;
struct tag {
  unsigned t: 4;
  const t: 5;
  plain r: 5;
};
struct tag x;
void g() {
  auto t i= 3;
  int t;
  t= 4;
  x.t= 4;
}
