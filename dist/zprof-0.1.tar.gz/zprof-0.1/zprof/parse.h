/* Automatically generated from parse.y by zyacc version 1.03. */
#ifndef _YY_DEFS_H
#define _YY_DEFS_H

typedef union {
  struct {
    TokSem t;
  } tok;
} YYSTYPE;

extern YYSTYPE yylval;
#define AUTO_TOK 257
#define BREAK_TOK 258
#define CASE_TOK 259
#define CHAR_TOK 260
#define CONST_TOK 261
#define CONTINUE_TOK 262
#define DEFAULT_TOK 263
#define DO_TOK 264
#define DOUBLE_TOK 265
#define ELSE_TOK 266
#define ENUM_TOK 267
#define EXTERN_TOK 268
#define FLOAT_TOK 269
#define FOR_TOK 270
#define GOTO_TOK 271
#define IF_TOK 272
#define INT_TOK 273
#define LONG_TOK 274
#define REGISTER_TOK 275
#define RETURN_TOK 276
#define SHORT_TOK 277
#define SIGNED_TOK 278
#define SIZEOF_TOK 279
#define STATIC_TOK 280
#define STRUCT_TOK 281
#define SWITCH_TOK 282
#define TYPEDEF_TOK 283
#define UNION_TOK 284
#define UNSIGNED_TOK 285
#define VOID_TOK 286
#define VOLATILE_TOK 287
#define WHILE_TOK 288
#define ADD_ASSGN_TOK 289
#define AND_ASSGN_TOK 290
#define BOOL_AND_TOK 291
#define BOOL_OR_TOK 292
#define DEC_TOK 293
#define DEREF_TOK 294
#define DIV_ASSGN_TOK 295
#define DOT_DOT_TOK 296
#define EQ_TOK 297
#define GE_TOK 298
#define INC_TOK 299
#define LE_TOK 300
#define LSH_ASSGN_TOK 301
#define LSH_TOK 302
#define MOD_ASSGN_TOK 303
#define MULT_ASSGN_TOK 304
#define NE_TOK 305
#define OR_ASSGN_TOK 306
#define RSH_ASSGN_TOK 307
#define RSH_TOK 308
#define SUB_ASSGN_TOK 309
#define XOR_ASSGN_TOK 310
#define ID_TOK 311
#define NUM_TOK 312
#define STRING_TOK 313
#endif /* ifndef _YY_DEFS_H */
