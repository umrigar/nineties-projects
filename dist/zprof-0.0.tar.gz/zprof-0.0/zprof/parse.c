/* Automatically generated from parse.y by zyacc version 1.02
 * using the command:
 * zyacc -d -v -o parse.c parse.y 
 */
/*

File:	 zlexskl.c
Purpose: Skeleton for zyacc parser generator.

Copyright (C) 1995 Zerksis D. Umrigar

See the file LICENSE for copying and distribution conditions.
THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.

*/
#define ZYACC

#ifdef DEBUG_ZYACC 	/* Define to check run-time assertions. */
#undef NDEBUG
#endif

#include <assert.h>

/*			 EXTERNAL LIBRARY ROUTINES.			*/

#if __STDC__
#include <limits.h>
#include <stdlib.h>	/* for malloc() and friends. */
#define YY_VOIDP void *
#define YY_VOID void
#define YY_CONST const
#define YY_PROTO 1
#else  /* ! __STDC__ */
#define YY_VOIDP char *
#define YY_VOID
#define YY_CONST
#define YY_PROTO 0
#if 0 
/* It is safest to not declare these here.  Most compilers should do the
 * right thing after producing warnings about missing declarations.
 */
char *malloc(unsigned);
YY_VOID free(char *);
char *realloc(char *, unsigned);
#endif /* if 0 */
#endif /* #if __STDC__ */


typedef unsigned char	YYUChar;
typedef unsigned short	YYUShrt;
typedef unsigned int	YYUInt;
typedef unsigned long	YYULong;


/* Define max. value YY_CHAR_BIT if YY_CHAR_BIT undef. */
#ifndef YY_CHAR_BIT
#ifdef CHAR_BIT	
#define YY_CHAR_BIT CHAR_BIT		/* From <limits.h> */
#else
#define YY_CHAR_BIT 8		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_UCHAR_MAX if YY_UCHAR_MAX undef. */
#ifndef YY_UCHAR_MAX
#ifdef UCHAR_MAX	
#define YY_UCHAR_MAX UCHAR_MAX		/* From <limits.h> */
#else
#define YY_UCHAR_MAX 255		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_USHRT_MAX if YY_USHRT_MAX undef. */
#ifndef YY_USHRT_MAX
#ifdef USHRT_MAX	
#define YY_USHRT_MAX USHRT_MAX		/* From <limits.h> */
#else
#define YY_USHRT_MAX 65535		/* A "reasonable" value. */
#endif
#endif



/* 			PARSER PARAMETERS.			*/

/* 

Define following parameters:

YY_HAS_IN_ATTRIBS:	1 if parser uses %in attributes.
YY_BAD_TOK:		Used to indicate an invalid token.
YY_EMPTY_TOK:		Used to indicate no lookahead.
YY_ERR_TOK_VAL:		Value associated with error token.
YY_HAS_MULTI_START:	1 if we have multiple %start non-terminals.
YY_N_TESTS:		# of semantic %tests used by gramar.
YY_MAX_TOK_VAL:		Maximum (user or automatically assigned) token value.
YY_MAX_RULE_LEN:	Maximum length of a rule.
YY_N_NON_TERMS:		# of non-terminal symbols (including start-symbol).
YY_N_RHS:		# of elements on RHS of all rules.
YY_N_RULES:		# of rules (including accept & error pseudo-rule).
			  Doesn't include %test pseudo-reductions.
YY_N_TOKS:		# of tokens (active & inactive) 
                        Including YYEMPTY & YY_BAD_TOK.
YY_BAD_BASE:		If used in base array, then use default entry.
YY_N_CHECK:		# of entries in yyCheck[] vector.
YY_N_NEXT:		# of entries in yyNext[] vector.
YY_N_STATES:		# of states.
YY_TESTS_SIZE:		# of entries in yyTests[].
YY_CMD_LINE_DEBUG:	1 if debugging requested via cmd-line; 0 if not.
YY_PREFIX		Prefix for external names (default yy).
YY_HAS_LOC:		1 if @n construct used; 0 otherwise.
YY_IS_PURE:		1 if %pure_parser requested; 0 otherwise.
YY_IS_TYPED:		1 if <type> used.
*/

#define YY_HAS_IN_ATTRIBS 1
#define YY_BAD_TOK 83
#define YY_EMPTY_TOK 84
#define YY_ERR_TOK_VAL 256
#define YY_HAS_MULTI_START 0
#define YY_N_TESTS 2
#define YY_MAX_TOK_VAL 315
#define YY_MAX_RULE_LEN 9
#define YY_N_NON_TERMS 158
#define YY_N_RHS 922
#define YY_N_RULES 315
#define YY_N_TOKS 85
#define YY_BAD_BASE 7
#define YY_N_CHECK 3572
#define YY_N_NEXT 3555
#define YY_N_STATES 477
#define YY_TESTS_SIZE 18
#define YY_CMD_LINE_DEBUG 0
#define YY_PREFIX yy
#define YY_IS_PURE 0
#define YY_HAS_LOC 0
#define YY_IS_TYPED 1
#define YY_ZYACC_MAJOR_VERSION 1
#define YY_ZYACC_MINOR_VERSION 02
#line 145 "parse.c"

/*                          TOKEN DEFINITIONS.                          */

#define AUTO_TOK 257
#define BREAK_TOK 258
#define CASE_TOK 259
#define CHAR_TOK 260
#define CONST_TOK 261
#define CONTINUE_TOK 262
#define DEFAULT_TOK 263
#define DO_TOK 264
#define DOUBLE_TOK 265
#define ELSE_TOK 266
#define ENUM_TOK 267
#define EXTERN_TOK 268
#define FLOAT_TOK 269
#define FOR_TOK 270
#define GOTO_TOK 271
#define IF_TOK 272
#define INT_TOK 273
#define LONG_TOK 274
#define REGISTER_TOK 275
#define RETURN_TOK 276
#define SHORT_TOK 277
#define SIGNED_TOK 278
#define SIZEOF_TOK 279
#define STATIC_TOK 280
#define STRUCT_TOK 281
#define SWITCH_TOK 282
#define TYPEDEF_TOK 283
#define UNION_TOK 284
#define UNSIGNED_TOK 285
#define VOID_TOK 286
#define VOLATILE_TOK 287
#define WHILE_TOK 288
#define ADD_ASSGN_TOK 289
#define AND_ASSGN_TOK 290
#define BOOL_AND_TOK 291
#define BOOL_OR_TOK 292
#define DEC_TOK 293
#define DEREF_TOK 294
#define DIV_ASSGN_TOK 295
#define DOT_DOT_TOK 296
#define EQ_TOK 297
#define GE_TOK 298
#define INC_TOK 299
#define LE_TOK 300
#define LSH_ASSGN_TOK 301
#define LSH_TOK 302
#define MOD_ASSGN_TOK 303
#define MULT_ASSGN_TOK 304
#define NE_TOK 305
#define OR_ASSGN_TOK 306
#define RSH_ASSGN_TOK 307
#define RSH_TOK 308
#define SUB_ASSGN_TOK 309
#define XOR_ASSGN_TOK 310
#define ID_TOK 311
#define NUM_TOK 312
#define STRING_TOK 313
#line 206 "parse.c"

/*	USER DEFINITIONS FROM SECTION 1 OF YACC FILE.			*/

#line 15 "parse.y"


#include "options.h"
#include "out.h"
#include "scan.h"

#include "area.h"
#include "error.h"
#include "ids.h"
#include "parseopt.h"

#define YY_LEX scan

static void dclTypedef PROTO((Index id, Boolean isTypedef));
static Boolean isTypedef PROTO((VOID_ARGS));
static Index beginScope PROTO((VOID_ARGS));
static VOID endScope PROTO((Index scope));
static Int helpOptFn 
  PROTO((Int id, VOIDP checkP, VOIDP valP, ConstString argP));
static Int typedefOptFn 
  PROTO((Int id, VOIDP checkP, VOIDP valP, ConstString argP));
static Int versionOptFn 
  PROTO((Int id, VOIDP checkP, VOIDP valP, ConstString argP));


static struct {
  Boolean seenType;
} globs;
#define G globs

#define OUT(t)		putOut(&t)

enum {
  TYPEDEF_DCL,		/* declaration of a typedef */
  ID_DCL,		/* declaration of other ID in typedef namespace */
  OTHER_DCL,		/* declaration of other ID in other namespace */
};


#line 250 "parse.c"

/*                      SEMANTIC TYPE DEFINITION YYSTYPE.               */

typedef union {
  struct {
    TokSem t;
  } tok;
  struct {
    CounterType counterZ;
  } yy_compound_statement;
  struct {
    Index dclType;
  } yy_declaration_specifiers;
  struct {
    Index dclType;
  } yy_declaration_specifiers_x;
  struct {
    Index dclType;
  } yy_storage_class_specifier;
  struct {
    Index id;
  } yy_ID;
  struct {
    CounterType counterZ;
  } yy_statement;
  struct {
    CounterType counterZ;
  } yy_labeled_statement;
  struct {
    CounterType counterZ;
  } yy_selection_statement;
  struct {
    CounterType counterZ;
  } yy_iteration_statement;
  struct {
    Index scope;
  } yy_lbrace;
  struct {
    CounterType counterZ;
  } yy_statement_list;
  struct {
    CounterType counterZ;
  } yy_needs_counter_statement;
} YYSTYPE;

typedef struct {
  union {
    /* compound_statement.counter0 */
    CounterType yyT_0;
  } yyC_0;
  union {
    /* declarator.dclType */
    Index yyT_1;
    /* statement.counter0 statement_list.counter0 counter_end.counter0 
     * counter_begin.counter0 
     */
    CounterType yyT_0;
  } yyC_1;
  union {
    /* init_declarator_list.dclType rbrace.scope 
     * direct_declarator.dclType init_declarator.dclType 
     */
    Index yyT_1;
  } yyC_2;
} YYIn;
#line 316 "parse.c"

/*           DEFINE TYPES WHICH DEPEND ON PARSER PARAMETERS.            */


/* typedef YYLen to represent values in 0, ..., YY_MAX_RULE_LEN. */
#if (YY_MAX_RULE_LEN <= YY_UCHAR_MAX)
typedef YYUChar YYLen;
#elif (YY_MAX_RULE_LEN <= YY_USHRT_MAX)
typedef YYUShrt YYLen;
#else
  #error Type YYLen cannot be represented.
#endif


/* typedef YYNonTerm to represent values in 0, ..., (YY_N_NON_TERMS - 1). */
#if ((YY_N_NON_TERMS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYNonTerm;
#elif ((YY_N_NON_TERMS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYNonTerm;
#else
  #error Type YYNonTerm cannot be represented.
#endif


/* typedef YYRHS to represent values in 0, ..., (YY_N_RHS - 1). */
#if ((YY_N_RHS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRHS;
#elif ((YY_N_RHS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRHS;
#else
  #error Type YYRHS cannot be represented.
#endif


/* typedef YYRuleN to represent values in 0, ..., (YY_N_RULES - 1). */
#if ((YY_N_RULES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRuleN;
#elif ((YY_N_RULES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRuleN;
#else
  #error Type YYRuleN cannot be represented.
#endif


/* typedef YYState to represent values in 0, ..., (YY_N_STATES - 1). */
#if ((YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYState;
#elif ((YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYState;
#else
  #error Type YYState cannot be represented.
#endif


/* typedef YYCheck to represent values in 0, ..., ((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS). */
#if (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_UCHAR_MAX)
typedef YYUChar YYCheck;
#elif (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_USHRT_MAX)
typedef YYUShrt YYCheck;
#else
  #error Type YYCheck cannot be represented.
#endif


/* typedef YYTok to represent values in 0, ..., (YY_N_TOKS - 1). */
#if ((YY_N_TOKS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTok;
#elif ((YY_N_TOKS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTok;
#else
  #error Type YYTok cannot be represented.
#endif


/* typedef YYBase to represent values in 0, ..., (YY_N_NEXT - 1). */
#if ((YY_N_NEXT - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYBase;
#elif ((YY_N_NEXT - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYBase;
#else
  #error Type YYBase cannot be represented.
#endif


/* typedef YYTest to represent values in 0, ..., (YY_N_TESTS - 1). */
#if ((YY_N_TESTS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTest;
#elif ((YY_N_TESTS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTest;
#else
  #error Type YYTest cannot be represented.
#endif


/* typedef YYAct to represent values in 0, ..., (YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1). */
#if ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYAct;
#elif ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYAct;
#else
  #error Type YYAct cannot be represented.
#endif


/* Combine YY_CMD_LINE_DEBUG and YYDEBUG into YYDEBUG. */
#if YY_CMD_LINE_DEBUG == 1
#undef YYDEBUG
#define YYDEBUG 1
#endif

#if YYDEBUG

#include <stdio.h>

typedef enum {
  YY_TOKEN_SYM= 0,		/* A token symbol. */
  YY_NON_TERM_SYM= 1,		/* A non-terminal symbol. */
  YY_RULE_SYM= 2		/* Rule symbol --- used only rule end. */
} YYSymType;

#define YY_SYM_TYPE_BIT 2	/* Min. # of bits for YYSymType. */

#define YY_SYM_TYPE(sym)						\
  ((YYSymType) ((sym) & ((1L << YY_SYM_TYPE_BIT) - 1)))
#define YY_SYM_NUM(sym)		((sym) >> YY_SYM_TYPE_BIT)
#define YY_MAKE_SYM(symType, symNum)	 				\
  ((((symNum) << YY_SYM_TYPE_BIT)) | (symType))

#define YY_MAX_SYM \
((( /* max(YY_N_NON_TERMS, YY_N_TOKS, YY_N_RULES) */ \
    (YY_N_NON_TERMS > YY_N_TOKS \
     ? (YY_N_NON_TERMS > YY_N_RULES ? YY_N_NON_TERMS : YY_N_RULES) \
     : (YY_N_TOKS > YY_N_RULES ? YY_N_TOKS : YY_N_RULES)) \
   - 1) \
  << YY_SYM_TYPE_BIT) \
 | ((1 << YY_SYM_TYPE_BIT) - 1))



/* typedef YYSym to represent values in 0, ..., YY_MAX_SYM. */
#if (YY_MAX_SYM <= YY_UCHAR_MAX)
typedef YYUChar YYSym;
#elif (YY_MAX_SYM <= YY_USHRT_MAX)
typedef YYUShrt YYSym;
#else
  #error Type YYSym cannot be represented.
#endif


#endif /* ifdef YYDEBUG */

/* 		NAMES FOR EXTERN PARSER OBJECTS.			*/
/* Default names provided, if macros not defined in section 1. 		*/

#ifndef YY_CHAR
#define YY_CHAR yychar
#endif

#ifndef YY_DEBUG
#define YY_DEBUG yydebug
#endif

#ifndef YY_ERROR
#define YY_ERROR yyerror
#endif

#ifndef YY_LEX
#define YY_LEX yylex
#endif

#ifndef YY_LVAL
#define YY_LVAL yylval
#endif

#ifndef YY_NERRS
#define YY_NERRS yynerrs
#endif

#ifndef YY_PARSE
#define YY_PARSE yyparse
#endif

#line 499 "parse.c"


/*                           GRAMMAR TABLES.                            */

/*

#if YYDEBUG					#Grammar info. for debugging.

static char *yyTokenNames[YY_N_TOKS];		#Token names. 
static char *yyNonTermNames[YY_N_NONTERMS];	#NonTerminal names.
static YYRHS yyRule[YY_N_RULES];		#Start of each rule in yySyms.
static YYSym yySyms[YY_N_RHS];			#Rule right-hand sides.
static YYSym yyAccess[YY_N_STATES]		#Access symbols for each state.

#endif

static YYTok yyTranslate[YY_MAX_TOK];		#Xlate ext. to internal tokens.

static YYLen yyLength[YY_N_RULES];		#Rule lengths.
static YYNonTerm yyLHS[YY_N_RULES];		#Rule LHS non-terminal numbers.

static YYBase yyActBase[YY_N_STATES];		#Base array for acts.
static YYRuleN yyActDef[YY_N_STATES];		#Default reduce rule.

static YYBase yyGotoBase[YY_N_NONTERMS];	#Base array for gotos.
static YYState yyGotoDef[YY_N_NONTERMS];	#Default state for gotos.

static YYAct yyNext[YY_N_NEXT];			#Action.
static YYCheck yyCheck[YY_N_CHECK];	 	#Action check array.



*/

#if YYDEBUG

static char *yyTokenNames[85]= {
  "error", "<EOF>", "'auto'", "'break'", 
  "'case'", "'char'", "'const'", "'continue'", 
  "'default'", "'do'", "'double'", "'else'", 
  "'enum'", "'extern'", "'float'", "'for'", 
  "'goto'", "'if'", "'int'", "'long'", 
  "'register'", "'return'", "'short'", "'signed'", 
  "'sizeof'", "'static'", "'struct'", "'switch'", 
  "'typedef'", "'union'", "'unsigned'", "'void'", 
  "'volatile'", "'while'", "'+='", "'&='", 
  "'&&'", "'||'", "'--'", "'->'", 
  "'/='", "'...'", "'=='", "'>='", 
  "'++'", "'<='", "'<<='", "'<<'", 
  "'%='", "'*='", "'!='", "'|='", 
  "'>>='", "'>>'", "'-='", "'^='", 
  "';'", "'{'", "'}'", "'['", 
  "']'", "'('", "')'", "','", 
  "':'", "'='", "'*'", "'?'", 
  "'|'", "'^'", "'&'", "'<'", 
  "'>'", "'+'", "'-'", "'/'", 
  "'%'", "'~'", "'!'", "'.'", 
  "ID_TOK", "NUM_TOK", "STRING_TOK", "$yyBadTok", 
  "$yyEmptyTok"
};
static char *yyNonTermNames[158]= {
  "$S", "translation_unit", "external_declaration", "function_definition", 
  "declaration", "fnDeclarator", "compound_statement", "declaration_list", 
  "declaration_specifiers", "declarator", "SEMI", "init_declarator_list", 
  "declaration_specifiers_x", "storage_class_specifier", "type_specifier", "type_qualifier", 
  "TYPEDEF", "EXTERN", "STATIC", "AUTO", 
  "REGISTER", "CHAR", "SHORT", "INT", 
  "LONG", "SIGNED", "UNSIGNED", "FLOAT", 
  "DOUBLE", "VOID", "struct_or_union_specifier", "enum_specifier", 
  "typedef_name", "CONST", "VOLATILE", "struct_or_union", 
  "ID", "LBRACE", "struct_declaration_list", "RBRACE", 
  "STRUCT", "UNION", "struct_declaration", "init_declarator", 
  "COMMA", "EQ", "initializer", "specifier_qualifier_list", 
  "struct_declarator_list", "specifier_qualifier_list_x", "struct_declarator", "fieldDeclarator", 
  "COLON", "constant_expr", "ENUM", "enumerator_list", 
  "enumerator", "direct_declarator", "pointer", "LPAREN", 
  "RPAREN", "LBRACKET", "RBRACKET", "parameter_type_list", 
  "identifier_list", "STAR", "type_qualifier_list", "parameter_list", 
  "DOT_DOT_DOT", "parameter_declaration", "abstract_declarator", "assignment_expr", 
  "initializer_list", "type_name", "direct_abstract_declarator", "YYTest_1", 
  "statement", "counter_begin", "labeled_statement", "counter_end", 
  "expression_statement", "selection_statement", "iteration_statement", "jump_statement", 
  "CASE", "DEFAULT", "expr", "lbrace", 
  "rbrace", "statement_list", "IF", "needs_counter_statement", 
  "ELSE", "SWITCH", "WHILE", "DO", 
  "FOR", "GOTO", "CONTINUE", "BREAK", 
  "RETURN", "conditional_expr", "unary_expr", "assignment_operator", 
  "STAR_EQ", "SLASH_EQ", "PERCENT_EQ", "PLUS_EQ", 
  "MINUS_EQ", "LT_LT_EQ", "GT_GT_EQ", "AMPERSAND_EQ", 
  "CARAT_EQ", "BAR_EQ", "logical_or_expr", "QUESTION", 
  "logical_and_expr", "BAR_BAR", "inclusive_or_expr", "AMPERSAND_AMPERSAND", 
  "exclusive_or_expr", "BAR", "and_expr", "CARAT", 
  "equality_expr", "AMPERSAND", "relational_expr", "EQ_EQ", 
  "BANG_EQ", "shift_expr", "LT", "GT", 
  "LT_EQ", "GT_EQ", "additive_expr", "LT_LT", 
  "GT_GT", "multiplicative_expr", "PLUS", "MINUS", 
  "cast_expr", "SLASH", "PERCENT", "postfix_expr", 
  "PLUS_PLUS", "MINUS_MINUS", "unary_operator", "SIZEOF", 
  "TILDE", "BANG", "primary_expr", "argument_expr_list", 
  "DOT", "MINUS_GT", "constant", "STRING", 
  "NUM", "$Err"
};
static YYRHS yyRule[315]= {
      0,     3,     5,     8,    10,    12,    14,    17,    21,    25, 
     30,    32,    35,    39,    41,    44,    46,    48,    51,    53, 
     56,    58,    61,    63,    65,    67,    69,    71,    73,    75, 
     77,    79,    81,    83,    85,    87,    89,    91,    93,    95, 
     97,    99,   105,   110,   113,   115,   117,   119,   122,   124, 
    128,   130,   134,   138,   140,   142,   145,   147,   150,   152, 
    156,   158,   161,   165,   167,   172,   178,   181,   183,   187, 
    189,   193,   195,   198,   200,   204,   208,   213,   218,   222, 
    227,   229,   232,   235,   239,   241,   244,   246,   250,   252, 
    256,   259,   261,   264,   266,   270,   272,   276,   281,   283, 
    287,   289,   292,   294,   296,   299,   303,   306,   310,   314, 
    319,   322,   326,   330,   335,   338,   339,   343,   347,   349, 
    353,   357,   361,   365,   370,   374,   376,   379,   383,   387, 
    391,   396,   398,   400,   402,   405,   411,   419,   425,   427, 
    433,   441,   448,   456,   464,   473,   481,   490,   499,   509, 
    513,   516,   519,   522,   526,   528,   532,   534,   536,   540, 
    542,   544,   546,   548,   550,   552,   554,   556,   558,   560, 
    562,   564,   574,   576,   578,   582,   584,   588,   590,   594, 
    596,   600,   602,   606,   608,   612,   616,   618,   622,   626, 
    630,   634,   636,   640,   644,   646,   650,   654,   656,   660, 
    664,   668,   670,   675,   677,   680,   683,   686,   689,   694, 
    696,   698,   700,   702,   704,   706,   708,   713,   717,   722, 
    726,   730,   733,   736,   738,   740,   742,   746,   748,   752, 
    754,   756,   758,   760,   762,   764,   766,   768,   770,   772, 
    774,   776,   778,   780,   782,   784,   786,   788,   790,   792, 
    794,   796,   798,   800,   802,   804,   806,   808,   810,   812, 
    814,   816,   818,   820,   822,   824,   826,   828,   830,   832, 
    834,   836,   838,   840,   842,   844,   846,   848,   850,   852, 
    854,   856,   858,   860,   862,   864,   866,   868,   870,   872, 
    874,   876,   878,   880,   882,   884,   886,   888,   890,   892, 
    894,   896,   898,   901,   903,   905,   907,   909,   911,   913, 
    915,   917,   919,   920,   921
};
static YYSym yySyms[922]= {
      5,     4,     2,     9,     6,     5,     9,    10,    13,    14, 
     17,    18,     0,    22,    21,    25,    26,    21,    29,    25, 
     30,    33,    37,    25,    34,    33,    37,    29,    25,    38, 
     37,    42,    33,    41,    46,    33,    45,    41,    50,    17, 
     54,    29,    17,    58,    49,    62,    53,    66,    53,    49, 
     70,    57,    74,    57,    49,    78,    61,    82,    61,    49, 
     86,    65,    90,    69,    94,    73,    98,    77,   102,    81, 
    106,    85,   110,    89,   114,    93,   118,    97,   122,   101, 
    126,   105,   130,   109,   134,   113,   138,   117,   142,   121, 
    146,   125,   150,   129,   154,   133,   158,   137,   162,   141, 
    145,   149,   153,   157,   166,   141,   149,   153,   157,   170, 
    141,   145,   174,   161,   178,   165,   182,   169,   186,   153, 
    169,   190,   173,   194,    45,   177,   173,   198,    37,   202, 
     37,   181,   185,   206,   189,   193,    41,   210,   197,   214, 
     57,   218,    57,   197,   222,    61,   226,    61,   197,   230, 
    201,   234,   193,   177,   201,   238,   205,   242,   209,   213, 
    246,   205,   209,   213,   250,    37,   254,   217,   149,   221, 
    157,   258,   217,   145,   149,   221,   157,   262,   217,   145, 
    266,   225,   270,   221,   177,   225,   274,   145,   278,   145, 
    181,   213,   282,   229,   286,   233,   229,   290,   145,   294, 
    237,    37,   241,   298,   229,   245,   249,   302,   229,   245, 
    213,   249,   306,   229,   237,   253,   241,   310,   229,   237, 
    241,   314,   229,   237,   257,   241,   318,   261,   322,   261, 
    265,   326,   261,   233,   330,   261,   265,   233,   334,    61, 
    338,   265,    61,   342,   269,   346,   269,   177,   273,   350, 
    277,   354,   269,   177,   277,   358,    33,    37,   362,    33, 
    366,    33,   281,   370,   145,   374,   257,   177,   145,   378, 
    285,   382,   149,   289,   157,   386,   149,   289,   177,   157, 
    390,   185,   394,   289,   177,   185,   398,   189,   402,   189, 
    281,   406,   233,   410,   297,   414,   233,   297,   418,   237, 
    281,   241,   422,   245,   249,   426,   245,   213,   249,   430, 
    297,   245,   249,   434,   297,   245,   213,   249,   438,   237, 
    241,   442,   237,   253,   241,   446,   297,   237,   241,   450, 
    297,   237,   253,   241,   454,   301,   145,   458,   462,   309, 
    313,   317,   466,   309,   321,   317,   470,    25,   474,   309, 
    325,   317,   478,   309,   329,   317,   482,   309,   333,   317, 
    486,   145,   209,   305,   490,   337,   213,   209,   305,   494, 
    341,   209,   305,   498,    41,   502,   345,    41,   506,   349, 
    309,   353,   510,   349,   357,   353,   514,   349,    29,   353, 
    518,   349,    29,   357,   353,   522,   149,   526,   157,   530, 
    305,   534,   357,   305,   538,   361,   237,   345,   241,   365, 
    542,   361,   237,   345,   241,   365,   369,   305,   546,   373, 
    237,   345,   241,   305,   550,   305,   554,   377,   237,   345, 
    241,   305,   558,   381,   305,   377,   237,   345,   241,    41, 
    562,   385,   237,    41,    41,   241,   305,   566,   385,   237, 
     41,    41,   345,   241,   305,   570,   385,   237,    41,   345, 
     41,   241,   305,   574,   385,   237,    41,   345,    41,   345, 
    241,   305,   578,   385,   237,   345,    41,    41,   241,   305, 
    582,   385,   237,   345,    41,    41,   345,   241,   305,   586, 
    385,   237,   345,    41,   345,    41,   241,   305,   590,   385, 
    237,   345,    41,   345,    41,   345,   241,   305,   594,   389, 
    145,    41,   598,   393,    41,   602,   397,    41,   606,   401, 
     41,   610,   401,   345,    41,   614,   285,   618,   345,   177, 
    285,   622,     0,   626,   405,   630,   409,   413,   285,   634, 
    181,   638,   417,   642,   421,   646,   425,   650,   429,   654, 
    433,   658,   437,   662,   441,   666,   445,   670,   449,   674, 
    453,   678,   457,   682,   457,   461,   309,   457,   317,   209, 
    309,   405,   317,   686,   405,   690,   465,   694,   457,   469, 
    465,   698,   473,   702,   465,   477,   473,   706,   481,   710, 
    473,   485,   481,   714,   489,   718,   481,   493,   489,   722, 
    497,   726,   489,   501,   497,   730,   505,   734,   497,   509, 
    505,   738,   497,   513,   505,   742,   517,   746,   505,   521, 
    517,   750,   505,   525,   517,   754,   505,   529,   517,   758, 
    505,   533,   517,   762,   537,   766,   517,   541,   537,   770, 
    517,   545,   537,   774,   549,   778,   537,   553,   549,   782, 
    537,   557,   549,   786,   561,   790,   549,   261,   561,   794, 
    549,   565,   561,   798,   549,   569,   561,   802,   409,   806, 
    237,   293,   241,   561,   810,   573,   814,   577,   409,   818, 
    581,   409,   822,   585,   561,   826,   589,   409,   830,   589, 
    237,   293,   241,   834,   501,   838,   261,   842,   553,   846, 
    557,   850,   593,   854,   597,   858,   601,   862,   573,   245, 
    345,   249,   866,   573,   237,   241,   870,   573,   237,   605, 
    241,   874,   573,   609,   145,   878,   573,   613,   145,   882, 
    573,   577,   886,   573,   581,   890,   145,   894,   617,   898, 
    621,   902,   237,   345,   241,   906,   285,   910,   605,   177, 
    285,   914,   625,   918,   280,   922,   144,   926,   140,   930, 
      8,   934,   312,   938,   200,   942,   272,   946,   148,   950, 
    204,   954,    12,   958,   276,   962,   220,   966,    16,   970, 
     20,   974,   256,   978,   252,   982,    24,   986,    28,   990, 
     32,   994,    36,   998,   316,  1002,   164,  1006,    40,  1010, 
     44,  1014,    48,  1018,   260,  1022,   168,  1026,    52,  1030, 
     56,  1034,    60,  1038,    64,  1042,   288,  1046,   172,  1050, 
    212,  1054,   208,  1058,   320,  1062,    68,  1066,    72,  1070, 
    228,  1074,   236,  1078,    76,  1082,   244,  1086,   284,  1090, 
    180,  1094,   188,  1098,   184,  1102,   296,  1106,   216,  1110, 
    156,  1114,   152,  1118,   324,  1122,   304,  1126,   192,  1130, 
    292,  1134,   136,  1138,   176,  1142,   268,  1146,   232,  1150, 
    240,  1154,    80,  1158,    84,  1162,   248,  1166,   224,  1170, 
     88,  1174,    92,  1178,    96,  1182,   300,  1186,   160,  1190, 
    264,  1194,   196,  1198,   100,  1202,   328,  1206,   621,   328, 
   1210,   104,  1214,   108,  1218,   308,  1222,   112,  1226,   116, 
   1230,   120,  1234,   124,  1238,   128,  1242,   132,  1246,  1250, 
   1254,  1258
};
static YYSym yyAccess[477]= {
      1,     0,   112,    52,   100,     8,    80,    20,    88,    72, 
     76,    92,   120,    56,    40,   124,    24,   128,   320,   104, 
    116,    48,   244,   264,     5,     9,    13,    17,    21,    33, 
     37,    49,   229,   233,    53,    57,    61,    65,    69,    73, 
     77,    81,    85,    89,    93,    97,   101,   105,   109,   113, 
    117,   121,   125,   129,   133,   137,   141,   217,   301,   161, 
    165,   145,   237,   261,     4,     9,   228,    25,    29,    33, 
    349,    17,   149,   224,    37,    41,    45,   173,   236,   245, 
    237,   229,    49,    49,    49,   145,   149,   149,   145,   145, 
     37,   265,   233,    61,    25,    17,    37,   309,   357,    29, 
     25,   305,   260,    25,    29,   181,   252,    41,   177,   240, 
    280,   292,   296,   176,   152,    96,   308,   312,   328,   324, 
    249,   213,   405,   457,   573,   577,   581,   585,   589,   465, 
    473,   481,   489,   497,   505,   517,   537,   549,   561,   409, 
    237,   601,   501,   261,   553,   557,   593,   597,   145,   617, 
    621,   625,   248,   253,   241,   257,   269,   145,   277,    33, 
    149,   153,   169,   189,   197,    57,    61,   221,   225,   145, 
    149,   241,   233,    61,   232,    16,    32,     0,    68,   108, 
    132,    36,    60,    64,    28,    12,    84,   353,   313,   321, 
    325,   329,   333,   405,   409,   145,   337,   341,    41,   345, 
    361,   373,   377,   381,   385,   389,   393,   397,   401,   285, 
    157,   353,   305,   309,   353,   357,    25,   185,   285,   149, 
    173,   249,   268,   148,   461,   469,   316,   156,   245,   237, 
    609,   613,   577,   581,   409,   237,   409,   561,   409,   237, 
    144,   477,   272,   485,   276,   493,   501,   168,   200,   509, 
    513,   284,   288,   180,   172,   521,   525,   529,   533,   188, 
    212,   541,   545,   553,   557,   300,   304,   261,   565,   569, 
    293,   345,   189,   328,   241,   241,   177,   177,    37,   281, 
    233,   237,   297,   245,   153,   157,   169,   256,   193,   201, 
    205,   209,    37,   197,   197,   157,   177,   181,   221,   317, 
    317,   317,   317,   317,   196,   160,   192,   136,   216,   184, 
    208,   140,   220,   204,   413,   181,   417,   421,   425,   429, 
    433,   437,   441,   445,   449,   453,   209,   213,   209,    41, 
    177,   237,   237,   237,   305,   237,   145,    41,    41,    41, 
    345,   353,   289,   185,   309,   465,   345,   241,   605,   285, 
    145,   145,   293,   473,   481,   489,   497,   505,   505,   517, 
    517,   517,   517,   537,   537,   549,   549,   561,   561,   561, 
    241,   241,   281,   233,   237,   145,   164,   273,   277,   297, 
    281,   241,   253,   245,   237,   249,   213,   157,    41,   177, 
    209,   213,   225,   213,   157,   285,   305,   209,   305,   285, 
    345,   345,   345,   377,    41,   345,    41,    41,   157,   177, 
    457,   249,   241,   177,   241,   561,   241,   241,   249,   213, 
    241,   253,   249,   201,   213,   305,   241,   241,   241,   237, 
     41,   345,    41,   157,   185,   317,   285,   249,   241,   365, 
    305,   305,   305,   345,   241,   345,    41,    41,   345,   209, 
     44,   369,   241,   305,   241,   241,   345,   241,   345,    41, 
    309,   305,    41,   305,   305,   241,   305,   241,   241,   345, 
    405,   305,   305,   305,   241,   317,   305
};
#endif /* #if YYDEBUG */

static YYTok yyTranslate[316]= {
      1,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    78,    83,    83,    83,    76,    70,    83, 
     61,    62,    66,    73,    63,    74,    79,    75,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    64,    56, 
     71,    65,    72,    67,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    59,    83,    60,    69,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    57,    68,    58,    77,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,    83,    83,    83,    83, 
     83,    83,    83,    83,    83,    83,     0,     2,     3,     4, 
      5,     6,     7,     8,     9,    10,    11,    12,    13,    14, 
     15,    16,    17,    18,    19,    20,    21,    22,    23,    24, 
     25,    26,    27,    28,    29,    30,    31,    32,    33,    34, 
     35,    36,    37,    38,    39,    40,    41,    42,    43,    44, 
     45,    46,    47,    48,    49,    50,    51,    52,    53,    54, 
     55,    80,    81,    82,    83,    84
};
static YYLen yyLength[315]= {
      2,     1,     2,     1,     1,     1,     2,     3,     3,     4, 
      1,     2,     3,     1,     2,     1,     1,     2,     1,     2, 
      1,     2,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     5,     4,     2,     1,     1,     1,     2,     1,     3, 
      1,     3,     3,     1,     1,     2,     1,     2,     1,     3, 
      1,     2,     3,     1,     4,     5,     2,     1,     3,     1, 
      3,     1,     2,     1,     3,     3,     4,     4,     3,     4, 
      1,     2,     2,     3,     1,     2,     1,     3,     1,     3, 
      2,     1,     2,     1,     3,     1,     3,     4,     1,     3, 
      1,     2,     1,     1,     2,     3,     2,     3,     3,     4, 
      2,     3,     3,     4,     2,     0,     3,     3,     1,     3, 
      3,     3,     3,     4,     3,     1,     2,     3,     3,     3, 
      4,     1,     1,     1,     2,     5,     7,     5,     1,     5, 
      7,     6,     7,     7,     8,     7,     8,     8,     9,     3, 
      2,     2,     2,     3,     1,     3,     1,     1,     3,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     9,     1,     1,     3,     1,     3,     1,     3,     1, 
      3,     1,     3,     1,     3,     3,     1,     3,     3,     3, 
      3,     1,     3,     3,     1,     3,     3,     1,     3,     3, 
      3,     1,     4,     1,     2,     2,     2,     2,     4,     1, 
      1,     1,     1,     1,     1,     1,     4,     3,     4,     3, 
      3,     2,     2,     1,     1,     1,     3,     1,     3,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     2,     1,     1,     1,     1,     1,     1,     1, 
      1,     1,     0,     0,     0
};
static YYNonTerm yyLHS[315]= {
      0,     1,     1,     2,     2,     2,     3,     3,     3,     3, 
      5,     4,     4,     7,     7,     8,    12,    12,    12,    12, 
     12,    12,    13,    13,    13,    13,    13,    14,    14,    14, 
     14,    14,    14,    14,    14,    14,    14,    14,    14,    15, 
     15,    30,    30,    30,    35,    35,    38,    38,    11,    11, 
     43,    43,    42,    47,    49,    49,    49,    49,    48,    48, 
     50,    50,    50,    51,    31,    31,    31,    55,    55,    56, 
     56,     9,     9,    57,    57,    57,    57,    57,    57,    57, 
     58,    58,    58,    58,    66,    66,    63,    63,    67,    67, 
     69,    69,    69,    64,    64,    46,    46,    46,    72,    72, 
     73,    73,    70,    70,    70,    74,    74,    74,    74,    74, 
     74,    74,    74,    74,    32,    75,    76,    76,    76,    76, 
     76,    76,    78,    78,    78,    80,    80,     6,     6,     6, 
      6,    87,    88,    89,    89,    81,    81,    81,    91,    82, 
     82,    82,    82,    82,    82,    82,    82,    82,    82,    83, 
     83,    83,    83,    83,    86,    86,    86,    71,    71,   103, 
    103,   103,   103,   103,   103,   103,   103,   103,   103,   103, 
    101,   101,    53,   114,   114,   116,   116,   118,   118,   120, 
    120,   122,   122,   124,   124,   124,   126,   126,   126,   126, 
    126,   129,   129,   129,   134,   134,   134,   137,   137,   137, 
    137,   140,   140,   102,   102,   102,   102,   102,   102,   146, 
    146,   146,   146,   146,   146,   143,   143,   143,   143,   143, 
    143,   143,   143,   150,   150,   150,   150,   151,   151,   154, 
    125,   119,   111,    19,   149,   128,   121,   117,   113,    99, 
    123,   112,    84,    21,    52,    44,    33,    98,    85,    95, 
    152,    68,    28,    92,    54,    45,   127,    17,    27,    96, 
     97,   131,   133,   136,   110,    36,    90,    23,    37,    61, 
     24,    59,   130,   132,   135,   109,   139,   108,   153,   145, 
    156,   142,   106,   138,   107,   144,   115,    39,    62,    20, 
    100,    60,    10,    22,    25,   147,   141,   105,    65,   104, 
     18,   155,   155,    40,    93,   148,    16,    41,    26,    29, 
     34,    94,    77,    79,   157
};
static YYBase yyActBase[477]= {
   1126,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,  1081,     7,     7,     7,  1796,    62, 
      7,     7,  1171,     4,  1425,  1488,  1551,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,    14,    14,    39,     7, 
      7,     7,    70,   139,     7,     7,     7,     7,  1796,    62, 
      0,     7,     7,     7,  1614,     7,    16,     7,     7,  1144, 
   1829,  1235,     7,     7,     7,  1299,  2116,    39,  1362,     7, 
     73,   229,     7,     7,     7,     7,   206,   822,   332,    83, 
      7,     7,     7,     7,  1867,  2117,     7,     7,    70,     7, 
      7,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,    86,     7,   151,  2260,  2162,  2162,  2162,  2162,   994, 
    315,   805,   477,  2929,  2818,  2633,  2516,  2393,     7,     7, 
    411,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
   2211,     7,     7,    93,     7,    75,    96,     7,     7,    63, 
   2116,  2086,     7,   128,     7,  1960,  2023,     6,     7,    89, 
     68,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,  2352,  2306,  2162,    98,     7,    16, 
    111,   111,   111,   494,   111,   104,     3,     3,   936,     7, 
      7,     7,     7,   905,     7,   577,     7,     7,     7,  2117, 
      7,     7,     7,     7,     7,  2162,     7,     7,   998,  1643, 
    106,   106,     7,     7,     7,   998,     7,     7,     7,   656, 
      7,  2162,     7,  2162,     7,  2162,  2162,     7,     7,  2162, 
   2162,     7,     7,     7,     7,  2162,  2162,  2162,  2162,     7, 
      7,  2162,  2162,  2162,  2162,     7,     7,  2162,  2162,  2162, 
    123,   105,     1,     7,     7,     7,   115,  1900,     7,     7, 
     71,  1670,   117,  2144,  2086,     7,     7,     7,    16,     7, 
     12,  2162,     7,     7,     7,     7,   115,  2162,     6,     7, 
      7,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,  2162,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,   739,   127,   739,     7, 
   2162,   998,   998,   998,     2,   936,   140,     7,     7,     7, 
     16,     7,     6,     7,  2162,  1060,    57,     7,   105,     7, 
      7,     7,   135,   560,   888,   722,  2944,  2855,  2892,  2670, 
   2707,  2744,  2781,  2555,  2594,  2434,  2475,     7,     7,     7, 
   2162,     7,     7,   216,  1733,     7,     7,     7,     7,   222, 
    135,     7,   135,  2144,  1932,     7,   146,     7,     7,   128, 
   2162,     7,     7,     7,     7,     7,     7,   739,     7,     7, 
    105,   105,   105,   155,   936,    16,     7,     7,     7,  2099, 
    166,     7,     7,  2162,     7,     7,     7,     7,     7,   152, 
      7,   158,     7,     7,     7,     7,   739,   739,   739,   998, 
    384,    16,   967,     7,     7,   153,     7,     7,     7,   249, 
      7,     7,     7,   105,   739,   105,   629,   629,    16,     7, 
      7,   739,   165,     7,   739,   739,   105,   739,   105,   629, 
   2162,     7,     7,     7,     7,   739,     7,   739,   739,   105, 
      7,     7,     7,     7,   739,     7,     7
};
static YYRuleN yyActDef[477]= {
    314,     5,   306,   257,   300,   233,   289,   243,   293,   267, 
    270,   294,   308,   258,   252,   309,   246,   310,   265,   303, 
    307,   254,   271,   298,   314,     1,     3,     4,   314,   314, 
     10,    15,    71,   314,    16,    18,    20,    22,    23,    24, 
     25,    26,    27,    28,    29,    30,    31,    32,    33,    34, 
     35,    36,    37,    38,    39,    40,   314,   314,   314,    44, 
     45,    73,   314,    80,     0,     2,   268,     6,   314,   314, 
    312,    13,   131,   292,    50,    11,   314,    48,   269,   314, 
    314,    72,    17,    19,    21,    43,   314,   314,    66,   114, 
    314,    81,    82,    84,     7,    14,    50,   314,   312,   312, 
    118,   133,   255,     8,   314,   314,   245,    12,   314,   288, 
    230,   283,   276,   285,   279,   295,   305,   234,   301,   280, 
     75,   314,   172,   170,   203,   314,   314,   314,   314,   173, 
    175,   177,   179,   181,   183,   186,   191,   194,   197,   201, 
    314,   215,   209,   210,   211,   212,   213,   214,   223,   224, 
    225,   229,   291,   314,    78,   314,    86,    93,    88,    91, 
    314,   314,    46,   314,    53,    54,    56,   314,    67,    69, 
    314,    74,    83,    85,   287,   242,   248,   156,   266,   304, 
    311,   249,   259,   260,   247,   239,   290,   127,   313,   313, 
    313,   313,   313,   157,   201,   223,   314,   314,   125,   314, 
    314,   314,   314,   312,   314,   314,   314,   314,   314,   154, 
    132,   128,   134,   314,   129,   312,     9,    51,    95,   314, 
     49,    76,   286,   237,   312,   314,   250,   278,   314,   314, 
    314,   314,   221,   222,   204,   314,   205,   206,   207,   314, 
    231,   314,   236,   314,   240,   314,   314,   256,   235,   314, 
    314,   272,   261,   273,   262,   314,   314,   314,   314,   274, 
    263,   314,   314,   314,   314,   296,   281,   314,   314,   314, 
    314,   314,   100,   302,    77,    79,   314,   314,    90,    92, 
    102,   314,   103,   314,   314,    42,    47,   244,   314,    58, 
     60,   314,    63,    55,    57,    64,   314,   314,   314,   116, 
    117,   119,   120,   121,   299,   297,   282,   284,   277,   275, 
    264,   232,   241,   238,   314,   159,   160,   161,   162,   163, 
    164,   165,   166,   167,   168,   169,   312,   314,   312,   126, 
    314,   314,   314,   314,   314,   314,   314,   150,   151,   152, 
    314,   130,   314,    98,   314,   174,   314,   217,   314,   227, 
    219,   220,   314,   176,   178,   180,   182,   184,   185,   187, 
    188,   189,   190,   192,   193,   195,   196,   198,   199,   200, 
    314,   226,   101,   102,   314,    94,   251,    87,    89,   104, 
    314,   110,   314,   314,   314,   106,   314,    41,    52,   314, 
    314,    61,    68,    70,    65,   158,   122,   312,   124,   155, 
    314,   314,   314,   314,   314,   314,   149,   153,    96,   314, 
    313,   216,   218,   314,   208,   202,   105,   111,   108,   314, 
    112,   314,   107,    59,    62,   123,   312,   312,   312,   314, 
    314,   314,   314,    97,    99,   314,   228,   109,   113,   135, 
    138,   137,   139,   314,   312,   314,   314,   314,   314,   312, 
    253,   312,   314,   141,   312,   312,   314,   312,   314,   314, 
    314,   136,   140,   142,   143,   312,   145,   312,   312,   314, 
    313,   144,   146,   147,   312,   171,   148
};
static YYBase yyGotoBase[158]= {
      7,     7,    11,     7,   357,     7,   292,   226,   367,  1000, 
   2827,     7,     5,     7,   793,   724,     7,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,  3025,   395,   173,   236, 
      7,     7,   156,   178,   647,    69,   136,    94,     7,    85, 
    131,     7,   148,   282,     7,   187,    21,     9,   432,  3015, 
   2898,   240,   223,   145,     7,  3045,     7,     7,     7,    31, 
     78,   521,     7,    91,    19,     7,  2691,   163,     7,   727, 
      7,     7,     7,     7,     7,     7,  3016,     7,   302,   228, 
      7,     7,     7,     7,     8,     7,     7,     7,     7,     7, 
      7,   176,  3095,     7,     7,     7,     7,     7,     7,     7, 
      7,     7,     7,     7,    10,     7,    99,     7,    77,     7, 
     82,     7,    92,     7,    88,   113,    18,     7,     7,    56, 
      7,     7,     7,     7,    42,     7,     7,    37,   144,   161, 
    429,     7,     7,     7,   204,   214,     7,     7,     7,     7, 
      7,     7,     7,     7,     7,     7,     7,     7
};
static YYState yyGotoDef[158]= {
      0,    24,    65,    26,    95,    28,   100,   104,    69,   292, 
    198,    76,    31,    34,    35,    36,    37,    38,    39,    40, 
     41,    42,    43,    44,    45,    46,    47,    48,    49,    50, 
     51,    52,    53,    54,    55,    56,   148,    72,   284,   210, 
     59,    60,   286,    77,   330,   105,   434,   163,   288,   164, 
    423,   290,   291,   424,    57,   298,   168,    32,    33,   140, 
    381,   283,   437,   382,   155,   143,    91,   156,   377,   158, 
    380,   209,   342,   352,   282,    58,   212,   213,   188,   475, 
    189,   190,   191,   192,   196,   197,   271,    70,   341,   215, 
    200,   439,   451,   201,   202,   203,   204,   205,   206,   207, 
    208,   193,   139,   314,   316,   317,   318,   319,   320,   321, 
    322,   323,   324,   325,   123,   224,   129,   225,   130,   241, 
    131,   243,   132,   245,   133,   142,   134,   249,   250,   135, 
    255,   256,   257,   258,   136,   261,   262,   137,   144,   145, 
    138,   268,   269,   124,   125,   126,   127,   128,   146,   147, 
    141,   348,   230,   231,   149,   150,   151,     0
};
static YYAct yyNext[3555]= {
    789,     0,     5,   789,   789,     7,    16,   789,   789,   789, 
     14,    25,    21,     3,    13,   789,   789,   789,     9,    10, 
      6,   789,     8,    11,   789,     4,    19,   789,     2,    20, 
     12,    15,    17,   789,     0,   180,     0,     0,   789,    82, 
     83,    84,    81,     0,   789,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,   789,    66,   789,    73, 
     78,   789,    22,   577,   174,    22,   789,    23,   537,   106, 
    789,    66,    73,   789,   789,   537,   287,   789,   789,   106, 
    802,   789,   789,   789,    18,     5,   789,   789,     7,    16, 
    789,   789,   789,    14,    18,    21,     3,    13,   789,   789, 
    789,     9,    10,     6,   789,     8,    11,   789,     4,    19, 
    789,     2,    20,    12,    15,    17,   789,   109,    73,    18, 
    106,   789,    78,    22,    22,   568,   568,   789,    23,    23, 
     78,    22,    22,   579,   579,   152,    23,   152,   106,   789, 
     66,   174,    18,    18,   789,    16,   109,   546,    18,   789, 
     18,    18,   546,   789,   102,   152,   789,   789,   563,   106, 
    789,   789,   287,   804,   789,   789,   790,   152,   106,   790, 
    790,    17,    22,   790,   790,   790,    78,   790,    22,   580, 
    580,   790,   790,   790,    18,   152,    18,   790,   223,    22, 
    790,   287,   287,   790,    23,    18,    73,   152,   557,   790, 
    557,   557,   557,   223,   790,    23,   109,   647,    18,   647, 
    790,   647,   109,   647,   647,   647,    22,   287,   222,   557, 
    152,    73,   790,   790,   790,   153,   790,   790,   790,   790, 
    790,   270,   790,    97,   272,    16,   790,   279,   297,   790, 
    790,   217,   162,   790,   790,   246,   790,   790,   790,   612, 
    293,   294,   612,   612,    68,   122,   612,   612,   612,   161, 
    450,    17,   527,   315,   612,   612,   612,   357,   358,   527, 
    612,   102,    79,   612,   167,    78,   612,    22,   579,   579, 
    263,    78,   612,    22,   581,   581,   220,   612,   558,    81, 
    558,   558,   558,   612,   289,    23,    99,   264,    98,   379, 
    365,   366,   120,   363,   364,   612,   612,   612,   378,   558, 
    612,   359,   360,   361,   362,   612,   162,   392,   353,   612, 
     67,    79,   612,   612,   345,   354,   612,   612,   232,   612, 
    612,   612,   789,   272,   356,   789,   789,   355,   233,   789, 
    789,   789,   403,   326,   221,   328,     0,   789,   789,   789, 
    372,   652,   652,   789,   410,   343,   789,    27,     0,   789, 
     94,   121,     0,     0,   228,   789,   103,    29,     0,     0, 
    789,   652,   122,   652,     0,   652,   789,   652,   652,   652, 
      0,    27,   652,   242,   177,    71,     0,   344,   789,    66, 
    174,    29,   379,   789,     0,     0,   216,   285,   789,   187, 
    211,   214,   789,   295,     0,   789,   789,     0,   115,   789, 
    789,   177,   789,   789,   789,     0,     7,    16,     0,     0, 
      0,    14,   114,    21,     0,    13,     0,    71,   113,     9, 
     10,    71,     0,     8,    11,   115,     0,    19,   390,     0, 
     20,    12,    15,    17,     0,    22,   152,   159,     0,   114, 
     23,    86,    87,     0,   110,   113,     0,   111,   112,   122, 
      0,   116,   117,     0,    18,   119,   118,   122,   246,     0, 
      0,     0,    22,   122,     0,   397,     0,    23,   327,     0, 
    160,   110,     0,   170,   111,   112,     0,     0,   116,   117, 
      0,   792,   119,   118,   789,    92,     0,   789,   789,     0, 
    219,   789,   789,   789,     0,     0,   385,   263,   263,   789, 
    789,   789,     0,   656,   656,   789,     0,     0,   789,     0, 
    387,   789,   383,   172,   264,   264,     0,   789,     0,   421, 
      0,     0,   789,   656,   394,   656,     0,   656,   789,   656, 
    656,   656,     0,     0,   656,   656,   656,   110,     0,     0, 
    789,    66,   789,     0,     0,   789,   237,     0,     0,   122, 
    789,     0,     0,     0,   789,   386,   122,   789,   789,   411, 
      0,   789,   789,   391,   789,   789,   789,   789,   408,   393, 
    789,   789,     0,   449,   789,   789,   789,     0,     0,     0, 
      0,   280,   789,   789,   789,     0,   653,   653,   789,     0, 
      0,   789,     0,     0,   789,     0,   418,     0,     0,   422, 
    789,     0,   460,     0,   219,   789,   653,     0,   653,   383, 
    653,   789,   653,   653,   653,     0,   218,   653,   242,   177, 
      0,     0,     0,   789,    66,   174,   470,     0,   789,     0, 
      0,     0,     0,   789,   159,   433,     0,   789,   159,     0, 
    789,   789,     0,   115,   789,   789,   177,   789,   789,   789, 
      0,     7,    16,     0,     0,   419,    14,   114,    21,     0, 
     13,     0,     0,   113,     9,    10,     0,     0,     8,    11, 
    115,     0,    19,     0,     0,    20,    12,    15,    17,     0, 
     22,   152,     0,     0,   114,    23,   367,   368,   369,   110, 
    113,     0,   111,   112,   373,     0,   116,   117,     0,    18, 
    119,   118,     0,   280,     0,     0,     0,    22,     0,     0, 
      0,     0,    23,   108,     0,     0,   110,     0,     0,   111, 
    112,     0,     0,   116,   117,     0,   792,   119,   118,   789, 
    218,   159,   789,   789,     0,     0,   789,   789,   789,     0, 
    349,   159,     0,     0,   789,   789,   789,     0,   657,   657, 
    789,     0,     0,   789,     0,     0,   789,     0,     0,     0, 
      0,     0,   789,     0,     0,     0,     0,   789,   657,     0, 
    657,     0,   657,   789,   657,   657,   657,    93,     0,   657, 
    657,   657,   110,     0,     0,   789,    66,   789,     0,   415, 
    789,     0,   276,   277,   219,   789,   373,     0,     0,   789, 
    166,     0,   789,   789,   296,   173,   789,   789,     0,   789, 
    789,   789,   177,     0,     0,   185,   175,     0,     0,   184, 
    176,   181,     0,     0,     0,   395,     0,   182,   183,   178, 
      0,   654,   654,   186,     0,     0,   115,     0,     0,   179, 
      0,   399,     0,     0,     0,   180,     0,     0,     0,     0, 
    114,   654,     0,   654,   166,   654,   113,   654,   654,   654, 
      0,     0,   654,   654,   244,     0,     0,     0,    73,   165, 
    174,     0,     0,    22,   166,   166,     0,     0,    23,   166, 
    166,     0,   110,     0,     0,   111,   112,     0,     0,   116, 
    117,     0,    18,   119,   118,   177,     0,     0,   185,   175, 
      0,     0,   184,   176,   181,   299,   300,   301,   302,   303, 
    182,   183,   178,     0,   655,   655,   186,     0,     0,   115, 
    218,     0,   179,   165,   436,   389,   177,     0,   180,     0, 
      0,     0,     0,   114,   655,   296,   655,     0,   655,   113, 
    655,   655,   655,   165,   165,   655,   655,   244,   165,   165, 
    115,    73,     0,   166,     0,     0,    22,   177,     0,     0, 
      0,    23,     0,     0,   114,   110,     0,     0,   111,   112, 
    113,     0,   116,   117,     0,    18,   119,   118,     0,   409, 
      0,   115,    73,     0,     0,   413,     0,    22,   177,     0, 
     30,     0,    23,     0,     0,   114,   110,     0,   166,   111, 
    112,   113,     0,   116,   117,     0,    18,   119,   118,     0, 
      0,     0,   115,    73,    30,     0,     0,     0,    22,    74, 
    240,   650,   165,    23,     0,     0,   114,   110,     0,     0, 
    111,   112,   113,     0,   116,   117,     0,    18,   119,   118, 
    650,     0,   650,     0,   650,     0,   650,   650,   650,    22, 
      0,   650,    90,     0,    23,     0,     0,     0,   110,    96, 
      0,   111,   112,     0,     0,   116,   117,   165,    18,   119, 
    118,     1,    64,     5,     0,     0,     7,    16,     0,     0, 
      0,    14,     0,    21,     3,    13,   240,   651,     0,     9, 
     10,     6,     0,     8,    11,     0,     4,    19,    96,     2, 
     20,    12,    15,    17,     0,     0,   651,     0,   651,     0, 
    651,     0,   651,   651,   651,     0,     1,   651,     5,     0, 
      0,     7,    16,     0,     0,     0,    14,   435,    21,     3, 
     13,     0,    22,     0,     9,    10,     6,    23,     8,    11, 
      0,     4,    19,     0,     2,    20,    12,    15,    17,   278, 
      0,   792,     0,     0,     0,     0,     0,     0,   115,     0, 
      0,     0,     0,   548,     0,     0,   548,   548,     0,     0, 
      0,   548,   114,   548,   548,   548,     0,    22,   113,   548, 
    548,   548,    23,   548,   548,     0,   548,   548,     0,   548, 
    548,   548,   548,   548,   109,    22,   792,     0,     0,     0, 
     23,     0,     0,     0,   110,     0,     0,   111,   112,     0, 
      0,   116,   117,     0,    18,   119,   118,   548,   548,     0, 
     78,     0,    22,   548,   548,   548,   548,   549,     0,     0, 
    549,   549,     0,     0,     0,   549,     0,   549,   549,   549, 
      0,   548,     0,   549,   549,   549,     0,   549,   549,     0, 
    549,   549,     0,   549,   549,   549,   549,   549,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,    90,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,   549,   549,     0,    78,     0,    22,   549,   549,   549, 
    549,   520,     0,     0,   520,   520,     0,     0,     0,   520, 
      0,   520,   520,   520,     0,   549,     0,   520,   520,   520, 
      0,   520,   520,     0,   520,   520,     0,   520,   520,   520, 
    520,   520,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,   520,    66,     0,   520,     0, 
    520,   520,   520,   520,   543,   520,     0,   543,   543,     0, 
      0,     0,   543,     0,   543,   543,   543,     0,     0,   520, 
    543,   543,   543,     0,   543,   543,     0,   543,   543,     0, 
    543,   543,   543,   543,   543,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,   543,    66, 
      0,   543,     0,   543,   543,   543,   543,     5,   543,     0, 
      7,    16,     0,     0,     0,    14,     0,    21,     3,    13, 
      0,     0,   543,     9,    10,     6,     0,     8,    11,     0, 
      4,    19,     0,     2,    20,    12,    15,    17,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,   493,     0,     0,   493,     0,   493,   493,   493,     0, 
      5,   493,     0,     7,    16,     0,     0,     0,    14,     0, 
     21,     3,    13,     0,     0,   796,     9,    10,     6,     0, 
      8,    11,     0,     4,    19,     0,     2,    20,    12,    15, 
     17,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,   495,     0,     0,   495,     0,   495, 
    495,   495,     0,     5,   495,     0,     7,    16,     0,     0, 
      0,    14,     0,    21,     3,    13,     0,     0,   798,     9, 
     10,     6,     0,     8,    11,     0,     4,    19,     0,     2, 
     20,    12,    15,    17,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,   497,     0,     0, 
    497,     0,   497,   497,   497,     0,     5,   497,     0,     7, 
     16,     0,     0,     0,    14,     0,    21,     3,    13,     0, 
      0,   800,     9,    10,     6,     0,     8,    11,     0,     4, 
     19,     0,     2,    20,    12,    15,    17,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,   115,     0,     0, 
    527,    66,     5,     0,     0,     7,    16,   527,     0,   102, 
     14,   114,    21,     3,    13,     0,     0,   113,     9,    10, 
      6,     0,     8,    11,   794,     4,    19,     0,     2,    20, 
     12,    15,    17,     0,    22,   152,     0,     0,     0,    23, 
      0,     0,     0,   110,     0,     0,   111,   112,     0,     0, 
    116,   117,     0,    18,   119,   118,     0,     0,     0,    78, 
      0,    22,   152,     0,     0,     5,    23,     0,     7,    16, 
      0,     0,     0,    14,     0,    21,     3,    13,     0,     0, 
    792,     9,    10,     6,     0,     8,    11,     0,     4,    19, 
      0,     2,    20,    12,    15,    17,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,    78,     0,    22,   152,     0,     0,     5,    23, 
      0,     7,    16,     0,     0,     0,    14,     0,    21,     3, 
     13,     0,     0,   794,     9,    10,     6,     0,     8,    11, 
      0,     4,    19,     0,     2,    20,    12,    15,    17,     0, 
      0,     5,     0,     0,     7,    16,     0,     0,     0,    14, 
      0,    21,     3,    13,     0,     0,     0,     9,    10,     6, 
      0,     8,    11,    66,     4,    19,     0,     2,    20,    12, 
     15,    17,     0,     0,     0,     0,     0,     0,     0,     5, 
      0,     0,     7,    16,     0,     0,   794,    14,     0,    21, 
      3,    13,     0,     0,     0,     9,    10,     6,     0,     8, 
     11,   152,     4,    19,     0,     2,    20,    12,    15,    17, 
      0,     0,     5,     0,     0,     7,    16,     0,     0,   792, 
     14,     0,    21,     3,    13,     0,     0,     0,     9,    10, 
      6,     0,     8,    11,    66,     4,    19,     0,     2,    20, 
     12,    15,    17,     0,     5,     0,     0,     7,    16,     0, 
      0,   376,    14,     0,    21,     3,    13,   794,     0,     0, 
      9,    10,     6,     0,     8,    11,     0,     4,    19,     0, 
      2,    20,    12,    15,    17,     7,    16,     0,     0,     0, 
     14,     0,    21,     0,    13,     0,     0,     0,     9,    10, 
    794,     0,     8,    11,     0,     0,    19,     0,     0,    20, 
     12,    15,    17,     0,   152,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,   794,     0,     0,     0,     0,     0,     0,   531, 
      0,   531,   531,     0,   531,     0,   531,     0,     7,    16, 
      0,     0,     0,    14,     0,    21,     0,    13,     0,     0, 
    806,     9,    10,     0,     0,     8,    11,     0,     0,    19, 
      0,     0,    20,    12,    15,    17,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,   533,     0,   533,   533,     0,   533,     0,   533, 
      0,     7,    16,     0,     0,     0,    14,     0,    21,     0, 
     13,     0,     0,   808,     9,    10,     0,     0,     8,    11, 
      0,     0,    19,     0,     0,    20,    12,    15,    17,     0, 
      0,     7,    16,   115,     0,     0,    14,     0,    21,     0, 
     13,     0,     0,     0,     9,    10,     0,   114,     8,    11, 
      0,   115,    19,   113,   174,    20,    12,    15,    17,     0, 
      0,     0,     0,     0,     0,   114,    66,   174,     0,     0, 
     22,   113,     0,     0,     0,    23,   794,     0,   115,   110, 
      0,     0,   111,   112,    66,     0,   116,   117,    22,    18, 
    119,   118,   114,    23,     0,     0,   115,   110,   113,     0, 
    111,   112,     0,     0,   116,   117,   794,    18,   119,   118, 
    114,     0,     0,     0,   109,    22,   113,     0,     0,     0, 
     23,     0,     0,     0,   110,     0,     0,   111,   112,     0, 
      0,   116,   117,    22,    18,   119,   118,     0,    23,     0, 
      0,     0,   110,     0,     0,   111,   112,     0,     0,   116, 
    117,     0,    18,   119,   118,   702,   702,   702,   702,   702, 
    702,   702,     0,   702,   702,   702,   702,   702,   702,   702, 
    702,   702,   702,   702,   702,   702,   702,   702,     0,   702, 
    702,   702,   702,   702,   702,   702,   702,   702,   702,   702, 
    702,   702,   702,   702,   702,   702,   702,   702,     0,     0, 
    702,     0,     0,   273,   680,   680,   680,   680,   114,   227, 
    680,     0,   680,   680,   113,   680,   680,   680,   680,   680, 
    680,   680,   680,   680,   680,   680,   680,     0,   680,    78, 
    680,    22,   680,   680,   680,   680,   680,   680,   680,   680, 
    680,   680,   680,   680,   680,   680,   680,     0,     0,   226, 
    700,   700,   700,   700,   700,   700,   700,     0,   700,   700, 
    700,   700,   700,   700,   700,   700,   700,   700,   700,   700, 
    700,   700,   700,     0,     0,   700,     0,   700,     0,   700, 
    287,   700,   700,   700,   700,   700,   700,   700,   700,   700, 
    700,   700,   700,     0,     0,   700,   307,   311,   678,   678, 
      0,     0,   305,     0,   678,   678,     0,   678,   309,   678, 
    306,   304,   678,   313,   310,   678,   308,   312,   678,     0, 
    678,     0,   678,     0,   678,   678,     0,   102,   678,   678, 
    678,   678,   678,   678,   678,   678,   678,   678,   678,   671, 
    671,     0,     0,     0,     0,   671,   671,     0,   671,     0, 
    671,     0,     0,   671,     0,     0,   671,     0,     0,   671, 
      0,   671,     0,   671,     0,   671,   671,   671,     0,    23, 
    671,   671,   671,   671,   671,   671,   671,   671,   265,   266, 
    672,   672,     0,     0,     0,     0,   672,   672,     0,   672, 
      0,   672,     0,     0,   672,     0,     0,   672,     0,     0, 
    672,     0,   672,     0,   672,     0,   672,   672,   672,     0, 
     23,   672,   672,   672,   672,   672,   672,   672,   672,   265, 
    266,   673,   673,     0,     0,     0,     0,   673,   673,     0, 
    673,     0,   673,     0,     0,   673,     0,     0,   673,     0, 
      0,   673,     0,   673,     0,   673,     0,   673,   673,   673, 
      0,    23,   673,   673,   673,   673,   673,   673,   673,   673, 
    265,   266,   668,   668,     0,     0,     0,     0,   668,   668, 
      0,   668,     0,   668,     0,     0,   668,     0,     0,   668, 
      0,     0,   668,     0,   668,     0,   668,     0,   668,   668, 
    668,     0,     0,   668,   668,   668,   668,   668,   668,   111, 
    112,   669,   669,     0,     0,     0,     0,   669,   669,     0, 
    669,     0,   669,     0,     0,   669,     0,     0,   669,     0, 
      0,   669,     0,   669,     0,   669,     0,   669,   669,   669, 
      0,     0,   669,   669,   669,   669,   669,   669,   111,   112, 
    670,   670,     0,     0,     0,     0,   670,   670,     0,   670, 
      0,   670,     0,     0,   670,     0,     0,   670,     0,     0, 
    670,     0,   670,     0,   670,     0,   670,   670,   670,     0, 
      0,   670,   670,   670,   670,   670,   670,   111,   112,   663, 
    663,     0,     0,     0,     0,   663,   663,     0,   663,     0, 
    259,     0,     0,   663,     0,     0,   260,     0,     0,   663, 
      0,   663,     0,   663,     0,   663,   663,   663,     0,     0, 
    663,   663,   663,   663,   663,   663,   664,   664,     0,     0, 
      0,     0,   664,   664,     0,   664,     0,   259,     0,     0, 
    664,     0,     0,   260,     0,     0,   664,     0,   664,     0, 
    664,     0,   664,   664,   664,     0,     0,   664,   664,   664, 
    664,   664,   664,   665,   665,     0,     0,     0,     0,   665, 
    665,     0,   665,     0,   259,     0,     0,   665,     0,     0, 
    260,   101,     0,   665,     0,   665,     0,   665,     0,   665, 
    665,   665,     0,     0,   665,   665,   665,   665,   665,   665, 
    666,   666,     0,     0,     0,     0,   666,   666,     0,   666, 
    101,   259,     0,     0,   666,     0,     0,   260,     0,     0, 
    666,     0,   666,     0,   666,     0,   666,   666,   666,     0, 
      0,   666,   666,   666,   666,   666,   666,   667,   667,     0, 
      0,     0,     0,   667,   667,     0,   667,     0,   259,     0, 
      0,   667,     0,     0,   260,     0,     0,   667,     0,   667, 
      0,   667,     0,   667,   667,   667,     0,     0,   667,   667, 
    667,   667,   667,   667,   660,   660,    75,     0,     0,     0, 
    660,   254,     0,   253,     0,     0,     0,     0,   660,     0, 
      0,     0,     0,     0,   660,     0,   660,     0,   660,     0, 
    660,   660,   660,     0,     0,   660,   660,   660,   660,   251, 
    252,   661,   661,     0,   334,     0,    75,   661,   254,     0, 
    253,     0,     0,   107,     0,   661,     0,     0,     0,     0, 
      0,   661,     0,   661,     0,   661,     0,   661,   661,   661, 
      0,     0,   661,   661,   661,   661,   251,   252,   662,   662, 
      0,     0,     0,     0,   662,   254,     0,   253,     0,     0, 
      0,     0,   662,     0,     0,     0,     0,     0,   662,     0, 
    662,     0,   662,     0,   662,   662,   662,     0,     0,   662, 
    662,   662,   662,   251,   252,   658,   658,     0,     0,     0, 
      0,   247,     0,     0,     0,     0,     0,     0,   154,   248, 
    659,   659,     0,     0,     0,   658,   247,   658,   171,   658, 
      0,   658,   658,   658,   248,     0,   658,   658,   658,   658, 
    659,     0,   659,     0,   659,     0,   659,   659,   659,     0, 
      0,   659,   659,   659,   659,    62,     0,   396,     0,   398, 
      0,     0,     0,     0,     0,    61,   329,     0,     0,     0, 
      0,     0,     0,   337,   338,   339,     0,     0,     0,    62, 
      0,     0,     0,     0,    62,    63,     0,    80,    62,    61, 
      0,   274,     0,   275,    61,     0,     0,     0,    61,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,    63, 
      0,     0,     0,     0,    63,     0,     0,    62,     0,     0, 
      0,    85,    88,    89,    62,     0,     0,    61,   425,     0, 
      0,     0,     0,     0,    61,     0,    80,     0,     0,     0, 
      0,     0,     0,     0,     0,   157,     0,    63,    63,     0, 
      0,     0,   169,   199,    63,   388,     0,   440,   441,   442, 
      0,     0,   195,    62,     0,     0,     0,   347,     0,     0, 
      0,     0,     0,    61,     0,   453,    63,     0,     0,   229, 
    235,   235,   461,   239,     0,   463,   464,     0,   466,     0, 
      0,     0,     0,    63,     0,     0,   471,     0,   472,   473, 
      0,     0,   404,   406,     0,   476,     0,   407,   370,   371, 
      0,     0,     0,     0,   281,     0,     0,     0,    62,     0, 
      0,     0,   267,     0,    61,     0,     0,     0,    61,     0, 
      0,     0,   194,     0,     0,   169,     0,     0,     0,     0, 
    194,     0,     0,     0,    63,     0,     0,     0,    63,     0, 
      0,     0,     0,     0,     0,   331,   332,   333,     0,   335, 
    234,   236,     0,   238,   340,     0,     0,     0,     0,   199, 
    336,   430,   432,     0,     0,   194,     0,     0,   195,     0, 
      0,     0,     0,     0,   346,     0,   412,     0,     0,     0, 
    414,     0,     0,     0,     0,   350,   351,     0,   446,   447, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,   459,     0,     0,   416,   462, 
    417,     0,   420,     0,     0,     0,     0,   374,     0,     0, 
      0,     0,     0,     0,     0,   281,   281,   384,   426,   427, 
    428,   375,     0,   194,     0,    61,    61,     0,   194,     0, 
      0,     0,     0,     0,   194,     0,     0,    63,     0,   438, 
      0,   169,     0,   194,   194,     0,    63,     0,   444,     0, 
    194,     0,     0,     0,   194,     0,     0,     0,     0,     0, 
      0,   452,     0,   454,   455,   457,     0,   400,   401,   402, 
      0,   405,     0,     0,   465,     0,   467,   468,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,   474,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,   374,   374, 
      0,     0,     0,     0,   384,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,    62,     0,     0,     0,     0,   194, 
    267,   267,     0,     0,    61,     0,     0,     0,   429,    63, 
    431,     0,     0,     0,     0,   194,   194,   194,   194,     0, 
    194,     0,     0,     0,    63,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,   443,   445,     0,   448,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,   456,   458,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,   469,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,   194, 
      0,     0,     0,     0,   194,     0,     0,     0,   194,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,   194,   194,     0,   194,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,   194,   194,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,   194
};
static YYCheck yyCheck[3572]= {
      0,   477,     2,     3,     4,     5,     6,     7,     8,     9, 
     10,     0,    12,    13,    14,    15,    16,    17,    18,    19, 
     20,    21,    22,    23,    24,    25,    26,    27,    28,    29, 
     30,    31,    32,    33,   477,    33,   477,   477,    38,    34, 
     35,    36,    33,   477,    44,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,    56,    57,    58,    56, 
     59,    61,    61,    62,    58,    61,    66,    66,    56,    63, 
     70,    57,    56,    73,    74,    63,    64,    77,    78,    63, 
     80,    81,    82,     0,    80,     2,     3,     4,     5,     6, 
      7,     8,     9,    10,    80,    12,    13,    14,    15,    16, 
     17,    18,    19,    20,    21,    22,    23,    24,    25,    26, 
     27,    28,    29,    30,    31,    32,    33,    60,    56,    80, 
     63,    38,    59,    61,    61,    62,    63,    44,    66,    66, 
     59,    61,    61,    62,    63,    62,    66,    62,    63,    56, 
     57,    58,    80,    80,    61,     6,    60,    58,    80,    66, 
     80,    80,    63,    70,    65,    62,    73,    74,    62,    63, 
     77,    78,    64,    80,    81,    82,     0,    62,    63,     3, 
      4,    32,    61,     7,     8,     9,    59,    11,    61,    62, 
     63,    15,    16,    17,    80,    62,    80,    21,    37,    61, 
     24,    64,    64,    27,    66,    80,    56,    62,    59,    33, 
     61,    62,    63,    37,    38,    66,    60,    56,    80,    58, 
     44,    60,    60,    62,    63,    64,    61,    64,    67,    80, 
     62,    56,    56,    57,    58,    80,    60,    61,    62,    63, 
     64,   140,    66,    70,   140,     6,    70,   159,   169,    73, 
     74,   105,    86,    77,    78,   132,    80,    81,    82,     0, 
    165,   166,     3,     4,    28,    79,     7,     8,     9,    86, 
     11,    32,    56,   194,    15,    16,    17,   249,   250,    63, 
     21,    65,    32,    24,    87,    59,    27,    61,    62,    63, 
    136,    59,    33,    61,    62,    63,   108,    38,    59,   280, 
     61,    62,    63,    44,   163,    66,    70,   136,    70,   280, 
    263,   264,    79,   261,   262,    56,    57,    58,   277,    80, 
     61,   255,   256,   257,   258,    66,   160,   296,   241,    70, 
     28,    81,    73,    74,   225,   243,    77,    78,   124,    80, 
     81,    82,     0,   239,   246,     3,     4,   245,   124,     7, 
      8,     9,   334,   195,   121,   197,   477,    15,    16,    17, 
    272,    36,    37,    21,   344,   219,    24,     0,   477,    27, 
     68,    79,   477,   477,   124,    33,    74,     0,   477,   477, 
     38,    56,   196,    58,   477,    60,    44,    62,    63,    64, 
    477,    24,    67,    68,     0,    28,   477,   224,    56,    57, 
     58,    24,   373,    61,   477,   477,   104,   161,    66,    97, 
     98,    99,    70,   167,   477,    73,    74,   477,    24,    77, 
     78,     0,    80,    81,    82,   477,     5,     6,   477,   477, 
    477,    10,    38,    12,   477,    14,   477,    70,    44,    18, 
     19,    74,   477,    22,    23,    24,   477,    26,   290,   477, 
     29,    30,    31,    32,   477,    61,    62,    80,   477,    38, 
     66,    56,    57,   477,    70,    44,   477,    73,    74,   283, 
    477,    77,    78,   477,    80,    81,    82,   291,   355,   477, 
    477,   477,    61,   297,   477,   327,   477,    66,   196,   477, 
     85,    70,   477,    88,    73,    74,   477,   477,    77,    78, 
    477,    80,    81,    82,     0,    63,   477,     3,     4,   477, 
    105,     7,     8,     9,   477,   477,   283,   363,   364,    15, 
     16,    17,   477,    36,    37,    21,   477,   477,    24,   477, 
    284,    27,   282,    91,   363,   364,   477,    33,   477,   384, 
    477,   477,    38,    56,   298,    58,   477,    60,    44,    62, 
     63,    64,   477,   477,    67,    68,    69,    70,   477,   477, 
     56,    57,    58,   477,   477,    61,   127,   477,   477,   383, 
     66,   477,   477,   477,    70,   283,   390,    73,    74,   346, 
    477,    77,    78,   291,    80,    81,    82,     0,   342,   297, 
      3,     4,   477,   435,     7,     8,     9,   477,   477,   477, 
    477,   159,    15,    16,    17,   477,    36,    37,    21,   477, 
    477,    24,   477,   477,    27,   477,   383,   477,   477,   386, 
     33,   477,   449,   477,   219,    38,    56,   477,    58,   379, 
     60,    44,    62,    63,    64,   477,   105,    67,    68,     0, 
    477,   477,   477,    56,    57,    58,   460,   477,    61,   477, 
    477,   477,   477,    66,   277,   409,   477,    70,   281,   477, 
     73,    74,   477,    24,    77,    78,     0,    80,    81,    82, 
    477,     5,     6,   477,   477,   383,    10,    38,    12,   477, 
     14,   477,   477,    44,    18,    19,   477,   477,    22,    23, 
     24,   477,    26,   477,   477,    29,    30,    31,    32,   477, 
     61,    62,   477,   477,    38,    66,   267,   268,   269,    70, 
     44,   477,    73,    74,   272,   477,    77,    78,   477,    80, 
     81,    82,   477,   281,   477,   477,   477,    61,   477,   477, 
    477,   477,    66,    76,   477,   477,    70,   477,   477,    73, 
     74,   477,   477,    77,    78,   477,    80,    81,    82,     0, 
    219,   374,     3,     4,   477,   477,     7,     8,     9,   477, 
    229,   384,   477,   477,    15,    16,    17,   477,    36,    37, 
     21,   477,   477,    24,   477,   477,    27,   477,   477,   477, 
    477,   477,    33,   477,   477,   477,   477,    38,    56,   477, 
     58,   477,    60,    44,    62,    63,    64,    63,   477,    67, 
     68,    69,    70,   477,   477,    56,    57,    58,   477,   370, 
     61,   477,   155,   156,   409,    66,   374,   477,   477,    70, 
     86,   477,    73,    74,   167,    91,    77,    78,   477,    80, 
     81,    82,     0,   477,   477,     3,     4,   477,   477,     7, 
      8,     9,   477,   477,   477,   314,   477,    15,    16,    17, 
    477,    36,    37,    21,   477,   477,    24,   477,   477,    27, 
    477,   330,   477,   477,   477,    33,   477,   477,   477,   477, 
     38,    56,   477,    58,   140,    60,    44,    62,    63,    64, 
    477,   477,    67,    68,    69,   477,   477,   477,    56,    86, 
     58,   477,   477,    61,   160,   161,   477,   477,    66,   165, 
    166,   477,    70,   477,   477,    73,    74,   477,   477,    77, 
     78,   477,    80,    81,    82,     0,   477,   477,     3,     4, 
    477,   477,     7,     8,     9,   188,   189,   190,   191,   192, 
     15,    16,    17,   477,    36,    37,    21,   477,   477,    24, 
    409,   477,    27,   140,   413,   288,     0,   477,    33,   477, 
    477,   477,   477,    38,    56,   298,    58,   477,    60,    44, 
     62,    63,    64,   160,   161,    67,    68,    69,   165,   166, 
     24,    56,   477,   239,   477,   477,    61,     0,   477,   477, 
    477,    66,   477,   477,    38,    70,   477,   477,    73,    74, 
     44,   477,    77,    78,   477,    80,    81,    82,   477,   342, 
    477,    24,    56,   477,   477,   348,   477,    61,     0,   477, 
      0,   477,    66,   477,   477,    38,    70,   477,   284,    73, 
     74,    44,   477,    77,    78,   477,    80,    81,    82,   477, 
    477,   477,    24,    56,    24,   477,   477,   477,    61,    29, 
     36,    37,   239,    66,   477,   477,    38,    70,   477,   477, 
     73,    74,    44,   477,    77,    78,   477,    80,    81,    82, 
     56,   477,    58,   477,    60,   477,    62,    63,    64,    61, 
    477,    67,    62,   477,    66,   477,   477,   477,    70,    69, 
    477,    73,    74,   477,   477,    77,    78,   284,    80,    81, 
     82,     0,     1,     2,   477,   477,     5,     6,   477,   477, 
    477,    10,   477,    12,    13,    14,    36,    37,   477,    18, 
     19,    20,   477,    22,    23,   477,    25,    26,   108,    28, 
     29,    30,    31,    32,   477,   477,    56,   477,    58,   477, 
     60,   477,    62,    63,    64,   477,     0,    67,     2,   477, 
    477,     5,     6,   477,   477,   477,    10,   410,    12,    13, 
     14,   477,    61,   477,    18,    19,    20,    66,    22,    23, 
    477,    25,    26,   477,    28,    29,    30,    31,    32,   159, 
    477,    80,   477,   477,   477,   477,   477,   477,    24,   477, 
    477,   477,   477,     2,   477,   477,     5,     6,   477,   477, 
    477,    10,    38,    12,    13,    14,   477,    61,    44,    18, 
     19,    20,    66,    22,    23,   477,    25,    26,   477,    28, 
     29,    30,    31,    32,    60,    61,    80,   477,   477,   477, 
     66,   477,   477,   477,    70,   477,   477,    73,    74,   477, 
    477,    77,    78,   477,    80,    81,    82,    56,    57,   477, 
     59,   477,    61,    62,    63,    64,    65,     2,   477,   477, 
      5,     6,   477,   477,   477,    10,   477,    12,    13,    14, 
    477,    80,   477,    18,    19,    20,   477,    22,    23,   477, 
     25,    26,   477,    28,    29,    30,    31,    32,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   281,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,    56,    57,   477,    59,   477,    61,    62,    63,    64, 
     65,     2,   477,   477,     5,     6,   477,   477,   477,    10, 
    477,    12,    13,    14,   477,    80,   477,    18,    19,    20, 
    477,    22,    23,   477,    25,    26,   477,    28,    29,    30, 
     31,    32,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,    56,    57,   477,    59,   477, 
     61,    62,    63,    64,     2,    66,   477,     5,     6,   477, 
    477,   477,    10,   477,    12,    13,    14,   477,   477,    80, 
     18,    19,    20,   477,    22,    23,   477,    25,    26,   477, 
     28,    29,    30,    31,    32,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,    56,    57, 
    477,    59,   477,    61,    62,    63,    64,     2,    66,   477, 
      5,     6,   477,   477,   477,    10,   477,    12,    13,    14, 
    477,   477,    80,    18,    19,    20,   477,    22,    23,   477, 
     25,    26,   477,    28,    29,    30,    31,    32,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,    56,   477,   477,    59,   477,    61,    62,    63,   477, 
      2,    66,   477,     5,     6,   477,   477,   477,    10,   477, 
     12,    13,    14,   477,   477,    80,    18,    19,    20,   477, 
     22,    23,   477,    25,    26,   477,    28,    29,    30,    31, 
     32,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,    56,   477,   477,    59,   477,    61, 
     62,    63,   477,     2,    66,   477,     5,     6,   477,   477, 
    477,    10,   477,    12,    13,    14,   477,   477,    80,    18, 
     19,    20,   477,    22,    23,   477,    25,    26,   477,    28, 
     29,    30,    31,    32,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,    56,   477,   477, 
     59,   477,    61,    62,    63,   477,     2,    66,   477,     5, 
      6,   477,   477,   477,    10,   477,    12,    13,    14,   477, 
    477,    80,    18,    19,    20,   477,    22,    23,   477,    25, 
     26,   477,    28,    29,    30,    31,    32,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,    24,   477,   477, 
     56,    57,     2,   477,   477,     5,     6,    63,   477,    65, 
     10,    38,    12,    13,    14,   477,   477,    44,    18,    19, 
     20,   477,    22,    23,    80,    25,    26,   477,    28,    29, 
     30,    31,    32,   477,    61,    62,   477,   477,   477,    66, 
    477,   477,   477,    70,   477,   477,    73,    74,   477,   477, 
     77,    78,   477,    80,    81,    82,   477,   477,   477,    59, 
    477,    61,    62,   477,   477,     2,    66,   477,     5,     6, 
    477,   477,   477,    10,   477,    12,    13,    14,   477,   477, 
     80,    18,    19,    20,   477,    22,    23,   477,    25,    26, 
    477,    28,    29,    30,    31,    32,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,    59,   477,    61,    62,   477,   477,     2,    66, 
    477,     5,     6,   477,   477,   477,    10,   477,    12,    13, 
     14,   477,   477,    80,    18,    19,    20,   477,    22,    23, 
    477,    25,    26,   477,    28,    29,    30,    31,    32,   477, 
    477,     2,   477,   477,     5,     6,   477,   477,   477,    10, 
    477,    12,    13,    14,   477,   477,   477,    18,    19,    20, 
    477,    22,    23,    57,    25,    26,   477,    28,    29,    30, 
     31,    32,   477,   477,   477,   477,   477,   477,   477,     2, 
    477,   477,     5,     6,   477,   477,    80,    10,   477,    12, 
     13,    14,   477,   477,   477,    18,    19,    20,   477,    22, 
     23,    62,    25,    26,   477,    28,    29,    30,    31,    32, 
    477,   477,     2,   477,   477,     5,     6,   477,   477,    80, 
     10,   477,    12,    13,    14,   477,   477,   477,    18,    19, 
     20,   477,    22,    23,    57,    25,    26,   477,    28,    29, 
     30,    31,    32,   477,     2,   477,   477,     5,     6,   477, 
    477,    41,    10,   477,    12,    13,    14,    80,   477,   477, 
     18,    19,    20,   477,    22,    23,   477,    25,    26,   477, 
     28,    29,    30,    31,    32,     5,     6,   477,   477,   477, 
     10,   477,    12,   477,    14,   477,   477,   477,    18,    19, 
     80,   477,    22,    23,   477,   477,    26,   477,   477,    29, 
     30,    31,    32,   477,    62,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,    80,   477,   477,   477,   477,   477,   477,    59, 
    477,    61,    62,   477,    64,   477,    66,   477,     5,     6, 
    477,   477,   477,    10,   477,    12,   477,    14,   477,   477, 
     80,    18,    19,   477,   477,    22,    23,   477,   477,    26, 
    477,   477,    29,    30,    31,    32,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,    59,   477,    61,    62,   477,    64,   477,    66, 
    477,     5,     6,   477,   477,   477,    10,   477,    12,   477, 
     14,   477,   477,    80,    18,    19,   477,   477,    22,    23, 
    477,   477,    26,   477,   477,    29,    30,    31,    32,   477, 
    477,     5,     6,    24,   477,   477,    10,   477,    12,   477, 
     14,   477,   477,   477,    18,    19,   477,    38,    22,    23, 
    477,    24,    26,    44,    58,    29,    30,    31,    32,   477, 
    477,   477,   477,   477,   477,    38,    57,    58,   477,   477, 
     61,    44,   477,   477,   477,    66,    80,   477,    24,    70, 
    477,   477,    73,    74,    57,   477,    77,    78,    61,    80, 
     81,    82,    38,    66,   477,   477,    24,    70,    44,   477, 
     73,    74,   477,   477,    77,    78,    80,    80,    81,    82, 
     38,   477,   477,   477,    60,    61,    44,   477,   477,   477, 
     66,   477,   477,   477,    70,   477,   477,    73,    74,   477, 
    477,    77,    78,    61,    80,    81,    82,   477,    66,   477, 
    477,   477,    70,   477,   477,    73,    74,   477,   477,    77, 
     78,   477,    80,    81,    82,    34,    35,    36,    37,    38, 
     39,    40,   477,    42,    43,    44,    45,    46,    47,    48, 
     49,    50,    51,    52,    53,    54,    55,    56,   477,    58, 
     59,    60,    61,    62,    63,    64,    65,    66,    67,    68, 
     69,    70,    71,    72,    73,    74,    75,    76,   477,   477, 
     79,   477,   477,    82,    34,    35,    36,    37,    38,    39, 
     40,   477,    42,    43,    44,    45,    46,    47,    48,    49, 
     50,    51,    52,    53,    54,    55,    56,   477,    58,    59, 
     60,    61,    62,    63,    64,    65,    66,    67,    68,    69, 
     70,    71,    72,    73,    74,    75,    76,   477,   477,    79, 
     34,    35,    36,    37,    38,    39,    40,   477,    42,    43, 
     44,    45,    46,    47,    48,    49,    50,    51,    52,    53, 
     54,    55,    56,   477,   477,    59,   477,    61,   477,    63, 
     64,    65,    66,    67,    68,    69,    70,    71,    72,    73, 
     74,    75,    76,   477,   477,    79,    34,    35,    36,    37, 
    477,   477,    40,   477,    42,    43,   477,    45,    46,    47, 
     48,    49,    50,    51,    52,    53,    54,    55,    56,   477, 
     58,   477,    60,   477,    62,    63,   477,    65,    66,    67, 
     68,    69,    70,    71,    72,    73,    74,    75,    76,    36, 
     37,   477,   477,   477,   477,    42,    43,   477,    45,   477, 
     47,   477,   477,    50,   477,   477,    53,   477,   477,    56, 
    477,    58,   477,    60,   477,    62,    63,    64,   477,    66, 
     67,    68,    69,    70,    71,    72,    73,    74,    75,    76, 
     36,    37,   477,   477,   477,   477,    42,    43,   477,    45, 
    477,    47,   477,   477,    50,   477,   477,    53,   477,   477, 
     56,   477,    58,   477,    60,   477,    62,    63,    64,   477, 
     66,    67,    68,    69,    70,    71,    72,    73,    74,    75, 
     76,    36,    37,   477,   477,   477,   477,    42,    43,   477, 
     45,   477,    47,   477,   477,    50,   477,   477,    53,   477, 
    477,    56,   477,    58,   477,    60,   477,    62,    63,    64, 
    477,    66,    67,    68,    69,    70,    71,    72,    73,    74, 
     75,    76,    36,    37,   477,   477,   477,   477,    42,    43, 
    477,    45,   477,    47,   477,   477,    50,   477,   477,    53, 
    477,   477,    56,   477,    58,   477,    60,   477,    62,    63, 
     64,   477,   477,    67,    68,    69,    70,    71,    72,    73, 
     74,    36,    37,   477,   477,   477,   477,    42,    43,   477, 
     45,   477,    47,   477,   477,    50,   477,   477,    53,   477, 
    477,    56,   477,    58,   477,    60,   477,    62,    63,    64, 
    477,   477,    67,    68,    69,    70,    71,    72,    73,    74, 
     36,    37,   477,   477,   477,   477,    42,    43,   477,    45, 
    477,    47,   477,   477,    50,   477,   477,    53,   477,   477, 
     56,   477,    58,   477,    60,   477,    62,    63,    64,   477, 
    477,    67,    68,    69,    70,    71,    72,    73,    74,    36, 
     37,   477,   477,   477,   477,    42,    43,   477,    45,   477, 
     47,   477,   477,    50,   477,   477,    53,   477,   477,    56, 
    477,    58,   477,    60,   477,    62,    63,    64,   477,   477, 
     67,    68,    69,    70,    71,    72,    36,    37,   477,   477, 
    477,   477,    42,    43,   477,    45,   477,    47,   477,   477, 
     50,   477,   477,    53,   477,   477,    56,   477,    58,   477, 
     60,   477,    62,    63,    64,   477,   477,    67,    68,    69, 
     70,    71,    72,    36,    37,   477,   477,   477,   477,    42, 
     43,   477,    45,   477,    47,   477,   477,    50,   477,   477, 
     53,    70,   477,    56,   477,    58,   477,    60,   477,    62, 
     63,    64,   477,   477,    67,    68,    69,    70,    71,    72, 
     36,    37,   477,   477,   477,   477,    42,    43,   477,    45, 
     99,    47,   477,   477,    50,   477,   477,    53,   477,   477, 
     56,   477,    58,   477,    60,   477,    62,    63,    64,   477, 
    477,    67,    68,    69,    70,    71,    72,    36,    37,   477, 
    477,   477,   477,    42,    43,   477,    45,   477,    47,   477, 
    477,    50,   477,   477,    53,   477,   477,    56,   477,    58, 
    477,    60,   477,    62,    63,    64,   477,   477,    67,    68, 
     69,    70,    71,    72,    36,    37,    29,   477,   477,   477, 
     42,    43,   477,    45,   477,   477,   477,   477,    50,   477, 
    477,   477,   477,   477,    56,   477,    58,   477,    60,   477, 
     62,    63,    64,   477,   477,    67,    68,    69,    70,    71, 
     72,    36,    37,   477,   203,   477,    69,    42,    43,   477, 
     45,   477,   477,    76,   477,    50,   477,   477,   477,   477, 
    477,    56,   477,    58,   477,    60,   477,    62,    63,    64, 
    477,   477,    67,    68,    69,    70,    71,    72,    36,    37, 
    477,   477,   477,   477,    42,    43,   477,    45,   477,   477, 
    477,   477,    50,   477,   477,   477,   477,   477,    56,   477, 
     58,   477,    60,   477,    62,    63,    64,   477,   477,    67, 
     68,    69,    70,    71,    72,    36,    37,   477,   477,   477, 
    477,    42,   477,   477,   477,   477,   477,   477,    80,    50, 
     36,    37,   477,   477,   477,    56,    42,    58,    90,    60, 
    477,    62,    63,    64,    50,   477,    67,    68,    69,    70, 
     56,   477,    58,   477,    60,   477,    62,    63,    64,   477, 
    477,    67,    68,    69,    70,     0,   477,   326,   477,   328, 
    477,   477,   477,   477,   477,     0,   199,   477,   477,   477, 
    477,   477,   477,   206,   207,   208,   477,   477,   477,    24, 
    477,   477,   477,   477,    29,     0,   477,    32,    33,    24, 
    477,   153,   477,   155,    29,   477,   477,   477,    33,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,    24, 
    477,   477,   477,   477,    29,   477,   477,    62,   477,   477, 
    477,    56,    57,    58,    69,   477,   477,    62,   397,   477, 
    477,   477,   477,   477,    69,   477,    81,   477,   477,   477, 
    477,   477,   477,   477,   477,    80,   477,    62,    63,   477, 
    477,   477,    87,    97,    69,   288,   477,   426,   427,   428, 
    477,   477,    97,   108,   477,   477,   477,   229,   477,   477, 
    477,   477,   477,   108,   477,   444,    91,   477,   477,   124, 
    125,   126,   451,   128,   477,   454,   455,   477,   457,   477, 
    477,   477,   477,   108,   477,   477,   465,   477,   467,   468, 
    477,   477,   335,   336,   477,   474,   477,   340,   270,   271, 
    477,   477,   477,   477,   159,   477,   477,   477,   163,   477, 
    477,   477,   137,   477,   159,   477,   477,   477,   163,   477, 
    477,   477,    97,   477,   477,   170,   477,   477,   477,   477, 
    105,   477,   477,   477,   159,   477,   477,   477,   163,   477, 
    477,   477,   477,   477,   477,   200,   201,   202,   477,   204, 
    125,   126,   477,   128,   208,   477,   477,   477,   477,   213, 
    205,   404,   405,   477,   477,   140,   477,   477,   213,   477, 
    477,   477,   477,   477,   228,   477,   348,   477,   477,   477, 
    352,   477,   477,   477,   477,   230,   231,   477,   431,   432, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   448,   477,   477,   380,   452, 
    382,   477,   384,   477,   477,   477,   477,   272,   477,   477, 
    477,   477,   477,   477,   477,   280,   281,   282,   400,   401, 
    402,   276,   477,   208,   477,   280,   281,   477,   213,   477, 
    477,   477,   477,   477,   219,   477,   477,   272,   477,   421, 
    477,   296,   477,   228,   229,   477,   281,   477,   430,   477, 
    235,   477,   477,   477,   239,   477,   477,   477,   477,   477, 
    477,   443,   477,   445,   446,   447,   477,   331,   332,   333, 
    477,   335,   477,   477,   456,   477,   458,   459,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   469,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   373,   374, 
    477,   477,   477,   477,   379,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   389,   477,   477,   477,   477,   314, 
    365,   366,   477,   477,   389,   477,   477,   477,   403,   374, 
    404,   477,   477,   477,   477,   330,   331,   332,   333,   477, 
    335,   477,   477,   477,   389,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   429,   430,   477,   432,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   446,   447,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   459,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   404, 
    477,   477,   477,   477,   409,   477,   477,   477,   413,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   429,   430,   477,   432,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   446,   447,   477,   477,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   459,   477,   477,   477,   477,   477, 
    477,   477,   477,   477,   477,   477,   477,   477,   477,   477, 
    477,   477
};
static YYTest yyTests[18]= {
      1,     0,     1,     0,     1,     0,     1,     0,     1,     0, 
      1,     0,     1,     0,     1,     0,     1,     0
};
static YYAct yyTestActs[18]= {
    592,    18,   592,   791,   592,   493,   592,   495,   592,   497, 
    592,   789,   592,   789,   592,   531,   592,   533
};
#line 1747 "parse.c"

/*                PUBLIC MACROS NOT REDEFINABLE BY USER.                */

#define	YYACCEPT	do { yyRetVal= 0; goto yyTerminate; } while (0)
#define YYABORT		do { yyRetVal= 1; goto yyTerminate; } while (0)
#define YYEMPTY		YY_EMPTY_TOK
#define YYERROR		goto yyError
#define YYFAIL		goto yyFail
#define yyclearin	(YY_CHAR= YYEMPTY)
#define yyerrok		(yyErrShift= 0)
#define YYRECOVERING	(YY_CHAR == YY_ERR_TOK_VAL)
#define YY_ACCEPT_RULE	0

/*                        PRIVATE TYPES & MACROS                        */

/* Resynchronize after YY_CHAR is changed. */
#define YY_CHAR_SYNC							\
  do { yyTok= YY_TRANSLATE(YY_CHAR); } while (0)

/* Pseudo-error rule used to shift to error processing. */
#ifndef YY_ERR_RULE
#define YY_ERR_RULE (YY_N_RULES - 1)
#endif

/* Min. # of tokens shifted after an error before resignalling an error. */
#ifndef YY_ERR_SHIFT
#define YY_ERR_SHIFT 3
#endif

/* Max. size of stack before overflow. */
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Initial stack size.  Also used for stack increment. */
#ifndef YYINITDEPTH
#define YYINITDEPTH 200
#endif

#if (YY_HAS_LOC)
#ifndef YY_LOC
/* Default struct to maintain location information. */
#define YY_LOC 								\
  struct {								\
    int first_line;							\
    int last_line;							\
    int first_column;							\
    int last_column;							\
  }
#endif

typedef YY_LOC YYLoc;

#endif /* if (YY_HAS_LOC) */

typedef YYSTYPE YYSType;	/* Type for semantic values. */

typedef struct {		/* Stack type. */
  YYState state;		/* State stored in stack entry. */
  YYSType outVals;		/* Semantic value. */
#if (YY_HAS_IN_ATTRIBS)
  YYIn inVals;
#endif
#if (YY_HAS_LOC)
  YYLoc loc;			/* Location information. */
#endif
} YYStk;

#if YY_IS_TYPED
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals.type)
#else
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals)
#endif

#define YY_IN_VAR(offset, selector)	(yySP[offset].inVals.selector)
#define YY_OUT_VAR(offset, selector)	(yySP[offset].outVals.selector)
#if (YY_HAS_LOC)
#define YY_LOC_VAR(offset)		(yySP[offset].loc)
#endif

/*                      EXTERN SCANNER VARIABLES.                       */

#if (!YY_IS_PURE)
YYSTYPE YY_LVAL;		/* Semantic value of current token. */
int YY_CHAR= 0;			/* Current lookahead token (actual value). */
int YY_NERRS= 0;		/* Number of errors so far. */
#if (YY_HAS_LOC)
YYLoc yylloc;			/* Location information for current token. */
#endif
#if YYDEBUG
int YY_DEBUG= 0;		/* Flag to turn debug messages on/off. 	*/
#endif
#endif



/*                      CODE MACROS FOR YY_PARSE().                   */

/* Defines how yylex() is called. */
#ifndef YY_LEX_CALL
#if YY_IS_PURE
#if YY_HAS_LOC
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL, &yylloc)
#else
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL)
#endif
#else
#define YY_LEX_CALL()	YY_LEX()
#endif
#endif /* ifndef YY_LEX_CALL */

/* Translate external tokens from yylex() to internal tokens. */
#define YY_TRANSLATE(t)							\
  (((0 <= t) && (t) <= YY_MAX_TOK_VAL) ? yyTranslate[t] : YY_BAD_TOK)

/* Macros to decode acts stored in yyActNext[] & yyActDef[] tables. */
#define YY_IS_SHIFT(act)	((act) < YY_N_STATES)
#define YY_IS_REDUCE(act)	((act) >= YY_N_STATES)
#define YY_ACT_RULEN(act)	((act) - YY_N_STATES)
#define YY_ACT_STATE(act)	(act)

#define YY_GOTO_STATE(s, n)						\
  do {									\
    unsigned i= yyGotoBase[n] + (s);					\
    s= (yyCheck[i] == (s)) ? yyNext[i] : yyGotoDef[n];			\
  } while (0)

#define YY_SHIFT_LHS  yyState= (yySP++)->state

/* Stack size check & growing. */
#define YY_STK_CHK(mainBase, mainSP, size, inc)				\
  do {									\
    if ((mainSP - mainBase) >= (size))					\
      if (!(size= yyGrowStk(&mainBase, &mainSP, size + inc))) YYABORT;	\
  } while (0)

#if (YY_HAS_LOC)

/* Location info for disp from stack top. */
#define YY_STK_LOC(disp)	(yySP[disp].loc)

/* Location info for element on rule RHS with index rhsIndex (0= 1st, etc)
 * given that rule has length ruleLen.  Valid only at reduction.
 */
#define YY_RHS_LOC(rhsIndex, ruleLen)					\
  YY_STK_LOC(rhsIndex - ruleLen - 1)

#ifndef YY_UPDATE_LOC

/* Default method of computing location information in locZ, after
 * reducing by a rule having rule length ruleLen.
 */
#define YY_UPDATE_LOC(ruleLen, locZ)					\
  do {									\
    if (ruleLen) {							\
      YY_CONST YYLoc *YY_CONST locFirstP= &YY_RHS_LOC(0, ruleLen);	\
      YY_CONST YYLoc *YY_CONST locLastP= 				\
	&YY_RHS_LOC(ruleLen - 1, ruleLen);				\
      (locZ).first_line= locFirstP->first_line;				\
      (locZ).first_column= locFirstP->first_column;			\
      (locZ).last_line= locLastP->last_line; 				\
      (locZ).last_column= locLastP->last_column;			\
    }									\
    else { /* Use location of previous element. */			\
      (locZ)= YY_STK_LOC(-1);						\
    }									\
  } while (0)

#endif /* #ifndef YY_UPDATE_LOC */
#endif /* #if YY_HAS_LOC */


/*                        STACK GROWING ROUTINE.                        */
#if YY_PROTO
static YYUInt yyGrowStk (YYStk **mainBase, YYStk **mainSP, YYUInt newSize)
#else
static YYUInt yyGrowStk (mainBase, mainSP, newSize)
  YYStk **mainBase;
  YYStk **mainSP;
  YYUInt newSize;
#endif /* #if YY_PROTO */
{ 
  if (newSize > YYMAXDEPTH) {
    YY_ERROR("stack overflow"); 
    return 0;
  }
  else {
    YYUInt disp= *mainSP - *mainBase;
    if (!(*mainBase= (YYStk *)realloc(*mainBase, newSize * sizeof(YYStk)))) {
      YY_ERROR("out of memory");
      return 0;
    }
    *mainSP= *mainBase + disp;
    return newSize;
  }
}


/*                         DEBUG HELPER ROUTINES.                       */

#if YYDEBUG



#if YY_PROTO
static YY_CONST char *yySymName (YYUInt sym) 
#else
static YY_CONST char *yySymName (sym) 
  YYUInt sym;
#endif /* #if YY_PROTO */
{
  return ((YY_SYM_TYPE(sym) == YY_NON_TERM_SYM) 
	  ? yyNonTermNames 
	  : yyTokenNames)
	  [YY_SYM_NUM(sym)];	
}

#if YY_PROTO
static YY_VOID yyPrintRule (YYUInt ruleN) 
#else
static YY_VOID yyPrintRule (ruleN) 
  YYUInt ruleN;
#endif /* #if YY_PROTO */
{
  unsigned i;
  fprintf(stderr, "%s: ", yyNonTermNames[yyLHS[ruleN]]);
  for (i= yyRule[ruleN]; YY_SYM_TYPE(yySyms[i]) != YY_RULE_SYM; i++) {
    fprintf(stderr, "%s ",  yySymName(yySyms[i]));
  }
}

#endif /* #if YYDEBUG */


/*			DECLARATION FOR YY_PARSE.			*/

/* Name of formal parameter used to pass start non-terminal. */
#ifndef YY_START
#define YY_START yyStart
#endif

#ifndef YY_DECL

/* Define K&R declaration for YY_PARSE. */
#if YY_HAS_MULTI_START

#ifdef YYPARSE_PARAM
#define YY_DECL \
  int YY_PARSE(YY_START, YYPARSE_PARAM) int YY_START; YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE(YY_START) int YY_START;
#endif /* else !defined YYPARSE_PARAM */

#else /* !YY_HAS_MULTI_START */

#ifdef YYPARSE_PARAM
#define YY_DECL int YY_PARSE(YYPARSE_PARAM) YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE()
#endif /* else !defined YYPARSE_PARAM */

#endif /* else !YY_HAS_MULTI_START */

#endif /* #ifndef YY_DECL */


/*			MAIN PARSER FUNCTION.				*/

YY_DECL
{
  enum { YY_STK_INC= YYINITDEPTH };
  /* malloc() initially, as some reallocs have problems with NULL 1st arg. */
  YYStk *yyStk= (YYStk *)malloc(YY_STK_INC * sizeof(YYStk)); /* Stack base. */	
  YYStk *yySP= yyStk;					/* Main stk. ptr. */
  YYUInt yyStkSize= YY_STK_INC;	/* Current size of main & location stks. */
#if YY_HAS_MULTI_START
  YYState yyState= YY_START;	/* Current parser state. */
#else
  YYState yyState= 0;		/* Current parser state. */
#endif
  YYTok yyTok= YYEMPTY;		/* Translated value of current lookahead. */
  int yyCharSave= 0;		/* Saved value of yyChar in error processing. */
  YY_CONST YYTok yyErrTok= 	/* Token error. */
    YY_TRANSLATE(YY_ERR_TOK_VAL);
  YYUChar yyErrShift= 0;	/* # of tokens to be shifted when error. */
  YYUChar yyRetVal;		/* Value to be returned by yyparse(). */
#if YY_IS_PURE
  YYSType YY_LVAL;		/* Lexical semantic value. */
  int YY_CHAR;			/* Current lookahead token (actual value). */
  int YY_NERRS= 0;		/* Number of errors. */
#if (YY_HAS_LOC)
  YYLoc yylloc;			/* Lexical location value. */
#endif
#endif
  /* Local definitions from user. */
#line 2043 "parse.c"
  /* Confirm initial stack allocation ok. */
  if (!yyStk) 
    YY_ERROR("Out of memory.");	/* Initial stk. allocation failed. */

  yySP->state= yyState; yySP++;		/* Push initial state. */

  while (1) {				/* Terminate only via return. */
    YYUInt yyRuleN;			/* Rule # used for reduction. */

    assert(yyState == yySP[-1].state);	/* yyState mirrors state on TOS. */

    /* yyTok & YY_CHAR must agree. */
    assert(yyTok == YYEMPTY || yyTok == YY_TRANSLATE(YY_CHAR)); 

#if YYDEBUG
    if (YY_DEBUG != 0) {
      YYStk *p;	/* Spew out stack. */
      fprintf(stderr, "[ ");
      for (p= (YY_DEBUG > 0 || yySP + YY_DEBUG < yyStk) 
              ? yyStk 
	      : yySP + YY_DEBUG;
	   p < yySP; p++) {
	YY_CONST YYUInt s= p->state;
	fprintf(stderr, "%d/%s ", s, yySymName(yyAccess[s]));
      }
      fprintf(stderr, "] ");
    }
#endif
    /* Ensure space for at least 1 more stack entry. */
    YY_STK_CHK(yyStk, yySP, yyStkSize, YY_STK_INC);
#if YY_HAS_IN_ATTRIBS
    switch (yyState) { /* Don't check for non-empty reduction. */
	case 0:
YY_IN_VAR(-1, yyC_1.yyT_1)= ID_DCL;
YY_IN_VAR(-1, yyC_2.yyT_1)= ID_DCL;
	break;
	case 24:
YY_IN_VAR(-1, yyC_1.yyT_1)= ID_DCL;
YY_IN_VAR(-1, yyC_2.yyT_1)= ID_DCL;
	break;
	case 28:
YY_IN_VAR(-1, yyC_0.yyT_0)= FN_COUNTER;
	break;
	case 29:
YY_IN_VAR(-1, yyC_1.yyT_1)= YY_OUT_VAR(-1, yy_declaration_specifiers.dclType);
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_OUT_VAR(-1, yy_declaration_specifiers.dclType);
	break;
	case 33:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_IN_VAR(-2, yyC_1.yyT_1);
	break;
	case 62:
YY_IN_VAR(-1, yyC_1.yyT_1)= YY_IN_VAR(-2, yyC_2.yyT_1);
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_IN_VAR(-2, yyC_2.yyT_1);
	break;
	case 68:
YY_IN_VAR(-1, yyC_0.yyT_0)= FN_COUNTER;
	break;
	case 69:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_OUT_VAR(-1, yy_declaration_specifiers.dclType);
YY_IN_VAR(-1, yyC_1.yyT_1)= YY_OUT_VAR(-1, yy_declaration_specifiers.dclType);
	break;
	case 70:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_0.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= (
YY_IN_VAR(-2, yyC_0.yyT_0)) == STMT_COUNTER ? COMPOUND_COUNTER : (
YY_IN_VAR(-2, yyC_0.yyT_0));
	break;
	case 74:
YY_IN_VAR(-1, yyC_0.yyT_0)= FN_COUNTER;
	break;
	case 97:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_OUT_VAR(-2, yy_lbrace.scope);
	break;
	case 98:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_OUT_VAR(-2, yy_lbrace.scope);
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_OUT_VAR(-1, yy_statement_list.counterZ);
YY_IN_VAR(-1, yyC_0.yyT_0)= (
YY_OUT_VAR(-1, yy_statement_list.counterZ)) == STMT_COUNTER ? COMPOUND_COUNTER : (
YY_OUT_VAR(-1, yy_statement_list.counterZ));
	break;
	case 99:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_OUT_VAR(-2, yy_lbrace.scope);
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-3, yyC_0.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= (
YY_IN_VAR(-3, yyC_0.yyT_0)) == STMT_COUNTER ? COMPOUND_COUNTER : (
YY_IN_VAR(-3, yyC_0.yyT_0));
	break;
	case 104:
YY_IN_VAR(-1, yyC_0.yyT_0)= FN_COUNTER;
	break;
	case 108:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_IN_VAR(-3, yyC_2.yyT_1);
YY_IN_VAR(-1, yyC_1.yyT_1)= YY_IN_VAR(-3, yyC_2.yyT_1);
	break;
	case 159:
YY_IN_VAR(-1, yyC_1.yyT_1)= YY_OUT_VAR(-1, yy_declaration_specifiers.dclType);
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_OUT_VAR(-1, yy_declaration_specifiers.dclType);
	break;
	case 163:
YY_IN_VAR(-1, yyC_1.yyT_1)= OTHER_DCL;
YY_IN_VAR(-1, yyC_2.yyT_1)= OTHER_DCL;
	break;
	case 188:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-3, yyC_1.yyT_0);
	break;
	case 189:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-3, yyC_1.yyT_0);
	break;
	case 190:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-3, yyC_1.yyT_0);
	break;
	case 191:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-3, yyC_1.yyT_0);
	break;
	case 192:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-3, yyC_1.yyT_0);
	break;
	case 203:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 215:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_OUT_VAR(-3, yy_lbrace.scope);
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_OUT_VAR(-1, yy_statement_list.counterZ);
YY_IN_VAR(-1, yyC_0.yyT_0)= (
YY_OUT_VAR(-1, yy_statement_list.counterZ)) == STMT_COUNTER ? COMPOUND_COUNTER : (
YY_OUT_VAR(-1, yy_statement_list.counterZ));
	break;
	case 224:
YY_IN_VAR(-1, yyC_1.yyT_0)= COND_COUNTER;
	break;
	case 280:
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_IN_VAR(-2, yyC_1.yyT_1);
	break;
	case 281:
YY_IN_VAR(-1, yyC_1.yyT_1)= YY_IN_VAR(-2, yyC_2.yyT_1);
YY_IN_VAR(-1, yyC_2.yyT_1)= YY_IN_VAR(-2, yyC_2.yyT_1);
	break;
	case 326:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 328:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 389:
YY_IN_VAR(-1, yyC_1.yyT_1)= OTHER_DCL;
YY_IN_VAR(-1, yyC_2.yyT_1)= OTHER_DCL;
	break;
	case 397:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 410:
YY_IN_VAR(-1, yyC_1.yyT_0)= COND_COUNTER;
	break;
	case 426:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 427:
YY_IN_VAR(-1, yyC_1.yyT_0)= NO_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
NO_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
NO_COUNTER);
	break;
	case 428:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 444:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 449:
YY_IN_VAR(-1, yyC_1.yyT_0)= COND_COUNTER;
	break;
	case 451:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 454:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 455:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 457:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 465:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 467:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 468:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
	case 470:
YY_IN_VAR(-1, yyC_1.yyT_0)= COND_COUNTER;
	break;
	case 474:
YY_IN_VAR(-1, yyC_1.yyT_0)= STMT_COUNTER;
YY_IN_VAR(-1, yyC_0.yyT_0)= (
STMT_COUNTER) == STMT_COUNTER ? COMPOUND_COUNTER : (
STMT_COUNTER);
	break;
#line 2287 "parse.c"
    }	
#endif /* #if YY_HAS_IN_ATTRIBS */
    { /* Lookup action table & branch either to yyShift or yyReduce. */
      YY_CONST YYUInt base= yyActBase[yyState];
      if (base == YY_BAD_BASE) { 
	yyRuleN= yyActDef[yyState];		/* Use default entry */
	goto yyReduce;
      }
      else { /* Use lookahead to consult yyNext[] & yyCheck[]. */
	YYUInt index;
	if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	  YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
	}
	index= base + yyTok;
	if (yyCheck[index] == yyTok) {
	  YY_CONST YYUInt act= yyNext[index];
	  if (YY_IS_REDUCE(act)) {
            yyRuleN= YY_ACT_RULEN(act); goto yyReduce;
	  }
	  else {
	    yyState= YY_ACT_STATE(act); goto yyShift;
	  }
	}
	else {
	  yyRuleN= yyActDef[yyState]; goto yyReduce;
	}
      }
    }

  yyShift:	/* Begin shift action. */
#if YYDEBUG
    if (YY_DEBUG != 0) {
      fprintf(stderr, "%s: SHIFT %d\n", yyTokenNames[yyTok], yyState);
    }
#endif
    /* Push state on stack. */
    yySP->state= yyState; yySP->outVals= YY_LVAL; 
#if (YY_HAS_LOC)
    yySP->loc= yylloc;
#endif
    yySP++;

    if (yyErrShift) {	/* Error processing in shift action. */
      if (yyTok == yyErrTok) { 	/* We successfully shifted error. */
	assert(yyErrShift == YY_ERR_SHIFT); /* No normal tokens shifted. */
	YY_CHAR= yyCharSave; YY_CHAR_SYNC; /* Restore original lookahead. */
      }
      else {			/* Successful shift of normal token. */
	yyErrShift--;		/* 1 fewer token to shift before resignal. */
	yyTok= YYEMPTY;
      }
    }
    else {
      yyTok= YYEMPTY;	/* Clear shifted token. */
    }
    continue;	/* End shift action. Continue while(1) loop.  */

  yyReduce: 	/* Begin reduce action. */
#if YY_N_TESTS > 0
    if (yyRuleN >= YY_N_RULES) { /* Test action. */
      int yyResult= 0; 	/* Or of tests tested so far. */
      YYUInt yyT;	/* Indexes yyTests[] and yyTestActs[]. */	
      if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
      }
      for (yyT= yyRuleN - YY_N_RULES; yyTests[yyT] > 0; yyT++) {
	switch (yyTests[yyT]) {
	  case 1:
	    yyResult= !G.seenType && isTypedef();
	  break;
#line 2358 "parse.c"
	}
	if (yyResult) break;
      }
      { YY_CONST YYUInt act= yyTestActs[yyT];
        if (YY_IS_SHIFT(act)) {
	  yyState= YY_ACT_STATE(act); goto yyShift;
        }
        else {
	  yyRuleN= YY_ACT_RULEN(act);
	  assert(yyRuleN < YY_N_RULES);
        }
      }
    }
#endif /* if YY_N_TESTS > 0 */
    { YYUInt yyDefault= 0;	/* 1 if default action. */

#if YYDEBUG
      if (YY_DEBUG != 0) {
        fprintf(stderr, "%s: ", yyTokenNames[yyTok]);
        if (yyRuleN == YY_ERR_RULE || yyTok == yyErrTok) {
	  fprintf(stderr, "ERROR");
        }
        else if (yyRuleN == YY_ACCEPT_RULE) {
	  fprintf(stderr, "ACCEPT." );
        }
        else {
	  fprintf(stderr, "REDUCE %d ", yyRuleN);
	  yyPrintRule(yyRuleN); 
        }
        fprintf(stderr, "\n");
      }
#endif
      if (yyTok == yyErrTok) goto yyFail; /* error triggered a default redn. */
      switch (yyRuleN) {	/* Perform relevant user or default action. */
	/* Use yySP->outVals as temporary to store new semantic value. */
	case YY_ACCEPT_RULE:	/* Accepting rule. */
	  YYACCEPT; break;
	/* User actions go here. */
	case 15:
#define yyYYdclType YY_OUT_VAR(-1, yy_declaration_specifiers_x.dclType)
#line 168 "parse.y"
{ G.seenType= FALSE; }
YY_OUT_VAR(0, yy_declaration_specifiers.dclType)= yyYYdclType;
#undef yyYYdclType
	break;
	case 16:
#define yyYYdclType YY_OUT_VAR(-1, yy_storage_class_specifier.dclType)
YY_OUT_VAR(0, yy_declaration_specifiers_x.dclType)= yyYYdclType;
#undef yyYYdclType
	break;
	case 17:
#define yyYYdclType YY_OUT_VAR(0, yy_declaration_specifiers_x.dclType)
#define yyYYdclType1 YY_OUT_VAR(-2, yy_storage_class_specifier.dclType)
#define yyYYdclType2 YY_OUT_VAR(-1, yy_declaration_specifiers_x.dclType)
#line 175 "parse.y"
{ yyYYdclType= (yyYYdclType1 == TYPEDEF_DCL || yyYYdclType2 == TYPEDEF_DCL)
                    ? TYPEDEF_DCL
                    : ID_DCL; 
	}
#undef yyYYdclType
#undef yyYYdclType1
#undef yyYYdclType2
	break;
	case 18:
#define yyYYdclType YY_OUT_VAR(0, yy_declaration_specifiers_x.dclType)
#line 180 "parse.y"
{ yyYYdclType= ID_DCL; }
#undef yyYYdclType
	break;
	case 19:
#define yyYYdclType YY_OUT_VAR(-1, yy_declaration_specifiers_x.dclType)
YY_OUT_VAR(0, yy_declaration_specifiers_x.dclType)= yyYYdclType;
#undef yyYYdclType
	break;
	case 20:
#define yyYYdclType YY_OUT_VAR(0, yy_declaration_specifiers_x.dclType)
#line 183 "parse.y"
{ yyYYdclType= ID_DCL; }
#undef yyYYdclType
	break;
	case 21:
#define yyYYdclType YY_OUT_VAR(-1, yy_declaration_specifiers_x.dclType)
YY_OUT_VAR(0, yy_declaration_specifiers_x.dclType)= yyYYdclType;
#undef yyYYdclType
	break;
	case 22:
#define yyYYdclType YY_OUT_VAR(0, yy_storage_class_specifier.dclType)
#line 189 "parse.y"
{ yyYYdclType= TYPEDEF_DCL; }
#undef yyYYdclType
	break;
	case 23:
#define yyYYdclType YY_OUT_VAR(0, yy_storage_class_specifier.dclType)
#line 191 "parse.y"
{ yyYYdclType= ID_DCL; }
#undef yyYYdclType
	break;
	case 24:
#define yyYYdclType YY_OUT_VAR(0, yy_storage_class_specifier.dclType)
#line 193 "parse.y"
{ yyYYdclType= ID_DCL; }
#undef yyYYdclType
	break;
	case 25:
#define yyYYdclType YY_OUT_VAR(0, yy_storage_class_specifier.dclType)
#line 195 "parse.y"
{ yyYYdclType= ID_DCL; }
#undef yyYYdclType
	break;
	case 26:
#define yyYYdclType YY_OUT_VAR(0, yy_storage_class_specifier.dclType)
#line 197 "parse.y"
{ yyYYdclType= ID_DCL; }
#undef yyYYdclType
	break;
	case 27:
#line 202 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 28:
#line 204 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 29:
#line 206 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 30:
#line 208 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 31:
#line 210 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 32:
#line 212 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 33:
#line 214 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 34:
#line 216 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 35:
#line 218 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 36:
#line 220 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 37:
#line 222 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 38:
#line 224 "parse.y"
{ G.seenType= TRUE; }
	break;
	case 53:
#line 264 "parse.y"
{ G.seenType= FALSE; }
	break;
	case 73:
#define yyYYdclType YY_IN_VAR(-2, yyC_2.yyT_1)
#define yyYYid YY_OUT_VAR(-1, yy_ID.id)
#line 312 "parse.y"
{ if (yyYYdclType != OTHER_DCL) dclTypedef(yyYYid, yyYYdclType == TYPEDEF_DCL);
	}
#undef yyYYdclType
#undef yyYYid
	break;
	case 114:
#line 392 "parse.y"
{ 
#if  TEST_TYPEDEF
         printf("*"); 
#endif
       }
	break;
	case 116:
#define yyYYcounterZ YY_OUT_VAR(-2, yy_labeled_statement.counterZ)
YY_OUT_VAR(0, yy_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 117:
#define yyYYcounterZ YY_OUT_VAR(0, yy_statement.counterZ)
#line 406 "parse.y"
{ yyYYcounterZ= NO_COUNTER; }
#undef yyYYcounterZ
	break;
	case 118:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_compound_statement.counterZ)
YY_OUT_VAR(0, yy_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 119:
#define yyYYcounterZ YY_OUT_VAR(0, yy_statement.counterZ)
#line 411 "parse.y"
{ yyYYcounterZ= STMT_COUNTER; }
#undef yyYYcounterZ
	break;
	case 120:
#define yyYYcounterZ YY_OUT_VAR(0, yy_statement.counterZ)
#line 414 "parse.y"
{ yyYYcounterZ= STMT_COUNTER; }
#undef yyYYcounterZ
	break;
	case 121:
#define yyYYcounterZ YY_OUT_VAR(0, yy_statement.counterZ)
#line 416 "parse.y"
{ yyYYcounterZ= NO_COUNTER; }
#undef yyYYcounterZ
	break;
	case 122:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_labeled_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 123:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_labeled_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 124:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_labeled_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 127:
#define yyYYcounterZ YY_OUT_VAR(0, yy_compound_statement.counterZ)
#line 432 "parse.y"
{ yyYYcounterZ= NO_COUNTER; }
#undef yyYYcounterZ
	break;
	case 128:
#define yyYYcounterZ YY_OUT_VAR(-2, yy_statement_list.counterZ)
YY_OUT_VAR(0, yy_compound_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 129:
#define yyYYcounterZ YY_OUT_VAR(0, yy_compound_statement.counterZ)
#line 435 "parse.y"
{ yyYYcounterZ= NO_COUNTER; }
#undef yyYYcounterZ
	break;
	case 130:
#define yyYYcounterZ YY_OUT_VAR(-2, yy_statement_list.counterZ)
YY_OUT_VAR(0, yy_compound_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 131:
#define yyYYscope YY_OUT_VAR(0, yy_lbrace.scope)
#line 443 "parse.y"
{ yyYYscope= beginScope(); }
#undef yyYYscope
	break;
	case 132:
#define yyYYscope YY_IN_VAR(-2, yyC_2.yyT_1)
#line 448 "parse.y"
{ endScope(yyYYscope); }
#undef yyYYscope
	break;
	case 133:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_statement_list.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 134:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_statement_list.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 135:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_needs_counter_statement.counterZ)
YY_OUT_VAR(0, yy_selection_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 136:
#define yyYYcounterZ YY_OUT_VAR(0, yy_selection_statement.counterZ)
#define yyYYcounterT YY_OUT_VAR(-3, yy_needs_counter_statement.counterZ)
#define yyYYcounterE YY_OUT_VAR(-1, yy_statement.counterZ)
#line 461 "parse.y"
{ yyYYcounterZ= (yyYYcounterT == NO_COUNTER) ? yyYYcounterE : yyYYcounterT; }
#undef yyYYcounterZ
#undef yyYYcounterT
#undef yyYYcounterE
	break;
	case 137:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_selection_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 138:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_needs_counter_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 139:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 140:
#define yyYYcounterZ YY_OUT_VAR(-6, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 141:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 142:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 143:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 144:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 145:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 146:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 147:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 148:
#define yyYYcounterZ YY_OUT_VAR(-1, yy_statement.counterZ)
YY_OUT_VAR(0, yy_iteration_statement.counterZ)= yyYYcounterZ;
#undef yyYYcounterZ
	break;
	case 230:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 645 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 231:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 650 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 232:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 655 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 233:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 660 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 234:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 665 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 235:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 670 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 236:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 675 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 237:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 680 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 238:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 685 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 239:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 690 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 240:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 695 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 241:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 700 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 242:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 705 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 243:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 710 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 244:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 715 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 245:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 720 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 246:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 725 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 247:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 730 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 248:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 735 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 249:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 740 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 250:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 745 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 251:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 750 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 252:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 755 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 253:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 760 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 254:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 765 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 255:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 770 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 256:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 775 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 257:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 780 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 258:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 785 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 259:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 790 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 260:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 795 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 261:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 800 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 262:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 805 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 263:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 810 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 264:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 815 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 265:
#define yyYYid YY_OUT_VAR(0, yy_ID.id)
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 820 "parse.y"
{ yyYYid= yyYYt.id; OUT(yyYYt); 
#if TEST_TYPEDEF
	  printf(" %s", getIDString(yyYYid)); 
#endif
        }
#undef yyYYid
#undef yyYYt
	break;
	case 266:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 829 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 267:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 834 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 268:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 839 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 269:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 844 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 270:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 849 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 271:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 854 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 272:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 859 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 273:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 864 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 274:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 869 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 275:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 874 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 276:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 879 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 277:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 884 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 278:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 889 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 279:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 894 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 280:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 899 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 281:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 904 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 282:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 909 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 283:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 914 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 284:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 919 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 285:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 924 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 286:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 929 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 287:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 934 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 288:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 939 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 289:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 944 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 290:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 949 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 291:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 954 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 292:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 959 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 293:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 964 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 294:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 969 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 295:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 974 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 296:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 979 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 297:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 984 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 298:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 989 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 299:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 994 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 300:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 999 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 301:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1004 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 302:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1006 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 303:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1011 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 304:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1016 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 305:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1021 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 306:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1026 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 307:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1031 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 308:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1036 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 309:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1041 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 310:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1046 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 311:
#define yyYYt YY_OUT_VAR(-1, tok.t)
#line 1051 "parse.y"
{ OUT(yyYYt); }
#undef yyYYt
	break;
	case 312:
#define yyYYcounter0 YY_IN_VAR(-1, yyC_1.yyT_0)
#line 1057 "parse.y"
{ beginCounter(yyYYcounter0); }
#undef yyYYcounter0
	break;
	case 313:
#define yyYYcounter0 YY_IN_VAR(-1, yyC_1.yyT_0)
#line 1062 "parse.y"
{ endCounter(yyYYcounter0); }
#undef yyYYcounter0
	break;
#line 3221 "parse.c"
	case YY_ERR_RULE:	/* "Rule" used to break to a parse error. */
	  goto yyError;
	default:		/* Perform default action. */
	  yyDefault= 1;		/* Set flag to indicate no semantic copy. */
	  break;
      }
      {	YYLen yyLen= yyLength[yyRuleN];	/* Length of reducing rule. */
      	YYNonTerm yyN= yyLHS[yyRuleN];	/* LHS nonTerm #. */
      	YYStk *yyReduceP= yySP - yyLen;	/* Point to stack entry for rule LHS. */
#if YY_HAS_LOC
	YY_UPDATE_LOC(yyLen, yySP->loc); /* Use yySP->loc as temp. entry. */
#endif
        /* Update semantic value and location info. for LHS stk. location. */
        if (yyLen > 0) { /* Stack location for rule LHS not at yySP. */
#if YY_HAS_LOC
	  yyReduceP->loc= yySP->loc; 	/* Copy tmp. loc. entry to loc. stk. */
#endif
	  if (!yyDefault) {		/* Semantic copy definitely required. */
	    yyReduceP->outVals= yySP->outVals;	/* Do semantic copy. */
	  }
        } /* if (yyLen > 0) */
        /* Compute new state. */
        assert(yyStk < yyReduceP);
        yyState= yyReduceP[-1].state;	/* Set yyState to uncovered state. */
        YY_GOTO_STATE(yyState, yyN);	
        yyReduceP->state= yyState;
        yySP= yyReduceP + 1;		/* Pop stack. */
      } /* YYLen yyLen= yyLeng[yyRuleN]; */
    } /* Reduce action: YYUInt yyDefault= 0; */
    continue;	/* End reduce action. Continue with while(1) loop.  */
  yyError:
    if (!yyErrShift) { YY_ERROR("parse error"); YY_NERRS++; }
  yyFail:
    if (!yyErrShift) { 		/* Must have just gotten an error. */
      yyErrShift= YY_ERR_SHIFT;	/* # of tokens to shift before next error. */
      yyCharSave= YY_CHAR;
      YY_CHAR= YY_ERR_TOK_VAL; YY_CHAR_SYNC;
    }
    else if (yyTok == yyErrTok) { /* We need to pop current state. */
      yySP--; 
      if (yySP == yyStk) YYABORT;
      yyState= yySP[-1].state; 
    }
    else if (yyErrShift == YY_ERR_SHIFT) { /* No tokens shifted after error. */
      if (YY_CHAR == 0) YYABORT;	/* Quit at EOF. */
      YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
    }
    else { /* We got a second error within YY_ERR_SHIFT tokens. */
      yyErrShift= 0; goto yyFail;
    }
    continue;	/* End error processing. */
  }  /* while (1) */
yyTerminate:
  free(yyStk);
  return yyRetVal;
}

/* 			SECTION 3 CODE					*/

#line 1066 "parse.y"



/*				IDENTIFIERS				*/

/* 

Keep track of whether an identifier is a typedef or not.

I really need to get a hashtable module into libz.  If I write another
one of these, I'll be ready to scream.

*/
 
 


typedef struct {
  Index id;		/* identifier stored in this entry */
  Index succ;		/* next entry in hash chain */
  Boolean isTypedef;	/* true if entry is a typedef */
} IDEntry;

static AREAX(idEntries, IDEntry, 6, 0xFFFF);
#define ID_ENTRIES(i)	AX_ACCESS(idEntries, IDEntry, (i))

enum { IDS_HASH_SIZE= 512 };
static Index ids[IDS_HASH_SIZE];
#define HASH(id)	((id) % IDS_HASH_SIZE)

static VOID
initIDs()
{
  Index i;
  for (i= 0; i < IDS_HASH_SIZE; i++) ids[i]= NIL;
}



static VOID 
dclTypedef(id, isTypedef)
  Index id;
  Boolean isTypedef;
{
  CONST Index h= HASH(id);
  CONST Index i= AX_NEXT(idEntries);
  ID_ENTRIES(i).id= id; ID_ENTRIES(i).isTypedef= isTypedef;
  ID_ENTRIES(i).succ= ids[h]; ids[h]= i;
  VOID_RET();
}

static Boolean 
isTypedef()
{
  CONST Index id= yylval.tok.t.id;
  CONST Index h= HASH(id);
  Index i;
  assert(yychar == ID_TOK);
  for (i= ids[h]; i != NIL; i= ID_ENTRIES(i).succ) {
    if (ID_ENTRIES(i).id == id) return ID_ENTRIES(i).isTypedef;
  }
  return FALSE;
}

static Index
beginScope()
{
  return AX_NENTRIES(idEntries);
}

static VOID
endScope(scope)
  Index scope;
{
  Index i;
  for (i= AX_NENTRIES(idEntries); i > scope; i--) {
    /* unlink entries from front of their hash chains */
    Index j= i - 1;
    CONST Index h= HASH(ID_ENTRIES(j).id);
    assert(ids[h] == j);
    ids[h]= ID_ENTRIES(j).succ;
  }
  AX_CUT(idEntries, scope);
}


/*			     MAIN PROGRAM				*/

static Options options;
CONST Options *CONST optionsP= &options;

OptInfo optTab[]= {
  /* LongOpt Name, ShortOpt Name, Argument Type, User ID, CheckP, ValP,
   * OptFn, Doc
   */

  OPT_ENTRY("cond", 'c', NO_OPT_FLAG, COND_OPT,	NULL,
	     (VOIDP) &options.isCond, yesNoOptFn,
            "\
--cond | -c          Profile subexpressions of a ?: conditional expression\n\
                     (default: `0').\n\
"
  ),

  OPT_ENTRY("help", 'h', NO_OPT_FLAG, HELP_OPT,	NULL, NULL,
	     helpOptFn,
            "\
--help | -h          Print summary of options and exit.\n\
"
  ),

  OPT_ENTRY("prefix", 'p', REQUIRED_OPT_FLAG, PREFIX_OPT, NULL,
	    (VOIDP) &options.prefix, stringOptFn,
    "\
--prefix=PREFIX |    Use PREFIX as prefix of all generated names in\n\
 -p PREFIX           instrumented file (default: `_BB').\n\
"
  ),

  OPT_ENTRY("preprocess", 'P', NO_OPT_FLAG, PREPROCESS_OPT, NULL,
	    (VOIDP) &options.isPreprocess, yesNoOptFn,
    "\
--preprocess | -P    Run preprocessor (given by environmental var CPP) on\n\
                     input file (default: `1').\n\
"
  ),

  OPT_ENTRY("silent", 's', NO_OPT_FLAG, SILENT_OPT, NULL,
	    (VOIDP) &options.isSilent, yesNoOptFn,
    "\
--silent | -s        Do not generate error messages (default: `0').\n\
"
  ),

  OPT_ENTRY("verbose", 'v', NO_OPT_FLAG, VERSION_OPT, NULL,
	    NULL, versionOptFn,
    "\
--version | -v       Print version information and exit.\n\
"
  ),

  OPT_ENTRY("typedef", 't', REQUIRED_OPT_FLAG, TYPEDEF_OPT, NULL,
	    NULL, typedefOptFn,
    "\
--typedef=ID |       Declare identifier ID to be a typedef in the global\n\
 -t ID               scope.\n\
"
  )

};


static Int 
helpOptFn(id, checkP, valP, argP)
  Int id; 
  VOIDP checkP;
  VOIDP valP;
  ConstString argP;
{
  allOptsHelp(NULL, "Usage: zprof [options] lex-file.", 
	      optTab, N_ELEMENTS(optTab));
  exit(0);
  return 0;
}

static Int 
typedefOptFn(id, checkP, valP, argP)
  Int id;
  VOIDP checkP;
  VOIDP valP;
  ConstString argP;
{
  dclTypedef(getID(argP, strlen(argP)), TRUE);
  return 0;
}

#ifndef VERSION
#define VERSION	"0.0"
#endif

static Int 
versionOptFn(id, checkP, valP, argP)
  Int id; 
  VOIDP checkP;
  VOIDP valP;
  ConstString argP;
{
  fprintf(stderr, "zprof version %s\n", VERSION);
  exit(0);
  return 0;
}

#ifndef SIGNATURE
#define SIGNATURE "Zerksis"
#endif

/* Insert signature string into executable to permit distinguishing it
 * from other executables of the same name.
 */
char uniqueSignature[]= SIGNATURE;

int 
main(int argc, ConstString argv[]) 
{
  int i, n;
#if YYDEBUG
  yydebug= 1;
#endif
  initOut();
  initScan();
  initIDs();
  options.prefix= "_BB"; options.isPreprocess= 1;
  n= parseOpt(NULL, argc, argv, optTab, N_ELEMENTS(optTab));
  if (n < 0 || n >= argc) {
    allOptsHelp(NULL, "Usage: zprof [options] lex-file.", 
	        optTab, N_ELEMENTS(optTab));
    exit(1);
  }
  for (i= n; i < argc; i++) {
    newFile(argv[i]);
    beginOutFile(argv[i]);
    beginScope();
    if (yyparse() != 0) {
      fatal("could not recover from parse errors.");
    }
    putOut(&yylval.tok.t);
    endOutFile();
    endScope(0);
  }
  terminateScan();
  terminateOut();
  return 0;
}


#line 3516 "parse.c"
