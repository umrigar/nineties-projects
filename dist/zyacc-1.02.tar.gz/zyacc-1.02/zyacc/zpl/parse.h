/* Automatically generated from parse.y by zyacc version 1.02. */
#ifndef _YY_DEFS_H
#define _YY_DEFS_H

typedef union {
  struct {
    Index2 id;
  } name;
  struct {
    long num;
  } natNum;
  struct {
    double num;
  } realNum;
  struct {
    int n;
  } yy_Term;
  struct {
    int n;
  } yy_PrefixOpAtom;
  struct {
    int n;
  } yy_PrefixTerm;
  struct {
    int n;
  } yy_InfixTerm;
  struct {
    int n;
  } yy_SuffixTerm;
  struct {
    int nArgs;
  } yy_Arguments;
  struct {
    int m;
  } yy_Term999;
  struct {
    Index id;
    int n;
  } yy_FXOp;
  struct {
    Index id;
    int n;
  } yy_FYOp;
  struct {
    Index id;
    int n;
  } yy_XFXOp;
  struct {
    Index id;
    int n;
  } yy_XFYOp;
  struct {
    Index id;
    int n;
  } yy_YFXOp;
  struct {
    Index id;
    int n;
  } yy_XFOp;
  struct {
    Index id;
    int n;
  } yy_YFOp;
} YYSTYPE;

typedef struct {
  union {
    /* Term.max XFOp.max YFOp.max */
    int yyT_0;
  } yyC_0;
  union {
    /* PrefixOpAtom.max YFXOp.max XFYOp.max XFXOp.max FYOp.max 
     * FXOp.max SuffixTerm.max InfixTerm.max PrefixTerm.max 
     */
    int yyT_0;
  } yyC_1;
} YYIn;
extern YYSTYPE yylval;
#define NAME_TOK 257
#define VAR_TOK 258
#define NAT_NUM_TOK 259
#define STR_CHAR_TOK 260
#define REAL_NUM_TOK 261
#define WS_LPAREN_TOK 262
#define FULL_STOP_TOK 263
#define LEX_ERR_TOK 264
#define NUM_MINUS_TOK 265
#endif /* ifndef _YY_DEFS_H */
