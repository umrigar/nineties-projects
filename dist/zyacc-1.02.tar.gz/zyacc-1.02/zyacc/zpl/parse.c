/* Automatically generated from parse.y by zyacc version 1.02
 * using the command:
 * ../src/zyacc -d -v -o parse.c parse.y 
 */
/*

File:	 zlexskl.c
Purpose: Skeleton for zyacc parser generator.

Copyright (C) 1995 Zerksis D. Umrigar

See the file LICENSE for copying and distribution conditions.
THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.

*/
#define ZYACC

#ifdef DEBUG_ZYACC 	/* Define to check run-time assertions. */
#undef NDEBUG
#endif

#include <assert.h>

/*			 EXTERNAL LIBRARY ROUTINES.			*/

#if __STDC__
#include <limits.h>
#include <stdlib.h>	/* for malloc() and friends. */
#define YY_VOIDP void *
#define YY_VOID void
#define YY_CONST const
#define YY_PROTO 1
#else  /* ! __STDC__ */
#define YY_VOIDP char *
#define YY_VOID
#define YY_CONST
#define YY_PROTO 0
#if 0 
/* It is safest to not declare these here.  Most compilers should do the
 * right thing after producing warnings about missing declarations.
 */
char *malloc(unsigned);
YY_VOID free(char *);
char *realloc(char *, unsigned);
#endif /* if 0 */
#endif /* #if __STDC__ */


typedef unsigned char	YYUChar;
typedef unsigned short	YYUShrt;
typedef unsigned int	YYUInt;
typedef unsigned long	YYULong;


/* Define max. value YY_CHAR_BIT if YY_CHAR_BIT undef. */
#ifndef YY_CHAR_BIT
#ifdef CHAR_BIT	
#define YY_CHAR_BIT CHAR_BIT		/* From <limits.h> */
#else
#define YY_CHAR_BIT 8		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_UCHAR_MAX if YY_UCHAR_MAX undef. */
#ifndef YY_UCHAR_MAX
#ifdef UCHAR_MAX	
#define YY_UCHAR_MAX UCHAR_MAX		/* From <limits.h> */
#else
#define YY_UCHAR_MAX 255		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_USHRT_MAX if YY_USHRT_MAX undef. */
#ifndef YY_USHRT_MAX
#ifdef USHRT_MAX	
#define YY_USHRT_MAX USHRT_MAX		/* From <limits.h> */
#else
#define YY_USHRT_MAX 65535		/* A "reasonable" value. */
#endif
#endif



/* 			PARSER PARAMETERS.			*/

/* 

Define following parameters:

YY_HAS_IN_ATTRIBS:	1 if parser uses %in attributes.
YY_BAD_TOK:		Used to indicate an invalid token.
YY_EMPTY_TOK:		Used to indicate no lookahead.
YY_ERR_TOK_VAL:		Value associated with error token.
YY_HAS_MULTI_START:	1 if we have multiple %start non-terminals.
YY_N_TESTS:		# of semantic %tests used by gramar.
YY_MAX_TOK_VAL:		Maximum (user or automatically assigned) token value.
YY_MAX_RULE_LEN:	Maximum length of a rule.
YY_N_NON_TERMS:		# of non-terminal symbols (including start-symbol).
YY_N_RHS:		# of elements on RHS of all rules.
YY_N_RULES:		# of rules (including accept & error pseudo-rule).
			  Doesn't include %test pseudo-reductions.
YY_N_TOKS:		# of tokens (active & inactive) 
                        Including YYEMPTY & YY_BAD_TOK.
YY_BAD_BASE:		If used in base array, then use default entry.
YY_N_CHECK:		# of entries in yyCheck[] vector.
YY_N_NEXT:		# of entries in yyNext[] vector.
YY_N_STATES:		# of states.
YY_TESTS_SIZE:		# of entries in yyTests[].
YY_CMD_LINE_DEBUG:	1 if debugging requested via cmd-line; 0 if not.
YY_PREFIX		Prefix for external names (default yy).
YY_HAS_LOC:		1 if @n construct used; 0 otherwise.
YY_IS_PURE:		1 if %pure_parser requested; 0 otherwise.
YY_IS_TYPED:		1 if <type> used.
*/

#define YY_HAS_IN_ATTRIBS 1
#define YY_BAD_TOK 19
#define YY_EMPTY_TOK 20
#define YY_ERR_TOK_VAL 256
#define YY_HAS_MULTI_START 0
#define YY_N_TESTS 23
#define YY_MAX_TOK_VAL 267
#define YY_MAX_RULE_LEN 5
#define YY_N_NON_TERMS 46
#define YY_N_RHS 184
#define YY_N_RULES 76
#define YY_N_TOKS 21
#define YY_BAD_BASE 2
#define YY_N_CHECK 325
#define YY_N_NEXT 310
#define YY_N_STATES 86
#define YY_TESTS_SIZE 95
#define YY_CMD_LINE_DEBUG 0
#define YY_PREFIX yy
#define YY_IS_PURE 0
#define YY_HAS_LOC 0
#define YY_IS_TYPED 1
#define YY_ZYACC_MAJOR_VERSION 1
#define YY_ZYACC_MINOR_VERSION 02
#line 145 "parse.c"

/*                          TOKEN DEFINITIONS.                          */

#define NAME_TOK 257
#define VAR_TOK 258
#define NAT_NUM_TOK 259
#define STR_CHAR_TOK 260
#define REAL_NUM_TOK 261
#define WS_LPAREN_TOK 262
#define FULL_STOP_TOK 263
#define LEX_ERR_TOK 264
#define NUM_MINUS_TOK 265
#line 158 "parse.c"

/*	USER DEFINITIONS FROM SECTION 1 OF YACC FILE.			*/

#line 10 "parse.y"

#include "plops.h"
#include "scan.h"

#include <stdio.h>

/* REDUCE_TEST(n) fails iff the lookahead is an infix or suffix operator
 * with precedence < n.
 */
#define REDUCE_TEST(n)							\
  (( yychar != NAME_TOK && yychar != ','  && 				\
     yychar != NUM_MINUS_TOK ) ||					\
   ( isInfixOrSuffixOp(							\
       (yychar == NAME_TOK)						\
       ? yylval.name.id 						\
       : ( (yychar == ',') ? commaID : minusID ),			\
       (n))								\
   )									\
  )

/* OP(id, type, max): id is a type-operator with precedence <= max.  The
 * precedence is stored in the global variable level.
 */
#define OP(id, type, max)						\
  (((level= opLevel(id, type)) > 0) && (level <= max))

#define PREFIX_OP(id)							\
   (opLevel((id), FX_OP) > 0 || opLevel((id), FY_OP) > 0)

/* Printing macros to print postfix representation of Prolog program. */
#define P(f, t)	printf(f, t)				/* printf() */
#define PS(s)	printf("%s", s)				/* Print string. */
#define PN(id)	printf("%s ", getNameString(id))	/* Print name. */
#define PF(f,n)	printf("%s/%d ", getNameString(f), n)	/* Print functor. */

static Index level; 	/* Variable used within OP-macro in %tests. */
static Index minusID;	/* Name for '-' symbol. */
static Index commaID;	/* Name for ',' symbol. */


#line 203 "parse.c"

/*                      SEMANTIC TYPE DEFINITION YYSTYPE.               */

typedef union {
  struct {
    Index2 id;
  } name;
  struct {
    long num;
  } natNum;
  struct {
    double num;
  } realNum;
  struct {
    int n;
  } yy_Term;
  struct {
    int n;
  } yy_PrefixOpAtom;
  struct {
    int n;
  } yy_PrefixTerm;
  struct {
    int n;
  } yy_InfixTerm;
  struct {
    int n;
  } yy_SuffixTerm;
  struct {
    int nArgs;
  } yy_Arguments;
  struct {
    int m;
  } yy_Term999;
  struct {
    Index id;
    int n;
  } yy_FXOp;
  struct {
    Index id;
    int n;
  } yy_FYOp;
  struct {
    Index id;
    int n;
  } yy_XFXOp;
  struct {
    Index id;
    int n;
  } yy_XFYOp;
  struct {
    Index id;
    int n;
  } yy_YFXOp;
  struct {
    Index id;
    int n;
  } yy_XFOp;
  struct {
    Index id;
    int n;
  } yy_YFOp;
} YYSTYPE;

typedef struct {
  union {
    /* Term.max XFOp.max YFOp.max */
    int yyT_0;
  } yyC_0;
  union {
    /* PrefixOpAtom.max YFXOp.max XFYOp.max XFXOp.max FYOp.max 
     * FXOp.max SuffixTerm.max InfixTerm.max PrefixTerm.max 
     */
    int yyT_0;
  } yyC_1;
} YYIn;
#line 280 "parse.c"

/*           DEFINE TYPES WHICH DEPEND ON PARSER PARAMETERS.            */


/* typedef YYLen to represent values in 0, ..., YY_MAX_RULE_LEN. */
#if (YY_MAX_RULE_LEN <= YY_UCHAR_MAX)
typedef YYUChar YYLen;
#elif (YY_MAX_RULE_LEN <= YY_USHRT_MAX)
typedef YYUShrt YYLen;
#else
  #error Type YYLen cannot be represented.
#endif


/* typedef YYNonTerm to represent values in 0, ..., (YY_N_NON_TERMS - 1). */
#if ((YY_N_NON_TERMS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYNonTerm;
#elif ((YY_N_NON_TERMS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYNonTerm;
#else
  #error Type YYNonTerm cannot be represented.
#endif


/* typedef YYRHS to represent values in 0, ..., (YY_N_RHS - 1). */
#if ((YY_N_RHS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRHS;
#elif ((YY_N_RHS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRHS;
#else
  #error Type YYRHS cannot be represented.
#endif


/* typedef YYRuleN to represent values in 0, ..., (YY_N_RULES - 1). */
#if ((YY_N_RULES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRuleN;
#elif ((YY_N_RULES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRuleN;
#else
  #error Type YYRuleN cannot be represented.
#endif


/* typedef YYState to represent values in 0, ..., (YY_N_STATES - 1). */
#if ((YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYState;
#elif ((YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYState;
#else
  #error Type YYState cannot be represented.
#endif


/* typedef YYCheck to represent values in 0, ..., ((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS). */
#if (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_UCHAR_MAX)
typedef YYUChar YYCheck;
#elif (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_USHRT_MAX)
typedef YYUShrt YYCheck;
#else
  #error Type YYCheck cannot be represented.
#endif


/* typedef YYTok to represent values in 0, ..., (YY_N_TOKS - 1). */
#if ((YY_N_TOKS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTok;
#elif ((YY_N_TOKS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTok;
#else
  #error Type YYTok cannot be represented.
#endif


/* typedef YYBase to represent values in 0, ..., (YY_N_NEXT - 1). */
#if ((YY_N_NEXT - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYBase;
#elif ((YY_N_NEXT - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYBase;
#else
  #error Type YYBase cannot be represented.
#endif


/* typedef YYTest to represent values in 0, ..., (YY_N_TESTS - 1). */
#if ((YY_N_TESTS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTest;
#elif ((YY_N_TESTS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTest;
#else
  #error Type YYTest cannot be represented.
#endif


/* typedef YYAct to represent values in 0, ..., (YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1). */
#if ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYAct;
#elif ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYAct;
#else
  #error Type YYAct cannot be represented.
#endif


/* Combine YY_CMD_LINE_DEBUG and YYDEBUG into YYDEBUG. */
#if YY_CMD_LINE_DEBUG == 1
#undef YYDEBUG
#define YYDEBUG 1
#endif

#if YYDEBUG

#include <stdio.h>

typedef enum {
  YY_TOKEN_SYM= 0,		/* A token symbol. */
  YY_NON_TERM_SYM= 1,		/* A non-terminal symbol. */
  YY_RULE_SYM= 2		/* Rule symbol --- used only rule end. */
} YYSymType;

#define YY_SYM_TYPE_BIT 2	/* Min. # of bits for YYSymType. */

#define YY_SYM_TYPE(sym)						\
  ((YYSymType) ((sym) & ((1L << YY_SYM_TYPE_BIT) - 1)))
#define YY_SYM_NUM(sym)		((sym) >> YY_SYM_TYPE_BIT)
#define YY_MAKE_SYM(symType, symNum)	 				\
  ((((symNum) << YY_SYM_TYPE_BIT)) | (symType))

#define YY_MAX_SYM \
((( /* max(YY_N_NON_TERMS, YY_N_TOKS, YY_N_RULES) */ \
    (YY_N_NON_TERMS > YY_N_TOKS \
     ? (YY_N_NON_TERMS > YY_N_RULES ? YY_N_NON_TERMS : YY_N_RULES) \
     : (YY_N_TOKS > YY_N_RULES ? YY_N_TOKS : YY_N_RULES)) \
   - 1) \
  << YY_SYM_TYPE_BIT) \
 | ((1 << YY_SYM_TYPE_BIT) - 1))



/* typedef YYSym to represent values in 0, ..., YY_MAX_SYM. */
#if (YY_MAX_SYM <= YY_UCHAR_MAX)
typedef YYUChar YYSym;
#elif (YY_MAX_SYM <= YY_USHRT_MAX)
typedef YYUShrt YYSym;
#else
  #error Type YYSym cannot be represented.
#endif


#endif /* ifdef YYDEBUG */

/* 		NAMES FOR EXTERN PARSER OBJECTS.			*/
/* Default names provided, if macros not defined in section 1. 		*/

#ifndef YY_CHAR
#define YY_CHAR yychar
#endif

#ifndef YY_DEBUG
#define YY_DEBUG yydebug
#endif

#ifndef YY_ERROR
#define YY_ERROR yyerror
#endif

#ifndef YY_LEX
#define YY_LEX yylex
#endif

#ifndef YY_LVAL
#define YY_LVAL yylval
#endif

#ifndef YY_NERRS
#define YY_NERRS yynerrs
#endif

#ifndef YY_PARSE
#define YY_PARSE yyparse
#endif

#line 463 "parse.c"


/*                           GRAMMAR TABLES.                            */

/*

#if YYDEBUG					#Grammar info. for debugging.

static char *yyTokenNames[YY_N_TOKS];		#Token names. 
static char *yyNonTermNames[YY_N_NONTERMS];	#NonTerminal names.
static YYRHS yyRule[YY_N_RULES];		#Start of each rule in yySyms.
static YYSym yySyms[YY_N_RHS];			#Rule right-hand sides.
static YYSym yyAccess[YY_N_STATES]		#Access symbols for each state.

#endif

static YYTok yyTranslate[YY_MAX_TOK];		#Xlate ext. to internal tokens.

static YYLen yyLength[YY_N_RULES];		#Rule lengths.
static YYNonTerm yyLHS[YY_N_RULES];		#Rule LHS non-terminal numbers.

static YYBase yyActBase[YY_N_STATES];		#Base array for acts.
static YYRuleN yyActDef[YY_N_STATES];		#Default reduce rule.

static YYBase yyGotoBase[YY_N_NONTERMS];	#Base array for gotos.
static YYState yyGotoDef[YY_N_NONTERMS];	#Default state for gotos.

static YYAct yyNext[YY_N_NEXT];			#Action.
static YYCheck yyCheck[YY_N_CHECK];	 	#Action check array.



*/

#if YYDEBUG

static char *yyTokenNames[21]= {
  "error", "<EOF>", "NAME_TOK", "VAR_TOK", 
  "NAT_NUM_TOK", "STR_CHAR_TOK", "REAL_NUM_TOK", "WS_LPAREN_TOK", 
  "FULL_STOP_TOK", "LEX_ERR_TOK", "NUM_MINUS_TOK", "'{'", 
  "'}'", "'('", "')'", "','", 
  "'['", "']'", "'|'", "$yyBadTok", 
  "$yyEmptyTok"
};
static char *yyNonTermNames[46]= {
  "$S", "PrologText", "ReadTerm", "Term", 
  "Term0", "PrefixOpAtom", "PrefixTerm", "InfixTerm", 
  "SuffixTerm", "YYTest_1", "Arguments", "LParen", 
  "List", "String", "Term999", "ListExpr", 
  "StrChar", "FXOp", "YYTest_2", "FYOp", 
  "YYTest_3", "YYTest_4", "YYTest_5", "XFXOp", 
  "YYTest_6", "XFYOp", "YYTest_7", "YFXOp", 
  "YYTest_8", "YYTest_9", "YYTest_10", "XFOp", 
  "YYTest_11", "YFOp", "YYTest_12", "YYTest_13", 
  "YYTest_14", "YYTest_15", "YYTest_16", "YYTest_17", 
  "YYTest_18", "YYTest_19", "YYTest_20", "YYTest_21", 
  "YYTest_22", "$Err"
};
static YYRHS yyRule[76]= {
      0,     3,     6,     7,    10,    13,    15,    17,    19,    21, 
     23,    26,    27,    29,    31,    34,    37,    39,    43,    48, 
     52,    54,    56,    58,    62,    66,    68,    72,    76,    78, 
     81,    83,    85,    88,    89,    92,    93,    97,    98,   102, 
    103,   108,   109,   114,   115,   120,   121,   127,   128,   129, 
    133,   134,   138,   139,   142,   143,   146,   147,   150,   151, 
    154,   155,   158,   159,   162,   163,   166,   167,   170,   171, 
    174,   175,   178,   179,   181,   183
};
static YYSym yySyms[184]= {
      5,     4,     2,     5,     9,     6,    10,    13,    32,    14, 
      0,    32,    18,    17,    22,    21,    26,    25,    30,    29, 
     34,    33,    38,     8,    37,    42,    46,    16,    50,    24, 
     54,    40,    16,    58,    40,    24,    62,    12,    66,    44, 
     13,    48,    70,     8,    52,    41,    56,    74,    45,    13, 
     56,    78,    49,    82,    53,    86,    57,    90,    57,    60, 
     41,    94,    64,    61,    68,    98,    57,   102,    57,    60, 
     61,   106,    57,    72,    57,   110,    13,   114,    65,    53, 
    118,    65,   122,    20,   126,    69,    73,   130,   134,    77, 
     81,   138,   142,    69,    13,    85,   146,   150,    77,    13, 
     89,   154,   158,    13,    93,    13,    97,   162,   166,    13, 
    101,    13,   105,   170,   174,    13,   109,    13,   113,   178, 
    182,    13,   117,    60,    13,   121,   186,   190,   194,    13, 
    125,   129,   198,   202,    13,   133,   137,   206,   210,     8, 
    141,   214,   218,     8,   145,   222,   226,     8,   149,   230, 
    234,    40,   153,   238,   242,     8,   157,   246,   250,    40, 
    161,   254,   258,     8,   165,   262,   266,    40,   169,   270, 
    274,     8,   173,   278,   282,     8,   177,   286,   290,    28, 
    294,    52,   298,   302
};
static YYSym yyAccess[86]= {
      1,     5,     4,     0,     8,    16,    24,    40,    12,    44, 
     28,    52,    64,    20,     9,    13,    17,    21,    25,    29, 
     33,    45,    49,    53,    69,    77,    65,    32,    52,    37, 
    141,   145,    16,    24,    13,    61,    13,    57,    32,     8, 
     40,    93,   101,   109,   117,   125,   133,    13,    73,    13, 
     81,    13,    53,    41,    57,    48,    68,    60,    72,   149, 
    157,   165,   173,   177,   153,   161,   169,    13,    13,    13, 
     60,   129,   137,    56,    85,    89,    56,    60,    61,    57, 
     97,   105,   113,    13,    41,   121
};
#endif /* #if YYDEBUG */

static YYTok yyTranslate[268]= {
      1,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     13,    14,    19,    19,    15,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    16,    19,    17,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    11,    18,    12,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,    19,    19,    19,    19, 
     19,    19,    19,    19,    19,    19,     0,     2,     3,     4, 
      5,     6,     7,     8,     9,    10,    19,    20
};
static YYLen yyLength[76]= {
      2,     2,     0,     2,     2,     1,     1,     1,     1,     1, 
      2,     0,     1,     1,     2,     2,     1,     3,     4,     3, 
      1,     1,     1,     3,     3,     1,     3,     3,     1,     2, 
      1,     1,     2,     0,     2,     0,     3,     0,     3,     0, 
      4,     0,     4,     0,     4,     0,     5,     0,     0,     3, 
      0,     3,     0,     2,     0,     2,     0,     2,     0,     2, 
      0,     2,     0,     2,     0,     2,     0,     2,     0,     2, 
      0,     2,     0,     1,     1,     0
};
static YYNonTerm yyLHS[76]= {
      0,     1,     1,     2,     2,     3,     3,     3,     3,     3, 
      4,     9,     4,     4,     4,     4,     4,     4,     4,     4, 
      4,     4,    10,    10,    12,    15,    15,    15,    14,    13, 
     13,    16,     5,    18,     5,    20,     6,    21,     6,    22, 
      7,    24,     7,    26,     7,    28,     7,    29,    30,     8, 
     32,     8,    34,    17,    35,    19,    36,    23,    37,    23, 
     38,    25,    39,    25,    40,    27,    41,    27,    42,    31, 
     43,    33,    44,    11,    11,    45
};
static YYBase yyActBase[86]= {
      2,    70,     2,     1,     0,     2,     2,    93,     2,   191, 
      2,     2,   191,     2,     2,   228,     2,     2,     2,     2, 
      2,   191,     2,     2,    17,    34,    77,     2,   191,     2, 
      2,     2,     2,     2,   237,     9,   174,   188,     2,    51, 
    206,   221,   221,   221,    28,    88,    99,   231,     2,   110, 
      2,   121,     2,    46,   171,     2,     2,   221,   221,     2, 
      2,     2,     2,     2,     2,     2,     2,   132,   143,   154, 
    221,     2,     2,     2,     2,     2,     2,   221,     2,     2, 
      2,     2,     2,   165,     2,     2
};
static YYRuleN yyActDef[86]= {
      2,    75,     0,    75,    75,    12,    13,    75,    16,    75, 
     73,    74,    75,    31,     1,    75,     5,     6,     7,     8, 
      9,    75,    20,    21,    75,    75,    30,     4,    75,    10, 
     53,    55,    14,    15,    75,    75,    28,    25,     3,    75, 
     75,    75,    75,    75,    75,    75,    75,    75,    32,    75, 
     34,    75,    29,    75,    22,    17,    24,    75,    75,    57, 
     61,    65,    69,    71,    59,    63,    67,    75,    75,    75, 
     75,    49,    51,    19,    36,    38,    18,    75,    26,    27, 
     40,    42,    44,    75,    23,    46
};
static YYBase yyGotoBase[46]= {
      2,     2,     2,   239,     2,     2,     2,     2,     2,     2, 
     50,     2,     2,    58,   142,    76,     2,     2,     2,     2, 
      2,     2,     2,     2,     2,     2,     2,     2,     2,     2, 
      2,     2,     2,     2,     2,     2,     2,     2,     2,     2, 
      2,     2,     2,     2,     2,     2
};
static YYState yyGotoDef[46]= {
      0,     1,    14,    36,    16,    17,    18,    19,    20,    29, 
     84,    21,    22,    23,    54,    78,    26,    24,    48,    25, 
     50,    74,    75,    41,    80,    42,    81,    43,    82,    44, 
     85,    45,    71,    46,    72,    30,    31,    59,    64,    60, 
     65,    61,    66,    62,    63,     0
};
static YYAct yyNext[310]= {
      0,     0,   162,   163,   163,   163,   163,   163,   162,    27, 
    162,   163,   162,   166,   162,   162,   163,   162,   162,   171, 
      8,     5,    13,     6,    10,   173,    56,   175,     9,   173, 
     11,   173,   173,    12,   173,   173,   177,     8,     5,    13, 
      6,    10,   179,    70,   181,     9,   179,    11,   179,   179, 
     12,   179,   179,   185,   191,   191,   191,   191,   191,   188, 
     76,   185,   191,   188,   191,   188,   188,   191,   188,   188, 
      3,     2,     4,     8,     5,    13,     6,    10,    53,   116, 
      7,     9,    13,    11,    52,   116,    12,   116,    35,   116, 
    199,   116,   116,     0,   116,   116,   199,    32,   199,    33, 
    199,   201,   199,   199,     0,   199,   199,   201,     0,   201, 
      0,   201,   203,   201,   201,     0,   201,   201,   205,     0, 
    207,     0,   205,   212,   205,   209,     0,   205,   205,   214, 
      0,   216,     0,   214,   221,   214,   218,     0,   214,   214, 
    223,     0,   225,     0,   223,   230,   223,   227,     0,   223, 
    223,   232,     0,   234,    37,   232,   239,   232,   236,     0, 
    232,   232,   241,     0,   243,     0,   241,   248,   241,   245, 
      0,   241,   241,   250,     0,   252,    39,   250,     0,   250, 
    254,     0,   255,   255,    40,   108,    77,     0,   114,   183, 
      0,   114,   114,     4,     8,     5,    13,     6,    10,    37, 
     79,     7,     9,    57,    11,   111,    58,    12,   195,   195, 
    195,   195,   195,   195,     0,     0,   195,   195,     0,   195, 
      0,     0,   195,     4,     8,     5,    13,     6,    10,     0, 
     39,     7,     9,    39,    11,     0,    38,    12,    40,    39, 
     15,    40,     0,   169,     0,    73,   169,    40,    34,    55, 
      0,     0,   169,     0,     0,     0,     0,     0,     0,     0, 
     47,     0,     0,    49,    51,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
     67,    68,    69,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,    83
};
static YYCheck yyCheck[325]= {
     86,    86,     2,     3,     4,     5,     6,     7,     8,     8, 
     10,    11,    12,    13,    14,    15,    16,    17,    18,     2, 
      3,     4,     5,     6,     7,     8,    17,    10,    11,    12, 
     13,    14,    15,    16,    17,    18,     2,     3,     4,     5, 
      6,     7,     8,    15,    10,    11,    12,    13,    14,    15, 
     16,    17,    18,     2,     3,     4,     5,     6,     7,     8, 
     14,    10,    11,    12,    13,    14,    15,    16,    17,    18, 
      0,     1,     2,     3,     4,     5,     6,     7,    28,     2, 
     10,    11,     5,    13,    26,     8,    16,    10,    12,    12, 
      2,    14,    15,    86,    17,    18,     8,     4,    10,     6, 
     12,     2,    14,    15,    86,    17,    18,     8,    86,    10, 
     86,    12,     2,    14,    15,    86,    17,    18,     8,    86, 
     10,    86,    12,     2,    14,    15,    86,    17,    18,     8, 
     86,    10,    86,    12,     2,    14,    15,    86,    17,    18, 
      8,    86,    10,    86,    12,     2,    14,    15,    86,    17, 
     18,     8,    86,    10,    12,    12,     2,    14,    15,    86, 
     17,    18,     8,    86,    10,    86,    12,     2,    14,    15, 
     86,    17,    18,     8,    86,    10,     2,    12,    86,    14, 
     15,    86,    17,    18,    10,    14,    15,    86,    14,    15, 
     86,    17,    18,     2,     3,     4,     5,     6,     7,    57, 
     58,    10,    11,    15,    13,    17,    18,    16,     2,     3, 
      4,     5,     6,     7,    86,    86,    10,    11,    86,    13, 
     86,    86,    16,     2,     3,     4,     5,     6,     7,    86, 
      2,    10,    11,     2,    13,    86,     8,    16,    10,     2, 
      1,    10,    86,    15,    86,    14,    15,    10,     9,    12, 
     86,    86,    15,    86,    86,    86,    86,    86,    86,    86, 
     21,    86,    86,    24,    25,    86,    86,    86,    86,    86, 
     86,    86,    86,    86,    86,    86,    86,    86,    86,    86, 
     41,    42,    43,    86,    86,    86,    86,    86,    86,    86, 
     86,    86,    86,    86,    86,    86,    86,    86,    86,    86, 
     86,    86,    86,    86,    86,    86,    86,    86,    86,    70, 
     86,    86,    86,    86,    86,    86,    86,    86,    86,    86, 
     86,    86,    86,    86,    86
};
static YYTest yyTests[95]= {
      1,    13,    14,     0,    13,    14,     0,     9,     0,     2, 
      0,     2,     0,     2,     0,     3,     0,     3,     0,     3, 
      0,     9,     0,    15,    17,    19,    21,    22,     0,    15, 
     17,    19,     0,    16,    18,    20,     0,    11,     0,    12, 
      0,     4,     0,     4,     0,     4,     0,     4,     9,     0, 
      5,     0,     5,     0,     5,     0,     5,     9,     0,     6, 
      0,     6,     0,     6,     0,     6,     9,     0,     7,     0, 
      7,     0,     7,     0,     7,     9,     0,     8,     0,     8, 
      0,     8,     0,     8,     9,     0,    10,     0,    10,     0, 
     10,     0,     9,    10,     0
};
static YYAct yyTestActs[95]= {
     97,   140,   142,   161,   140,   142,    28,   133,   161,   119, 
      4,   119,   161,   119,     7,   121,     4,   121,   161,   121, 
      7,   133,   114,   144,   148,   152,   156,   158,   161,   144, 
    148,   152,   161,   146,   150,   154,   161,   136,   161,   138, 
    161,   123,    39,   123,   161,   123,    40,   123,   133,   161, 
    125,    39,   125,   161,   125,    40,   125,   133,   161,   127, 
     39,   127,   161,   127,    40,   127,   133,   161,   129,    39, 
    129,   161,   129,    40,   129,   133,   161,   131,    39,   131, 
    161,   131,    40,   131,   133,   161,   134,    39,   134,   161, 
    134,    40,   133,   134,   161
};
#line 743 "parse.c"

/*                PUBLIC MACROS NOT REDEFINABLE BY USER.                */

#define	YYACCEPT	do { yyRetVal= 0; goto yyTerminate; } while (0)
#define YYABORT		do { yyRetVal= 1; goto yyTerminate; } while (0)
#define YYEMPTY		YY_EMPTY_TOK
#define YYERROR		goto yyError
#define YYFAIL		goto yyFail
#define yyclearin	(YY_CHAR= YYEMPTY)
#define yyerrok		(yyErrShift= 0)
#define YYRECOVERING	(YY_CHAR == YY_ERR_TOK_VAL)
#define YY_ACCEPT_RULE	0

/*                        PRIVATE TYPES & MACROS                        */

/* Resynchronize after YY_CHAR is changed. */
#define YY_CHAR_SYNC							\
  do { yyTok= YY_TRANSLATE(YY_CHAR); } while (0)

/* Pseudo-error rule used to shift to error processing. */
#ifndef YY_ERR_RULE
#define YY_ERR_RULE (YY_N_RULES - 1)
#endif

/* Min. # of tokens shifted after an error before resignalling an error. */
#ifndef YY_ERR_SHIFT
#define YY_ERR_SHIFT 3
#endif

/* Max. size of stack before overflow. */
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Initial stack size.  Also used for stack increment. */
#ifndef YYINITDEPTH
#define YYINITDEPTH 200
#endif

#if (YY_HAS_LOC)
#ifndef YY_LOC
/* Default struct to maintain location information. */
#define YY_LOC 								\
  struct {								\
    int first_line;							\
    int last_line;							\
    int first_column;							\
    int last_column;							\
  }
#endif

typedef YY_LOC YYLoc;

#endif /* if (YY_HAS_LOC) */

typedef YYSTYPE YYSType;	/* Type for semantic values. */

typedef struct {		/* Stack type. */
  YYState state;		/* State stored in stack entry. */
  YYSType outVals;		/* Semantic value. */
#if (YY_HAS_IN_ATTRIBS)
  YYIn inVals;
#endif
#if (YY_HAS_LOC)
  YYLoc loc;			/* Location information. */
#endif
} YYStk;

#if YY_IS_TYPED
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals.type)
#else
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals)
#endif

#define YY_IN_VAR(offset, selector)	(yySP[offset].inVals.selector)
#define YY_OUT_VAR(offset, selector)	(yySP[offset].outVals.selector)
#if (YY_HAS_LOC)
#define YY_LOC_VAR(offset)		(yySP[offset].loc)
#endif

/*                      EXTERN SCANNER VARIABLES.                       */

#if (!YY_IS_PURE)
YYSTYPE YY_LVAL;		/* Semantic value of current token. */
int YY_CHAR= 0;			/* Current lookahead token (actual value). */
int YY_NERRS= 0;		/* Number of errors so far. */
#if (YY_HAS_LOC)
YYLoc yylloc;			/* Location information for current token. */
#endif
#if YYDEBUG
int YY_DEBUG= 0;		/* Flag to turn debug messages on/off. 	*/
#endif
#endif



/*                      CODE MACROS FOR YY_PARSE().                   */

/* Defines how yylex() is called. */
#ifndef YY_LEX_CALL
#if YY_IS_PURE
#if YY_HAS_LOC
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL, &yylloc)
#else
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL)
#endif
#else
#define YY_LEX_CALL()	YY_LEX()
#endif
#endif /* ifndef YY_LEX_CALL */

/* Translate external tokens from yylex() to internal tokens. */
#define YY_TRANSLATE(t)							\
  (((0 <= t) && (t) <= YY_MAX_TOK_VAL) ? yyTranslate[t] : YY_BAD_TOK)

/* Macros to decode acts stored in yyActNext[] & yyActDef[] tables. */
#define YY_IS_SHIFT(act)	((act) < YY_N_STATES)
#define YY_IS_REDUCE(act)	((act) >= YY_N_STATES)
#define YY_ACT_RULEN(act)	((act) - YY_N_STATES)
#define YY_ACT_STATE(act)	(act)

#define YY_GOTO_STATE(s, n)						\
  do {									\
    unsigned i= yyGotoBase[n] + (s);					\
    s= (yyCheck[i] == (s)) ? yyNext[i] : yyGotoDef[n];			\
  } while (0)

#define YY_SHIFT_LHS  yyState= (yySP++)->state

/* Stack size check & growing. */
#define YY_STK_CHK(mainBase, mainSP, size, inc)				\
  do {									\
    if ((mainSP - mainBase) >= (size))					\
      if (!(size= yyGrowStk(&mainBase, &mainSP, size + inc))) YYABORT;	\
  } while (0)

#if (YY_HAS_LOC)

/* Location info for disp from stack top. */
#define YY_STK_LOC(disp)	(yySP[disp].loc)

/* Location info for element on rule RHS with index rhsIndex (0= 1st, etc)
 * given that rule has length ruleLen.  Valid only at reduction.
 */
#define YY_RHS_LOC(rhsIndex, ruleLen)					\
  YY_STK_LOC(rhsIndex - ruleLen - 1)

#ifndef YY_UPDATE_LOC

/* Default method of computing location information in locZ, after
 * reducing by a rule having rule length ruleLen.
 */
#define YY_UPDATE_LOC(ruleLen, locZ)					\
  do {									\
    if (ruleLen) {							\
      YY_CONST YYLoc *YY_CONST locFirstP= &YY_RHS_LOC(0, ruleLen);	\
      YY_CONST YYLoc *YY_CONST locLastP= 				\
	&YY_RHS_LOC(ruleLen - 1, ruleLen);				\
      (locZ).first_line= locFirstP->first_line;				\
      (locZ).first_column= locFirstP->first_column;			\
      (locZ).last_line= locLastP->last_line; 				\
      (locZ).last_column= locLastP->last_column;			\
    }									\
    else { /* Use location of previous element. */			\
      (locZ)= YY_STK_LOC(-1);						\
    }									\
  } while (0)

#endif /* #ifndef YY_UPDATE_LOC */
#endif /* #if YY_HAS_LOC */


/*                        STACK GROWING ROUTINE.                        */
#if YY_PROTO
static YYUInt yyGrowStk (YYStk **mainBase, YYStk **mainSP, YYUInt newSize)
#else
static YYUInt yyGrowStk (mainBase, mainSP, newSize)
  YYStk **mainBase;
  YYStk **mainSP;
  YYUInt newSize;
#endif /* #if YY_PROTO */
{ 
  if (newSize > YYMAXDEPTH) {
    YY_ERROR("stack overflow"); 
    return 0;
  }
  else {
    YYUInt disp= *mainSP - *mainBase;
    if (!(*mainBase= (YYStk *)realloc(*mainBase, newSize * sizeof(YYStk)))) {
      YY_ERROR("out of memory");
      return 0;
    }
    *mainSP= *mainBase + disp;
    return newSize;
  }
}


/*                         DEBUG HELPER ROUTINES.                       */

#if YYDEBUG



#if YY_PROTO
static YY_CONST char *yySymName (YYUInt sym) 
#else
static YY_CONST char *yySymName (sym) 
  YYUInt sym;
#endif /* #if YY_PROTO */
{
  return ((YY_SYM_TYPE(sym) == YY_NON_TERM_SYM) 
	  ? yyNonTermNames 
	  : yyTokenNames)
	  [YY_SYM_NUM(sym)];	
}

#if YY_PROTO
static YY_VOID yyPrintRule (YYUInt ruleN) 
#else
static YY_VOID yyPrintRule (ruleN) 
  YYUInt ruleN;
#endif /* #if YY_PROTO */
{
  unsigned i;
  fprintf(stderr, "%s: ", yyNonTermNames[yyLHS[ruleN]]);
  for (i= yyRule[ruleN]; YY_SYM_TYPE(yySyms[i]) != YY_RULE_SYM; i++) {
    fprintf(stderr, "%s ",  yySymName(yySyms[i]));
  }
}

#endif /* #if YYDEBUG */


/*			DECLARATION FOR YY_PARSE.			*/

/* Name of formal parameter used to pass start non-terminal. */
#ifndef YY_START
#define YY_START yyStart
#endif

#ifndef YY_DECL

/* Define K&R declaration for YY_PARSE. */
#if YY_HAS_MULTI_START

#ifdef YYPARSE_PARAM
#define YY_DECL \
  int YY_PARSE(YY_START, YYPARSE_PARAM) int YY_START; YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE(YY_START) int YY_START;
#endif /* else !defined YYPARSE_PARAM */

#else /* !YY_HAS_MULTI_START */

#ifdef YYPARSE_PARAM
#define YY_DECL int YY_PARSE(YYPARSE_PARAM) YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE()
#endif /* else !defined YYPARSE_PARAM */

#endif /* else !YY_HAS_MULTI_START */

#endif /* #ifndef YY_DECL */


/*			MAIN PARSER FUNCTION.				*/

YY_DECL
{
  enum { YY_STK_INC= YYINITDEPTH };
  /* malloc() initially, as some reallocs have problems with NULL 1st arg. */
  YYStk *yyStk= (YYStk *)malloc(YY_STK_INC * sizeof(YYStk)); /* Stack base. */	
  YYStk *yySP= yyStk;					/* Main stk. ptr. */
  YYUInt yyStkSize= YY_STK_INC;	/* Current size of main & location stks. */
#if YY_HAS_MULTI_START
  YYState yyState= YY_START;	/* Current parser state. */
#else
  YYState yyState= 0;		/* Current parser state. */
#endif
  YYTok yyTok= YYEMPTY;		/* Translated value of current lookahead. */
  int yyCharSave= 0;		/* Saved value of yyChar in error processing. */
  YY_CONST YYTok yyErrTok= 	/* Token error. */
    YY_TRANSLATE(YY_ERR_TOK_VAL);
  YYUChar yyErrShift= 0;	/* # of tokens to be shifted when error. */
  YYUChar yyRetVal;		/* Value to be returned by yyparse(). */
#if YY_IS_PURE
  YYSType YY_LVAL;		/* Lexical semantic value. */
  int YY_CHAR;			/* Current lookahead token (actual value). */
  int YY_NERRS= 0;		/* Number of errors. */
#if (YY_HAS_LOC)
  YYLoc yylloc;			/* Lexical location value. */
#endif
#endif
  /* Local definitions from user. */
#line 1039 "parse.c"
  /* Confirm initial stack allocation ok. */
  if (!yyStk) 
    YY_ERROR("Out of memory.");	/* Initial stk. allocation failed. */

  yySP->state= yyState; yySP++;		/* Push initial state. */

  while (1) {				/* Terminate only via return. */
    YYUInt yyRuleN;			/* Rule # used for reduction. */

    assert(yyState == yySP[-1].state);	/* yyState mirrors state on TOS. */

    /* yyTok & YY_CHAR must agree. */
    assert(yyTok == YYEMPTY || yyTok == YY_TRANSLATE(YY_CHAR)); 

#if YYDEBUG
    if (YY_DEBUG != 0) {
      YYStk *p;	/* Spew out stack. */
      fprintf(stderr, "[ ");
      for (p= (YY_DEBUG > 0 || yySP + YY_DEBUG < yyStk) 
              ? yyStk 
	      : yySP + YY_DEBUG;
	   p < yySP; p++) {
	YY_CONST YYUInt s= p->state;
	fprintf(stderr, "%d/%s ", s, yySymName(yyAccess[s]));
      }
      fprintf(stderr, "] ");
    }
#endif
    /* Ensure space for at least 1 more stack entry. */
    YY_STK_CHK(yyStk, yySP, yyStkSize, YY_STK_INC);
#if YY_HAS_IN_ATTRIBS
    switch (yyState) { /* Don't check for non-empty reduction. */
	case 1:
YY_IN_VAR(-1, yyC_0.yyT_0)= 1200;
YY_IN_VAR(-1, yyC_1.yyT_0)= 1200;
	break;
	case 9:
YY_IN_VAR(-1, yyC_0.yyT_0)= 1200;
YY_IN_VAR(-1, yyC_1.yyT_0)= 1200;
	break;
	case 12:
YY_IN_VAR(-1, yyC_0.yyT_0)= 999;
YY_IN_VAR(-1, yyC_1.yyT_0)= 999;
	break;
	case 15:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 21:
YY_IN_VAR(-1, yyC_0.yyT_0)= 1200;
YY_IN_VAR(-1, yyC_1.yyT_0)= 1200;
	break;
	case 24:
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_OUT_VAR(-1, yy_FXOp.n) - 1;
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_OUT_VAR(-1, yy_FXOp.n) - 1;
	break;
	case 25:
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_OUT_VAR(-1, yy_FYOp.n);
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_OUT_VAR(-1, yy_FYOp.n);
	break;
	case 28:
YY_IN_VAR(-1, yyC_0.yyT_0)= 999;
YY_IN_VAR(-1, yyC_1.yyT_0)= 999;
	break;
	case 34:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 36:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 41:
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_OUT_VAR(-1, yy_XFXOp.n) - 1;
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_OUT_VAR(-1, yy_XFXOp.n) - 1;
	break;
	case 42:
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_OUT_VAR(-1, yy_XFYOp.n);
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_OUT_VAR(-1, yy_XFYOp.n);
	break;
	case 43:
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_OUT_VAR(-1, yy_YFXOp.n) - 1;
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_OUT_VAR(-1, yy_YFXOp.n) - 1;
	break;
	case 47:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 49:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 51:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 57:
YY_IN_VAR(-1, yyC_0.yyT_0)= 999;
YY_IN_VAR(-1, yyC_1.yyT_0)= 999;
	break;
	case 58:
YY_IN_VAR(-1, yyC_0.yyT_0)= 999;
YY_IN_VAR(-1, yyC_1.yyT_0)= 999;
	break;
	case 67:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 68:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 69:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
	case 70:
YY_IN_VAR(-1, yyC_0.yyT_0)= 1000;
YY_IN_VAR(-1, yyC_1.yyT_0)= 1000;
	break;
	case 77:
YY_IN_VAR(-1, yyC_0.yyT_0)= 999;
YY_IN_VAR(-1, yyC_1.yyT_0)= 999;
	break;
	case 83:
YY_IN_VAR(-1, yyC_1.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
YY_IN_VAR(-1, yyC_0.yyT_0)= YY_IN_VAR(-2, yyC_1.yyT_0);
	break;
#line 1168 "parse.c"
    }	
#endif /* #if YY_HAS_IN_ATTRIBS */
    { /* Lookup action table & branch either to yyShift or yyReduce. */
      YY_CONST YYUInt base= yyActBase[yyState];
      if (base == YY_BAD_BASE) { 
	yyRuleN= yyActDef[yyState];		/* Use default entry */
	goto yyReduce;
      }
      else { /* Use lookahead to consult yyNext[] & yyCheck[]. */
	YYUInt index;
	if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	  YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
	}
	index= base + yyTok;
	if (yyCheck[index] == yyTok) {
	  YY_CONST YYUInt act= yyNext[index];
	  if (YY_IS_REDUCE(act)) {
            yyRuleN= YY_ACT_RULEN(act); goto yyReduce;
	  }
	  else {
	    yyState= YY_ACT_STATE(act); goto yyShift;
	  }
	}
	else {
	  yyRuleN= yyActDef[yyState]; goto yyReduce;
	}
      }
    }

  yyShift:	/* Begin shift action. */
#if YYDEBUG
    if (YY_DEBUG != 0) {
      fprintf(stderr, "%s: SHIFT %d\n", yyTokenNames[yyTok], yyState);
    }
#endif
    /* Push state on stack. */
    yySP->state= yyState; yySP->outVals= YY_LVAL; 
#if (YY_HAS_LOC)
    yySP->loc= yylloc;
#endif
    yySP++;

    if (yyErrShift) {	/* Error processing in shift action. */
      if (yyTok == yyErrTok) { 	/* We successfully shifted error. */
	assert(yyErrShift == YY_ERR_SHIFT); /* No normal tokens shifted. */
	YY_CHAR= yyCharSave; YY_CHAR_SYNC; /* Restore original lookahead. */
      }
      else {			/* Successful shift of normal token. */
	yyErrShift--;		/* 1 fewer token to shift before resignal. */
	yyTok= YYEMPTY;
      }
    }
    else {
      yyTok= YYEMPTY;	/* Clear shifted token. */
    }
    continue;	/* End shift action. Continue while(1) loop.  */

  yyReduce: 	/* Begin reduce action. */
#if YY_N_TESTS > 0
    if (yyRuleN >= YY_N_RULES) { /* Test action. */
      int yyResult= 0; 	/* Or of tests tested so far. */
      YYUInt yyT;	/* Indexes yyTests[] and yyTestActs[]. */	
      if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
      }
      for (yyT= yyRuleN - YY_N_RULES; yyTests[yyT] > 0; yyT++) {
	switch (yyTests[yyT]) {
	  case 1:
	    yyResult= !PREFIX_OP(YY_OUT_VAR(-1, name.id));
	  break;
	  case 2:
	    yyResult= REDUCE_TEST(YY_OUT_VAR(-1, yy_FXOp.n));
	  break;
	  case 3:
	    yyResult= REDUCE_TEST(YY_OUT_VAR(-1, yy_FYOp.n)+1);
	  break;
	  case 4:
	    yyResult= REDUCE_TEST(YY_OUT_VAR(-2, yy_FXOp.n));
	  break;
	  case 5:
	    yyResult= REDUCE_TEST(YY_OUT_VAR(-2, yy_FYOp.n) + 1);
	  break;
	  case 6:
	    yyResult= YY_OUT_VAR(-3, yy_Term.n) < YY_OUT_VAR(-2, yy_XFXOp.n) && REDUCE_TEST(YY_OUT_VAR(-2, yy_XFXOp.n));
	  break;
	  case 7:
	    yyResult= YY_OUT_VAR(-3, yy_Term.n) < YY_OUT_VAR(-2, yy_XFYOp.n) && REDUCE_TEST(YY_OUT_VAR(-2, yy_XFYOp.n) + 1);
	  break;
	  case 8:
	    yyResult= YY_OUT_VAR(-3, yy_Term.n) <= YY_OUT_VAR(-2, yy_YFXOp.n) && REDUCE_TEST(YY_OUT_VAR(-2, yy_YFXOp.n));
	  break;
	  case 9:
	    yyResult= YY_IN_VAR(-2, yyC_1.yyT_0) >= 1000;
	  break;
	  case 10:
	    yyResult= YY_OUT_VAR(-4, yy_Term.n) < 1000 && REDUCE_TEST(1001);
	  break;
	  case 11:
	    yyResult= YY_OUT_VAR(-2, yy_Term.n) < YY_OUT_VAR(-1, yy_XFOp.n) && REDUCE_TEST(YY_OUT_VAR(-1, yy_XFOp.n));
	  break;
	  case 12:
	    yyResult= YY_OUT_VAR(-2, yy_Term.n) <= YY_OUT_VAR(-1, yy_YFOp.n) && REDUCE_TEST(YY_OUT_VAR(-1, yy_YFOp.n));
	  break;
	  case 13:
	    yyResult= OP(YY_OUT_VAR(-1, name.id), FX_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 14:
	    yyResult= OP(YY_OUT_VAR(-1, name.id), FY_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 15:
	    yyResult= OP(YY_OUT_VAR(-1, name.id), XFX_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 16:
	    yyResult= OP(minusID, XFX_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 17:
	    yyResult= OP(YY_OUT_VAR(-1, name.id), XFY_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 18:
	    yyResult= OP(minusID, XFY_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 19:
	    yyResult= OP(YY_OUT_VAR(-1, name.id), YFX_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 20:
	    yyResult= OP(minusID, YFX_OP, YY_IN_VAR(-2, yyC_1.yyT_0));
	  break;
	  case 21:
	    yyResult= OP(YY_OUT_VAR(-1, name.id), XF_OP, YY_IN_VAR(-2, yyC_0.yyT_0));
	  break;
	  case 22:
	    yyResult= OP(YY_OUT_VAR(-1, name.id), YF_OP, YY_IN_VAR(-2, yyC_0.yyT_0));
	  break;
#line 1302 "parse.c"
	}
	if (yyResult) break;
      }
      { YY_CONST YYUInt act= yyTestActs[yyT];
        if (YY_IS_SHIFT(act)) {
	  yyState= YY_ACT_STATE(act); goto yyShift;
        }
        else {
	  yyRuleN= YY_ACT_RULEN(act);
	  assert(yyRuleN < YY_N_RULES);
        }
      }
    }
#endif /* if YY_N_TESTS > 0 */
    { YYUInt yyDefault= 0;	/* 1 if default action. */

#if YYDEBUG
      if (YY_DEBUG != 0) {
        fprintf(stderr, "%s: ", yyTokenNames[yyTok]);
        if (yyRuleN == YY_ERR_RULE || yyTok == yyErrTok) {
	  fprintf(stderr, "ERROR");
        }
        else if (yyRuleN == YY_ACCEPT_RULE) {
	  fprintf(stderr, "ACCEPT." );
        }
        else {
	  fprintf(stderr, "REDUCE %d ", yyRuleN);
	  yyPrintRule(yyRuleN); 
        }
        fprintf(stderr, "\n");
      }
#endif
      if (yyTok == yyErrTok) goto yyFail; /* error triggered a default redn. */
      switch (yyRuleN) {	/* Perform relevant user or default action. */
	/* Use yySP->outVals as temporary to store new semantic value. */
	case YY_ACCEPT_RULE:	/* Accepting rule. */
	  YYACCEPT; break;
	/* User actions go here. */
	case 3:
#line 81 "parse.y"
{ PS("\n"); }
	break;
	case 4:
#line 82 "parse.y"
{ PS("\n"); }
	break;
	case 5:
#define yyYYn YY_OUT_VAR(0, yy_Term.n)
#line 85 "parse.y"
{ yyYYn= 0; }
#undef yyYYn
	break;
	case 6:
#define yyYYn YY_OUT_VAR(-1, yy_PrefixOpAtom.n)
YY_OUT_VAR(0, yy_Term.n)= yyYYn;
#undef yyYYn
	break;
	case 7:
#define yyYYn YY_OUT_VAR(-1, yy_PrefixTerm.n)
YY_OUT_VAR(0, yy_Term.n)= yyYYn;
#undef yyYYn
	break;
	case 8:
#define yyYYn YY_OUT_VAR(-1, yy_InfixTerm.n)
YY_OUT_VAR(0, yy_Term.n)= yyYYn;
#undef yyYYn
	break;
	case 9:
#define yyYYn YY_OUT_VAR(-1, yy_SuffixTerm.n)
YY_OUT_VAR(0, yy_Term.n)= yyYYn;
#undef yyYYn
	break;
	case 10:
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 92 "parse.y"
{ PN(yyYYid); }
#undef yyYYid
	break;
	case 12:
#define yyYYn YY_OUT_VAR(-1, natNum.num)
#line 93 "parse.y"
{ P("%ld ", yyYYn); }
#undef yyYYn
	break;
	case 13:
#define yyYYv YY_OUT_VAR(-1, realNum.num)
#line 94 "parse.y"
{ P("%g ", yyYYv); }
#undef yyYYv
	break;
	case 14:
#define yyYYn YY_OUT_VAR(-1, natNum.num)
#line 95 "parse.y"
{ P("-%ld ", yyYYn); }
#undef yyYYn
	break;
	case 15:
#define yyYYv YY_OUT_VAR(-1, realNum.num)
#line 96 "parse.y"
{ P("-%g ", yyYYv); }
#undef yyYYv
	break;
	case 16:
#define yyYYid YY_OUT_VAR(-1, name.id)
#line 97 "parse.y"
{ PN(yyYYid); }
#undef yyYYid
	break;
	case 17:
#line 98 "parse.y"
{ PS("{} "); }
	break;
	case 18:
#define yyYYid YY_OUT_VAR(-4, name.id)
#define yyYYn YY_OUT_VAR(-2, yy_Arguments.nArgs)
#line 99 "parse.y"
{ PF(yyYYid, yyYYn); }
#undef yyYYid
#undef yyYYn
	break;
	case 22:
#define yyYYnArgs YY_OUT_VAR(0, yy_Arguments.nArgs)
#line 105 "parse.y"
{ yyYYnArgs= 1; }
#undef yyYYnArgs
	break;
	case 23:
#define yyYYnArgs YY_OUT_VAR(0, yy_Arguments.nArgs)
#define yyYYnArgs1 YY_OUT_VAR(-1, yy_Arguments.nArgs)
#line 106 "parse.y"
{ yyYYnArgs= yyYYnArgs1 + 1; }
#undef yyYYnArgs
#undef yyYYnArgs1
	break;
	case 25:
#line 112 "parse.y"
{ PS("[] ./2 "); }
	break;
	case 26:
#line 113 "parse.y"
{ PS("./2 "); }
	break;
	case 27:
#line 114 "parse.y"
{ PS("./2 "); }
	break;
	case 28:
#define yyYYm YY_OUT_VAR(-1, yy_Term.n)
YY_OUT_VAR(0, yy_Term999.m)= yyYYm;
#undef yyYYm
	break;
	case 29:
#line 120 "parse.y"
{ PS("./2 "); }
	break;
	case 30:
#line 121 "parse.y"
{ PS("[] ./2 "); }
	break;
	case 31:
#define yyYYn YY_OUT_VAR(-1, natNum.num)
#line 124 "parse.y"
{ P("%ld ", yyYYn); }
#undef yyYYn
	break;
	case 32:
#define yyYYid YY_OUT_VAR(-2, yy_FXOp.id)
#define yyYYn YY_OUT_VAR(-2, yy_FXOp.n)
#line 128 "parse.y"
{ PN(yyYYid); }
YY_OUT_VAR(0, yy_PrefixOpAtom.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 34:
#define yyYYid YY_OUT_VAR(-2, yy_FYOp.id)
#define yyYYn YY_OUT_VAR(-2, yy_FYOp.n)
#line 130 "parse.y"
{ PN(yyYYid); }
YY_OUT_VAR(0, yy_PrefixOpAtom.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 36:
#define yyYYid YY_OUT_VAR(-3, yy_FXOp.id)
#define yyYYn YY_OUT_VAR(-3, yy_FXOp.n)
#line 134 "parse.y"
{ PF(yyYYid, 1); }
YY_OUT_VAR(0, yy_PrefixTerm.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 38:
#define yyYYid YY_OUT_VAR(-3, yy_FYOp.id)
#define yyYYn YY_OUT_VAR(-3, yy_FYOp.n)
#line 136 "parse.y"
{ PF(yyYYid, 1); }
YY_OUT_VAR(0, yy_PrefixTerm.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 40:
#define yyYYid YY_OUT_VAR(-3, yy_XFXOp.id)
#define yyYYn YY_OUT_VAR(-3, yy_XFXOp.n)
#line 141 "parse.y"
{ PF(yyYYid, 2); }
YY_OUT_VAR(0, yy_InfixTerm.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 42:
#define yyYYid YY_OUT_VAR(-3, yy_XFYOp.id)
#define yyYYn YY_OUT_VAR(-3, yy_XFYOp.n)
#line 144 "parse.y"
{ PF(yyYYid, 2); }
YY_OUT_VAR(0, yy_InfixTerm.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 44:
#define yyYYid YY_OUT_VAR(-3, yy_YFXOp.id)
#define yyYYn YY_OUT_VAR(-3, yy_YFXOp.n)
#line 147 "parse.y"
{ PF(yyYYid, 2); }
YY_OUT_VAR(0, yy_InfixTerm.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 46:
#define yyYYn YY_OUT_VAR(0, yy_InfixTerm.n)
#line 150 "parse.y"
{ yyYYn= 1000; PS(",/2 "); }
#undef yyYYn
	break;
	case 49:
#define yyYYid YY_OUT_VAR(-2, yy_XFOp.id)
#define yyYYn YY_OUT_VAR(-2, yy_XFOp.n)
#line 155 "parse.y"
{ PF(yyYYid, 1); }
YY_OUT_VAR(0, yy_SuffixTerm.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 51:
#define yyYYid YY_OUT_VAR(-2, yy_YFOp.id)
#define yyYYn YY_OUT_VAR(-2, yy_YFOp.n)
#line 158 "parse.y"
{ PF(yyYYid, 1); }
YY_OUT_VAR(0, yy_SuffixTerm.n)= yyYYn;
#undef yyYYid
#undef yyYYn
	break;
	case 53:
#define yyYYn YY_OUT_VAR(0, yy_FXOp.n)
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 162 "parse.y"
{ yyYYn= level; }
YY_OUT_VAR(0, yy_FXOp.id)= yyYYid;
#undef yyYYn
#undef yyYYid
	break;
	case 55:
#define yyYYn YY_OUT_VAR(0, yy_FYOp.n)
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 166 "parse.y"
{ yyYYn= level; }
YY_OUT_VAR(0, yy_FYOp.id)= yyYYid;
#undef yyYYn
#undef yyYYid
	break;
	case 57:
#define yyYYn YY_OUT_VAR(0, yy_XFXOp.n)
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 170 "parse.y"
{ yyYYn= level; }
YY_OUT_VAR(0, yy_XFXOp.id)= yyYYid;
#undef yyYYn
#undef yyYYid
	break;
	case 59:
#define yyYYid YY_OUT_VAR(0, yy_XFXOp.id)
#define yyYYn YY_OUT_VAR(0, yy_XFXOp.n)
#line 172 "parse.y"
{ yyYYid= minusID; yyYYn= level; }
#undef yyYYid
#undef yyYYn
	break;
	case 61:
#define yyYYn YY_OUT_VAR(0, yy_XFYOp.n)
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 176 "parse.y"
{ yyYYn= level; }
YY_OUT_VAR(0, yy_XFYOp.id)= yyYYid;
#undef yyYYn
#undef yyYYid
	break;
	case 63:
#define yyYYid YY_OUT_VAR(0, yy_XFYOp.id)
#define yyYYn YY_OUT_VAR(0, yy_XFYOp.n)
#line 178 "parse.y"
{ yyYYid= minusID; yyYYn= level; }
#undef yyYYid
#undef yyYYn
	break;
	case 65:
#define yyYYn YY_OUT_VAR(0, yy_YFXOp.n)
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 182 "parse.y"
{ yyYYn= level; }
YY_OUT_VAR(0, yy_YFXOp.id)= yyYYid;
#undef yyYYn
#undef yyYYid
	break;
	case 67:
#define yyYYid YY_OUT_VAR(0, yy_YFXOp.id)
#define yyYYn YY_OUT_VAR(0, yy_YFXOp.n)
#line 184 "parse.y"
{ yyYYid= minusID; yyYYn= level; }
#undef yyYYid
#undef yyYYn
	break;
	case 69:
#define yyYYn YY_OUT_VAR(0, yy_XFOp.n)
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 188 "parse.y"
{ yyYYn= level; }
YY_OUT_VAR(0, yy_XFOp.id)= yyYYid;
#undef yyYYn
#undef yyYYid
	break;
	case 71:
#define yyYYn YY_OUT_VAR(0, yy_YFOp.n)
#define yyYYid YY_OUT_VAR(-2, name.id)
#line 192 "parse.y"
{ yyYYn= level; }
YY_OUT_VAR(0, yy_YFOp.id)= yyYYid;
#undef yyYYn
#undef yyYYid
	break;
#line 1642 "parse.c"
	case YY_ERR_RULE:	/* "Rule" used to break to a parse error. */
	  goto yyError;
	default:		/* Perform default action. */
	  yyDefault= 1;		/* Set flag to indicate no semantic copy. */
	  break;
      }
      {	YYLen yyLen= yyLength[yyRuleN];	/* Length of reducing rule. */
      	YYNonTerm yyN= yyLHS[yyRuleN];	/* LHS nonTerm #. */
      	YYStk *yyReduceP= yySP - yyLen;	/* Point to stack entry for rule LHS. */
#if YY_HAS_LOC
	YY_UPDATE_LOC(yyLen, yySP->loc); /* Use yySP->loc as temp. entry. */
#endif
        /* Update semantic value and location info. for LHS stk. location. */
        if (yyLen > 0) { /* Stack location for rule LHS not at yySP. */
#if YY_HAS_LOC
	  yyReduceP->loc= yySP->loc; 	/* Copy tmp. loc. entry to loc. stk. */
#endif
	  if (!yyDefault) {		/* Semantic copy definitely required. */
	    yyReduceP->outVals= yySP->outVals;	/* Do semantic copy. */
	  }
        } /* if (yyLen > 0) */
        /* Compute new state. */
        assert(yyStk < yyReduceP);
        yyState= yyReduceP[-1].state;	/* Set yyState to uncovered state. */
        YY_GOTO_STATE(yyState, yyN);	
        yyReduceP->state= yyState;
        yySP= yyReduceP + 1;		/* Pop stack. */
      } /* YYLen yyLen= yyLeng[yyRuleN]; */
    } /* Reduce action: YYUInt yyDefault= 0; */
    continue;	/* End reduce action. Continue with while(1) loop.  */
  yyError:
    if (!yyErrShift) { YY_ERROR("parse error"); YY_NERRS++; }
  yyFail:
    if (!yyErrShift) { 		/* Must have just gotten an error. */
      yyErrShift= YY_ERR_SHIFT;	/* # of tokens to shift before next error. */
      yyCharSave= YY_CHAR;
      YY_CHAR= YY_ERR_TOK_VAL; YY_CHAR_SYNC;
    }
    else if (yyTok == yyErrTok) { /* We need to pop current state. */
      yySP--; 
      if (yySP == yyStk) YYABORT;
      yyState= yySP[-1].state; 
    }
    else if (yyErrShift == YY_ERR_SHIFT) { /* No tokens shifted after error. */
      if (YY_CHAR == 0) YYABORT;	/* Quit at EOF. */
      YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
    }
    else { /* We got a second error within YY_ERR_SHIFT tokens. */
      yyErrShift= 0; goto yyFail;
    }
    continue;	/* End error processing. */
  }  /* while (1) */
yyTerminate:
  free(yyStk);
  return yyRetVal;
}

/* 			SECTION 3 CODE					*/

#line 198 "parse.y"


int main(int argc, CONST char *argv[]) {
  initScan();
  initOps();
  minusID= getName("-", 1);	/* Set name for "-" symbol. */
  commaID= getName(",", 1);	/* Set name for "," symbol. */
#if YYDEBUG
  if (argc > 1) { sscanf(argv[1], "%d", &YYDEBUG_VAR); }
#endif
  /* Add some suffix operators for testing. */
  addOp(getName("^^", 2), XF_OP, 400);
  addOp(getName("??", 2), YF_OP, 300);
  return yyparse();
}

#line 1718 "parse.c"
