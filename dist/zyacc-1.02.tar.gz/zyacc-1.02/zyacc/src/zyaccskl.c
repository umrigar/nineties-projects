/*

File:	 zlexskl.c
Purpose: Skeleton for zyacc parser generator.

Copyright (C) 1995 Zerksis D. Umrigar

See the file LICENSE for copying and distribution conditions.
THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.

*/
#define ZYACC

#ifdef DEBUG_ZYACC 	/* Define to check run-time assertions. */
#undef NDEBUG
#endif

#include <assert.h>

/*			 EXTERNAL LIBRARY ROUTINES.			*/

#if __STDC__
#include <limits.h>
#include <stdlib.h>	/* for malloc() and friends. */
#define YY_VOIDP void *
#define YY_VOID void
#define YY_CONST const
#define YY_PROTO 1
#else  /* ! __STDC__ */
#define YY_VOIDP char *
#define YY_VOID
#define YY_CONST
#define YY_PROTO 0
#if 0 
/* It is safest to not declare these here.  Most compilers should do the
 * right thing after producing warnings about missing declarations.
 */
char *malloc(unsigned);
YY_VOID free(char *);
char *realloc(char *, unsigned);
#endif /* if 0 */
#endif /* #if __STDC__ */


typedef unsigned char	YYUChar;
typedef unsigned short	YYUShrt;
typedef unsigned int	YYUInt;
typedef unsigned long	YYULong;


/* Define max. value YY_CHAR_BIT if YY_CHAR_BIT undef. */
#ifndef YY_CHAR_BIT
#ifdef CHAR_BIT	
#define YY_CHAR_BIT CHAR_BIT		/* From <limits.h> */
#else
#define YY_CHAR_BIT 8		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_UCHAR_MAX if YY_UCHAR_MAX undef. */
#ifndef YY_UCHAR_MAX
#ifdef UCHAR_MAX	
#define YY_UCHAR_MAX UCHAR_MAX		/* From <limits.h> */
#else
#define YY_UCHAR_MAX 255		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_USHRT_MAX if YY_USHRT_MAX undef. */
#ifndef YY_USHRT_MAX
#ifdef USHRT_MAX	
#define YY_USHRT_MAX USHRT_MAX		/* From <limits.h> */
#else
#define YY_USHRT_MAX 65535		/* A "reasonable" value. */
#endif
#endif



/* 			PARSER PARAMETERS.			*/

/* 

Define following parameters:

YY_HAS_IN_ATTRIBS:	1 if parser uses %in attributes.
YY_BAD_TOK:		Used to indicate an invalid token.
YY_EMPTY_TOK:		Used to indicate no lookahead.
YY_ERR_TOK_VAL:		Value associated with error token.
YY_HAS_MULTI_START:	1 if we have multiple %start non-terminals.
YY_N_TESTS:		# of semantic %tests used by gramar.
YY_MAX_TOK_VAL:		Maximum (user or automatically assigned) token value.
YY_MAX_RULE_LEN:	Maximum length of a rule.
YY_N_NON_TERMS:		# of non-terminal symbols (including start-symbol).
YY_N_RHS:		# of elements on RHS of all rules.
YY_N_RULES:		# of rules (including accept & error pseudo-rule).
			  Doesn't include %test pseudo-reductions.
YY_N_TOKS:		# of tokens (active & inactive) 
                        Including YYEMPTY & YY_BAD_TOK.
YY_BAD_BASE:		If used in base array, then use default entry.
YY_N_CHECK:		# of entries in yyCheck[] vector.
YY_N_NEXT:		# of entries in yyNext[] vector.
YY_N_STATES:		# of states.
YY_TESTS_SIZE:		# of entries in yyTests[].
YY_CMD_LINE_DEBUG:	1 if debugging requested via cmd-line; 0 if not.
YY_PREFIX		Prefix for external names (default yy).
YY_HAS_LOC:		1 if @n construct used; 0 otherwise.
YY_IS_PURE:		1 if %pure_parser requested; 0 otherwise.
YY_IS_TYPED:		1 if <type> used.
*/

/*!*/

/*                          TOKEN DEFINITIONS.                          */

/*!*/

/*	USER DEFINITIONS FROM SECTION 1 OF YACC FILE.			*/

/*!*/

/*                      SEMANTIC TYPE DEFINITION YYSTYPE.               */

/*!*/

/*           DEFINE TYPES WHICH DEPEND ON PARSER PARAMETERS.            */


/* typedef YYLen to represent values in 0, ..., YY_MAX_RULE_LEN. */
#if (YY_MAX_RULE_LEN <= YY_UCHAR_MAX)
typedef YYUChar YYLen;
#elif (YY_MAX_RULE_LEN <= YY_USHRT_MAX)
typedef YYUShrt YYLen;
#else
  #error Type YYLen cannot be represented.
#endif


/* typedef YYNonTerm to represent values in 0, ..., (YY_N_NON_TERMS - 1). */
#if ((YY_N_NON_TERMS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYNonTerm;
#elif ((YY_N_NON_TERMS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYNonTerm;
#else
  #error Type YYNonTerm cannot be represented.
#endif


/* typedef YYRHS to represent values in 0, ..., (YY_N_RHS - 1). */
#if ((YY_N_RHS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRHS;
#elif ((YY_N_RHS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRHS;
#else
  #error Type YYRHS cannot be represented.
#endif


/* typedef YYRuleN to represent values in 0, ..., (YY_N_RULES - 1). */
#if ((YY_N_RULES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRuleN;
#elif ((YY_N_RULES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRuleN;
#else
  #error Type YYRuleN cannot be represented.
#endif


/* typedef YYState to represent values in 0, ..., (YY_N_STATES - 1). */
#if ((YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYState;
#elif ((YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYState;
#else
  #error Type YYState cannot be represented.
#endif


/* typedef YYCheck to represent values in 0, ..., ((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS). */
#if (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_UCHAR_MAX)
typedef YYUChar YYCheck;
#elif (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_USHRT_MAX)
typedef YYUShrt YYCheck;
#else
  #error Type YYCheck cannot be represented.
#endif


/* typedef YYTok to represent values in 0, ..., (YY_N_TOKS - 1). */
#if ((YY_N_TOKS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTok;
#elif ((YY_N_TOKS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTok;
#else
  #error Type YYTok cannot be represented.
#endif


/* typedef YYBase to represent values in 0, ..., (YY_N_NEXT - 1). */
#if ((YY_N_NEXT - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYBase;
#elif ((YY_N_NEXT - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYBase;
#else
  #error Type YYBase cannot be represented.
#endif


/* typedef YYTest to represent values in 0, ..., (YY_N_TESTS - 1). */
#if ((YY_N_TESTS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTest;
#elif ((YY_N_TESTS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTest;
#else
  #error Type YYTest cannot be represented.
#endif


/* typedef YYAct to represent values in 0, ..., (YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1). */
#if ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYAct;
#elif ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYAct;
#else
  #error Type YYAct cannot be represented.
#endif


/* Combine YY_CMD_LINE_DEBUG and YYDEBUG into YYDEBUG. */
#if YY_CMD_LINE_DEBUG == 1
#undef YYDEBUG
#define YYDEBUG 1
#endif

#if YYDEBUG

#include <stdio.h>

typedef enum {
  YY_TOKEN_SYM= 0,		/* A token symbol. */
  YY_NON_TERM_SYM= 1,		/* A non-terminal symbol. */
  YY_RULE_SYM= 2		/* Rule symbol --- used only rule end. */
} YYSymType;

#define YY_SYM_TYPE_BIT 2	/* Min. # of bits for YYSymType. */

#define YY_SYM_TYPE(sym)						\
  ((YYSymType) ((sym) & ((1L << YY_SYM_TYPE_BIT) - 1)))
#define YY_SYM_NUM(sym)		((sym) >> YY_SYM_TYPE_BIT)
#define YY_MAKE_SYM(symType, symNum)	 				\
  ((((symNum) << YY_SYM_TYPE_BIT)) | (symType))

#define YY_MAX_SYM \
((( /* max(YY_N_NON_TERMS, YY_N_TOKS, YY_N_RULES) */ \
    (YY_N_NON_TERMS > YY_N_TOKS \
     ? (YY_N_NON_TERMS > YY_N_RULES ? YY_N_NON_TERMS : YY_N_RULES) \
     : (YY_N_TOKS > YY_N_RULES ? YY_N_TOKS : YY_N_RULES)) \
   - 1) \
  << YY_SYM_TYPE_BIT) \
 | ((1 << YY_SYM_TYPE_BIT) - 1))



/* typedef YYSym to represent values in 0, ..., YY_MAX_SYM. */
#if (YY_MAX_SYM <= YY_UCHAR_MAX)
typedef YYUChar YYSym;
#elif (YY_MAX_SYM <= YY_USHRT_MAX)
typedef YYUShrt YYSym;
#else
  #error Type YYSym cannot be represented.
#endif


#endif /* ifdef YYDEBUG */

/* 		NAMES FOR EXTERN PARSER OBJECTS.			*/
/* Default names provided, if macros not defined in section 1. 		*/

/*!*/


/*                           GRAMMAR TABLES.                            */

/*

#if YYDEBUG					#Grammar info. for debugging.

static char *yyTokenNames[YY_N_TOKS];		#Token names. 
static char *yyNonTermNames[YY_N_NONTERMS];	#NonTerminal names.
static YYRHS yyRule[YY_N_RULES];		#Start of each rule in yySyms.
static YYSym yySyms[YY_N_RHS];			#Rule right-hand sides.
static YYSym yyAccess[YY_N_STATES]		#Access symbols for each state.

#endif

static YYTok yyTranslate[YY_MAX_TOK];		#Xlate ext. to internal tokens.

static YYLen yyLength[YY_N_RULES];		#Rule lengths.
static YYNonTerm yyLHS[YY_N_RULES];		#Rule LHS non-terminal numbers.

static YYBase yyActBase[YY_N_STATES];		#Base array for acts.
static YYRuleN yyActDef[YY_N_STATES];		#Default reduce rule.

static YYBase yyGotoBase[YY_N_NONTERMS];	#Base array for gotos.
static YYState yyGotoDef[YY_N_NONTERMS];	#Default state for gotos.

static YYAct yyNext[YY_N_NEXT];			#Action.
static YYCheck yyCheck[YY_N_CHECK];	 	#Action check array.



*/

/*!*/

/*                PUBLIC MACROS NOT REDEFINABLE BY USER.                */

#define	YYACCEPT	do { yyRetVal= 0; goto yyTerminate; } while (0)
#define YYABORT		do { yyRetVal= 1; goto yyTerminate; } while (0)
#define YYEMPTY		YY_EMPTY_TOK
#define YYERROR		goto yyError
#define YYFAIL		goto yyFail
#define yyclearin	(YY_CHAR= YYEMPTY)
#define yyerrok		(yyErrShift= 0)
#define YYRECOVERING	(YY_CHAR == YY_ERR_TOK_VAL)
#define YY_ACCEPT_RULE	0

/*                        PRIVATE TYPES & MACROS                        */

/* Resynchronize after YY_CHAR is changed. */
#define YY_CHAR_SYNC							\
  do { yyTok= YY_TRANSLATE(YY_CHAR); } while (0)

/* Pseudo-error rule used to shift to error processing. */
#ifndef YY_ERR_RULE
#define YY_ERR_RULE (YY_N_RULES - 1)
#endif

/* Min. # of tokens shifted after an error before resignalling an error. */
#ifndef YY_ERR_SHIFT
#define YY_ERR_SHIFT 3
#endif

/* Max. size of stack before overflow. */
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Initial stack size.  Also used for stack increment. */
#ifndef YYINITDEPTH
#define YYINITDEPTH 200
#endif

#if (YY_HAS_LOC)
#ifndef YY_LOC
/* Default struct to maintain location information. */
#define YY_LOC 								\
  struct {								\
    int first_line;							\
    int last_line;							\
    int first_column;							\
    int last_column;							\
  }
#endif

typedef YY_LOC YYLoc;

#endif /* if (YY_HAS_LOC) */

typedef YYSTYPE YYSType;	/* Type for semantic values. */

typedef struct {		/* Stack type. */
  YYState state;		/* State stored in stack entry. */
  YYSType outVals;		/* Semantic value. */
#if (YY_HAS_IN_ATTRIBS)
  YYIn inVals;
#endif
#if (YY_HAS_LOC)
  YYLoc loc;			/* Location information. */
#endif
} YYStk;

#if YY_IS_TYPED
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals.type)
#else
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals)
#endif

#define YY_IN_VAR(offset, selector)	(yySP[offset].inVals.selector)
#define YY_OUT_VAR(offset, selector)	(yySP[offset].outVals.selector)
#if (YY_HAS_LOC)
#define YY_LOC_VAR(offset)		(yySP[offset].loc)
#endif

/*                      EXTERN SCANNER VARIABLES.                       */

#if (!YY_IS_PURE)
YYSTYPE YY_LVAL;		/* Semantic value of current token. */
int YY_CHAR= 0;			/* Current lookahead token (actual value). */
int YY_NERRS= 0;		/* Number of errors so far. */
#if (YY_HAS_LOC)
YYLoc yylloc;			/* Location information for current token. */
#endif
#if YYDEBUG
int YY_DEBUG= 0;		/* Flag to turn debug messages on/off. 	*/
#endif
#endif



/*                      CODE MACROS FOR YY_PARSE().                   */

/* Defines how yylex() is called. */
#ifndef YY_LEX_CALL
#if YY_IS_PURE
#if YY_HAS_LOC
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL, &yylloc)
#else
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL)
#endif
#else
#define YY_LEX_CALL()	YY_LEX()
#endif
#endif /* ifndef YY_LEX_CALL */

/* Translate external tokens from yylex() to internal tokens. */
#define YY_TRANSLATE(t)							\
  (((0 <= t) && (t) <= YY_MAX_TOK_VAL) ? yyTranslate[t] : YY_BAD_TOK)

/* Macros to decode acts stored in yyActNext[] & yyActDef[] tables. */
#define YY_IS_SHIFT(act)	((act) < YY_N_STATES)
#define YY_IS_REDUCE(act)	((act) >= YY_N_STATES)
#define YY_ACT_RULEN(act)	((act) - YY_N_STATES)
#define YY_ACT_STATE(act)	(act)

#define YY_GOTO_STATE(s, n)						\
  do {									\
    unsigned i= yyGotoBase[n] + (s);					\
    s= (yyCheck[i] == (s)) ? yyNext[i] : yyGotoDef[n];			\
  } while (0)

#define YY_SHIFT_LHS  yyState= (yySP++)->state

/* Stack size check & growing. */
#define YY_STK_CHK(mainBase, mainSP, size, inc)				\
  do {									\
    if ((mainSP - mainBase) >= (size))					\
      if (!(size= yyGrowStk(&mainBase, &mainSP, size + inc))) YYABORT;	\
  } while (0)

#if (YY_HAS_LOC)

/* Location info for disp from stack top. */
#define YY_STK_LOC(disp)	(yySP[disp].loc)

/* Location info for element on rule RHS with index rhsIndex (0= 1st, etc)
 * given that rule has length ruleLen.  Valid only at reduction.
 */
#define YY_RHS_LOC(rhsIndex, ruleLen)					\
  YY_STK_LOC(rhsIndex - ruleLen - 1)

#ifndef YY_UPDATE_LOC

/* Default method of computing location information in locZ, after
 * reducing by a rule having rule length ruleLen.
 */
#define YY_UPDATE_LOC(ruleLen, locZ)					\
  do {									\
    if (ruleLen) {							\
      YY_CONST YYLoc *YY_CONST locFirstP= &YY_RHS_LOC(0, ruleLen);	\
      YY_CONST YYLoc *YY_CONST locLastP= 				\
	&YY_RHS_LOC(ruleLen - 1, ruleLen);				\
      (locZ).first_line= locFirstP->first_line;				\
      (locZ).first_column= locFirstP->first_column;			\
      (locZ).last_line= locLastP->last_line; 				\
      (locZ).last_column= locLastP->last_column;			\
    }									\
    else { /* Use location of previous element. */			\
      (locZ)= YY_STK_LOC(-1);						\
    }									\
  } while (0)

#endif /* #ifndef YY_UPDATE_LOC */
#endif /* #if YY_HAS_LOC */


/*                        STACK GROWING ROUTINE.                        */
#if YY_PROTO
static YYUInt yyGrowStk (YYStk **mainBase, YYStk **mainSP, YYUInt newSize)
#else
static YYUInt yyGrowStk (mainBase, mainSP, newSize)
  YYStk **mainBase;
  YYStk **mainSP;
  YYUInt newSize;
#endif /* #if YY_PROTO */
{ 
  if (newSize > YYMAXDEPTH) {
    YY_ERROR("stack overflow"); 
    return 0;
  }
  else {
    YYUInt disp= *mainSP - *mainBase;
    if (!(*mainBase= (YYStk *)realloc(*mainBase, newSize * sizeof(YYStk)))) {
      YY_ERROR("out of memory");
      return 0;
    }
    *mainSP= *mainBase + disp;
    return newSize;
  }
}


/*                         DEBUG HELPER ROUTINES.                       */

#if YYDEBUG



#if YY_PROTO
static YY_CONST char *yySymName (YYUInt sym) 
#else
static YY_CONST char *yySymName (sym) 
  YYUInt sym;
#endif /* #if YY_PROTO */
{
  return ((YY_SYM_TYPE(sym) == YY_NON_TERM_SYM) 
	  ? yyNonTermNames 
	  : yyTokenNames)
	  [YY_SYM_NUM(sym)];	
}

#if YY_PROTO
static YY_VOID yyPrintRule (YYUInt ruleN) 
#else
static YY_VOID yyPrintRule (ruleN) 
  YYUInt ruleN;
#endif /* #if YY_PROTO */
{
  unsigned i;
  fprintf(stderr, "%s: ", yyNonTermNames[yyLHS[ruleN]]);
  for (i= yyRule[ruleN]; YY_SYM_TYPE(yySyms[i]) != YY_RULE_SYM; i++) {
    fprintf(stderr, "%s ",  yySymName(yySyms[i]));
  }
}

#endif /* #if YYDEBUG */


/*			DECLARATION FOR YY_PARSE.			*/

/* Name of formal parameter used to pass start non-terminal. */
#ifndef YY_START
#define YY_START yyStart
#endif

#ifndef YY_DECL

/* Define K&R declaration for YY_PARSE. */
#if YY_HAS_MULTI_START

#ifdef YYPARSE_PARAM
#define YY_DECL \
  int YY_PARSE(YY_START, YYPARSE_PARAM) int YY_START; YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE(YY_START) int YY_START;
#endif /* else !defined YYPARSE_PARAM */

#else /* !YY_HAS_MULTI_START */

#ifdef YYPARSE_PARAM
#define YY_DECL int YY_PARSE(YYPARSE_PARAM) YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE()
#endif /* else !defined YYPARSE_PARAM */

#endif /* else !YY_HAS_MULTI_START */

#endif /* #ifndef YY_DECL */


/*			MAIN PARSER FUNCTION.				*/

YY_DECL
{
  enum { YY_STK_INC= YYINITDEPTH };
  /* malloc() initially, as some reallocs have problems with NULL 1st arg. */
  YYStk *yyStk= (YYStk *)malloc(YY_STK_INC * sizeof(YYStk)); /* Stack base. */	
  YYStk *yySP= yyStk;					/* Main stk. ptr. */
  YYUInt yyStkSize= YY_STK_INC;	/* Current size of main & location stks. */
#if YY_HAS_MULTI_START
  YYState yyState= YY_START;	/* Current parser state. */
#else
  YYState yyState= 0;		/* Current parser state. */
#endif
  YYTok yyTok= YYEMPTY;		/* Translated value of current lookahead. */
  int yyCharSave= 0;		/* Saved value of yyChar in error processing. */
  YY_CONST YYTok yyErrTok= 	/* Token error. */
    YY_TRANSLATE(YY_ERR_TOK_VAL);
  YYUChar yyErrShift= 0;	/* # of tokens to be shifted when error. */
  YYUChar yyRetVal;		/* Value to be returned by yyparse(). */
#if YY_IS_PURE
  YYSType YY_LVAL;		/* Lexical semantic value. */
  int YY_CHAR;			/* Current lookahead token (actual value). */
  int YY_NERRS= 0;		/* Number of errors. */
#if (YY_HAS_LOC)
  YYLoc yylloc;			/* Lexical location value. */
#endif
#endif
  /* Local definitions from user. */
/*!*/
  /* Confirm initial stack allocation ok. */
  if (!yyStk) 
    YY_ERROR("Out of memory.");	/* Initial stk. allocation failed. */

  yySP->state= yyState; yySP++;		/* Push initial state. */

  while (1) {				/* Terminate only via return. */
    YYUInt yyRuleN;			/* Rule # used for reduction. */

    assert(yyState == yySP[-1].state);	/* yyState mirrors state on TOS. */

    /* yyTok & YY_CHAR must agree. */
    assert(yyTok == YYEMPTY || yyTok == YY_TRANSLATE(YY_CHAR)); 

#if YYDEBUG
    if (YY_DEBUG != 0) {
      YYStk *p;	/* Spew out stack. */
      fprintf(stderr, "[ ");
      for (p= (YY_DEBUG > 0 || yySP + YY_DEBUG < yyStk) 
              ? yyStk 
	      : yySP + YY_DEBUG;
	   p < yySP; p++) {
	YY_CONST YYUInt s= p->state;
	fprintf(stderr, "%d/%s ", s, yySymName(yyAccess[s]));
      }
      fprintf(stderr, "] ");
    }
#endif
    /* Ensure space for at least 1 more stack entry. */
    YY_STK_CHK(yyStk, yySP, yyStkSize, YY_STK_INC);
#if YY_HAS_IN_ATTRIBS
    switch (yyState) { /* Don't check for non-empty reduction. */
/*!*/	
    }	
#endif /* #if YY_HAS_IN_ATTRIBS */
    { /* Lookup action table & branch either to yyShift or yyReduce. */
      YY_CONST YYUInt base= yyActBase[yyState];
      if (base == YY_BAD_BASE) { 
	yyRuleN= yyActDef[yyState];		/* Use default entry */
	goto yyReduce;
      }
      else { /* Use lookahead to consult yyNext[] & yyCheck[]. */
	YYUInt index;
	if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	  YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
	}
	index= base + yyTok;
	if (yyCheck[index] == yyTok) {
	  YY_CONST YYUInt act= yyNext[index];
	  if (YY_IS_REDUCE(act)) {
            yyRuleN= YY_ACT_RULEN(act); goto yyReduce;
	  }
	  else {
	    yyState= YY_ACT_STATE(act); goto yyShift;
	  }
	}
	else {
	  yyRuleN= yyActDef[yyState]; goto yyReduce;
	}
      }
    }

  yyShift:	/* Begin shift action. */
#if YYDEBUG
    if (YY_DEBUG != 0) {
      fprintf(stderr, "%s: SHIFT %d\n", yyTokenNames[yyTok], yyState);
    }
#endif
    /* Push state on stack. */
    yySP->state= yyState; yySP->outVals= YY_LVAL; 
#if (YY_HAS_LOC)
    yySP->loc= yylloc;
#endif
    yySP++;

    if (yyErrShift) {	/* Error processing in shift action. */
      if (yyTok == yyErrTok) { 	/* We successfully shifted error. */
	assert(yyErrShift == YY_ERR_SHIFT); /* No normal tokens shifted. */
	YY_CHAR= yyCharSave; YY_CHAR_SYNC; /* Restore original lookahead. */
      }
      else {			/* Successful shift of normal token. */
	yyErrShift--;		/* 1 fewer token to shift before resignal. */
	yyTok= YYEMPTY;
      }
    }
    else {
      yyTok= YYEMPTY;	/* Clear shifted token. */
    }
    continue;	/* End shift action. Continue while(1) loop.  */

  yyReduce: 	/* Begin reduce action. */
#if YY_N_TESTS > 0
    if (yyRuleN >= YY_N_RULES) { /* Test action. */
      int yyResult= 0; 	/* Or of tests tested so far. */
      YYUInt yyT;	/* Indexes yyTests[] and yyTestActs[]. */	
      if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
      }
      for (yyT= yyRuleN - YY_N_RULES; yyTests[yyT] > 0; yyT++) {
	switch (yyTests[yyT]) {
/*!*/	
	}
	if (yyResult) break;
      }
      { YY_CONST YYUInt act= yyTestActs[yyT];
        if (YY_IS_SHIFT(act)) {
	  yyState= YY_ACT_STATE(act); goto yyShift;
        }
        else {
	  yyRuleN= YY_ACT_RULEN(act);
	  assert(yyRuleN < YY_N_RULES);
        }
      }
    }
#endif /* if YY_N_TESTS > 0 */
    { YYUInt yyDefault= 0;	/* 1 if default action. */

#if YYDEBUG
      if (YY_DEBUG != 0) {
        fprintf(stderr, "%s: ", yyTokenNames[yyTok]);
        if (yyRuleN == YY_ERR_RULE || yyTok == yyErrTok) {
	  fprintf(stderr, "ERROR");
        }
        else if (yyRuleN == YY_ACCEPT_RULE) {
	  fprintf(stderr, "ACCEPT." );
        }
        else {
	  fprintf(stderr, "REDUCE %d ", yyRuleN);
	  yyPrintRule(yyRuleN); 
        }
        fprintf(stderr, "\n");
      }
#endif
      if (yyTok == yyErrTok) goto yyFail; /* error triggered a default redn. */
      switch (yyRuleN) {	/* Perform relevant user or default action. */
	/* Use yySP->outVals as temporary to store new semantic value. */
	case YY_ACCEPT_RULE:	/* Accepting rule. */
	  YYACCEPT; break;
	/* User actions go here. */
/*!*/
	case YY_ERR_RULE:	/* "Rule" used to break to a parse error. */
	  goto yyError;
	default:		/* Perform default action. */
	  yyDefault= 1;		/* Set flag to indicate no semantic copy. */
	  break;
      }
      {	YYLen yyLen= yyLength[yyRuleN];	/* Length of reducing rule. */
      	YYNonTerm yyN= yyLHS[yyRuleN];	/* LHS nonTerm #. */
      	YYStk *yyReduceP= yySP - yyLen;	/* Point to stack entry for rule LHS. */
#if YY_HAS_LOC
	YY_UPDATE_LOC(yyLen, yySP->loc); /* Use yySP->loc as temp. entry. */
#endif
        /* Update semantic value and location info. for LHS stk. location. */
        if (yyLen > 0) { /* Stack location for rule LHS not at yySP. */
#if YY_HAS_LOC
	  yyReduceP->loc= yySP->loc; 	/* Copy tmp. loc. entry to loc. stk. */
#endif
	  if (!yyDefault) {		/* Semantic copy definitely required. */
	    yyReduceP->outVals= yySP->outVals;	/* Do semantic copy. */
	  }
        } /* if (yyLen > 0) */
        /* Compute new state. */
        assert(yyStk < yyReduceP);
        yyState= yyReduceP[-1].state;	/* Set yyState to uncovered state. */
        YY_GOTO_STATE(yyState, yyN);	
        yyReduceP->state= yyState;
        yySP= yyReduceP + 1;		/* Pop stack. */
      } /* YYLen yyLen= yyLeng[yyRuleN]; */
    } /* Reduce action: YYUInt yyDefault= 0; */
    continue;	/* End reduce action. Continue with while(1) loop.  */
  yyError:
    if (!yyErrShift) { YY_ERROR("parse error"); YY_NERRS++; }
  yyFail:
    if (!yyErrShift) { 		/* Must have just gotten an error. */
      yyErrShift= YY_ERR_SHIFT;	/* # of tokens to shift before next error. */
      yyCharSave= YY_CHAR;
      YY_CHAR= YY_ERR_TOK_VAL; YY_CHAR_SYNC;
    }
    else if (yyTok == yyErrTok) { /* We need to pop current state. */
      yySP--; 
      if (yySP == yyStk) YYABORT;
      yyState= yySP[-1].state; 
    }
    else if (yyErrShift == YY_ERR_SHIFT) { /* No tokens shifted after error. */
      if (YY_CHAR == 0) YYABORT;	/* Quit at EOF. */
      YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
    }
    else { /* We got a second error within YY_ERR_SHIFT tokens. */
      yyErrShift= 0; goto yyFail;
    }
    continue;	/* End error processing. */
  }  /* while (1) */
yyTerminate:
  free(yyStk);
  return yyRetVal;
}

/* 			SECTION 3 CODE					*/

/*!*/
