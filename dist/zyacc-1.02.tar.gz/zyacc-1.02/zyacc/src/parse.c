/* Automatically generated from parse.y by zyacc version 1.02
 * using the command:
 * ./zyacc -d -v -o parse.c parse.y 
 */
/*

File:	 zlexskl.c
Purpose: Skeleton for zyacc parser generator.

Copyright (C) 1995 Zerksis D. Umrigar

See the file LICENSE for copying and distribution conditions.
THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.

*/
#define ZYACC

#ifdef DEBUG_ZYACC 	/* Define to check run-time assertions. */
#undef NDEBUG
#endif

#include <assert.h>

/*			 EXTERNAL LIBRARY ROUTINES.			*/

#if __STDC__
#include <limits.h>
#include <stdlib.h>	/* for malloc() and friends. */
#define YY_VOIDP void *
#define YY_VOID void
#define YY_CONST const
#define YY_PROTO 1
#else  /* ! __STDC__ */
#define YY_VOIDP char *
#define YY_VOID
#define YY_CONST
#define YY_PROTO 0
#if 0 
/* It is safest to not declare these here.  Most compilers should do the
 * right thing after producing warnings about missing declarations.
 */
char *malloc(unsigned);
YY_VOID free(char *);
char *realloc(char *, unsigned);
#endif /* if 0 */
#endif /* #if __STDC__ */


typedef unsigned char	YYUChar;
typedef unsigned short	YYUShrt;
typedef unsigned int	YYUInt;
typedef unsigned long	YYULong;


/* Define max. value YY_CHAR_BIT if YY_CHAR_BIT undef. */
#ifndef YY_CHAR_BIT
#ifdef CHAR_BIT	
#define YY_CHAR_BIT CHAR_BIT		/* From <limits.h> */
#else
#define YY_CHAR_BIT 8		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_UCHAR_MAX if YY_UCHAR_MAX undef. */
#ifndef YY_UCHAR_MAX
#ifdef UCHAR_MAX	
#define YY_UCHAR_MAX UCHAR_MAX		/* From <limits.h> */
#else
#define YY_UCHAR_MAX 255		/* A "reasonable" value. */
#endif
#endif



/* Define max. value YY_USHRT_MAX if YY_USHRT_MAX undef. */
#ifndef YY_USHRT_MAX
#ifdef USHRT_MAX	
#define YY_USHRT_MAX USHRT_MAX		/* From <limits.h> */
#else
#define YY_USHRT_MAX 65535		/* A "reasonable" value. */
#endif
#endif



/* 			PARSER PARAMETERS.			*/

/* 

Define following parameters:

YY_HAS_IN_ATTRIBS:	1 if parser uses %in attributes.
YY_BAD_TOK:		Used to indicate an invalid token.
YY_EMPTY_TOK:		Used to indicate no lookahead.
YY_ERR_TOK_VAL:		Value associated with error token.
YY_HAS_MULTI_START:	1 if we have multiple %start non-terminals.
YY_N_TESTS:		# of semantic %tests used by gramar.
YY_MAX_TOK_VAL:		Maximum (user or automatically assigned) token value.
YY_MAX_RULE_LEN:	Maximum length of a rule.
YY_N_NON_TERMS:		# of non-terminal symbols (including start-symbol).
YY_N_RHS:		# of elements on RHS of all rules.
YY_N_RULES:		# of rules (including accept & error pseudo-rule).
			  Doesn't include %test pseudo-reductions.
YY_N_TOKS:		# of tokens (active & inactive) 
                        Including YYEMPTY & YY_BAD_TOK.
YY_BAD_BASE:		If used in base array, then use default entry.
YY_N_CHECK:		# of entries in yyCheck[] vector.
YY_N_NEXT:		# of entries in yyNext[] vector.
YY_N_STATES:		# of states.
YY_TESTS_SIZE:		# of entries in yyTests[].
YY_CMD_LINE_DEBUG:	1 if debugging requested via cmd-line; 0 if not.
YY_PREFIX		Prefix for external names (default yy).
YY_HAS_LOC:		1 if @n construct used; 0 otherwise.
YY_IS_PURE:		1 if %pure_parser requested; 0 otherwise.
YY_IS_TYPED:		1 if <type> used.
*/

#define YY_HAS_IN_ATTRIBS 0
#define YY_BAD_TOK 40
#define YY_EMPTY_TOK 41
#define YY_ERR_TOK_VAL 256
#define YY_HAS_MULTI_START 0
#define YY_N_TESTS 0
#define YY_MAX_TOK_VAL 287
#define YY_MAX_RULE_LEN 4
#define YY_N_NON_TERMS 45
#define YY_N_RHS 266
#define YY_N_RULES 100
#define YY_N_TOKS 42
#define YY_BAD_BASE 1
#define YY_N_CHECK 534
#define YY_N_NEXT 442
#define YY_N_STATES 144
#define YY_TESTS_SIZE 0
#define YY_CMD_LINE_DEBUG 0
#define YY_PREFIX yy
#define YY_IS_PURE 0
#define YY_HAS_LOC 0
#define YY_IS_TYPED 1
#define YY_ZYACC_MAJOR_VERSION 1
#define YY_ZYACC_MINOR_VERSION 02
#line 145 "parse.c"

/*                          TOKEN DEFINITIONS.                          */

#define EXPECT_TOK 257
#define ID_TOK 258
#define ID_VAR_TOK 259
#define IN_TOK 260
#define LEFT_TOK 261
#define LEX_ERR_TOK 262
#define LHS_VAR_TOK 263
#define LIT_TOK 264
#define MARK_TOK 265
#define NOLOOK_TOK 266
#define NONASSOC_TOK 267
#define NOWARN_TOK 268
#define NUM_TOK 269
#define NUM_VAR_TOK 270
#define OPTION_TOK 271
#define OPTION_VAL_TOK 272
#define OUT_TOK 273
#define PREC_TOK 274
#define PURE_TOK 275
#define RIGHT_TOK 276
#define SHORT_TEXT_TOK 277
#define START_TOK 278
#define TEST_TOK 279
#define TEXT_TOK 280
#define TOKEN_TOK 281
#define TYPE_TOK 282
#define TYPE_ID_TOK 283
#define UNION_TOK 284
#define XID_TOK 285
#line 178 "parse.c"

/*	USER DEFINITIONS FROM SECTION 1 OF YACC FILE.			*/

#line 38 "parse.y"


#include "attribs.h"
#include "gram.h"
#include "lalr.h"
#include "options.h"
#include "scan.h"
#include "zparse.h"

#include "error.h"


#line 113 "parse.y"


int yyerror PROTO((char *s));

#define yylex scan

static struct {
  Index2 assocPrec;	/* The assoc/prec. of the current declaration. */
  Index2 precLevel;	/* Precedence level counter. */
  Index2 prec;		/* The precedence associated with the declaration. */
  Index2 type;		/* The type associated with current declaration. */
  Count2 decCount;	/* Count of # of declarations. */
  Index2 lineN;		/* Line # for attrib. exprs. */
  Boolean isPure;	/* TRUE if %pure parser specified. */
  Boolean nowarn;	/* TRUE if %nowarn for current token declaration. */
} globs;

#define G globs


#line 216 "parse.c"

/*                      SEMANTIC TYPE DEFINITION YYSTYPE.               */

typedef union {
#line 51 "parse.y"
 
  Index id;			/* Index of identifier. */
  struct {			/* Literal in single quotes. */
    Index2 id;			/* Index literal text (including quotes). */
    Index2 val;			/* The integer value of the literal. */
  } lit;		
  NumVar numVar;		/* A numeric $-variable of form $<type>NN. */
  ConstString text;		/* Pointer to saved yytext. */
  char shortText 		/* Avoid interning short strings if returned */
    [sizeof(ConstString)];	/* text fits here. */
  Int num;			/* A number. */
  Int lineN;			/* Line # in source file. */
  Index type;			/* Identifier for <type>. */
  Index actN;
  Count count;			/* Count of number in lists. */
  Index2 assocPrec;		/* Associativity and precedence. */

} YYSTYPE;

#line 241 "parse.c"

/*           DEFINE TYPES WHICH DEPEND ON PARSER PARAMETERS.            */


/* typedef YYLen to represent values in 0, ..., YY_MAX_RULE_LEN. */
#if (YY_MAX_RULE_LEN <= YY_UCHAR_MAX)
typedef YYUChar YYLen;
#elif (YY_MAX_RULE_LEN <= YY_USHRT_MAX)
typedef YYUShrt YYLen;
#else
  #error Type YYLen cannot be represented.
#endif


/* typedef YYNonTerm to represent values in 0, ..., (YY_N_NON_TERMS - 1). */
#if ((YY_N_NON_TERMS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYNonTerm;
#elif ((YY_N_NON_TERMS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYNonTerm;
#else
  #error Type YYNonTerm cannot be represented.
#endif


/* typedef YYRHS to represent values in 0, ..., (YY_N_RHS - 1). */
#if ((YY_N_RHS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRHS;
#elif ((YY_N_RHS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRHS;
#else
  #error Type YYRHS cannot be represented.
#endif


/* typedef YYRuleN to represent values in 0, ..., (YY_N_RULES - 1). */
#if ((YY_N_RULES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYRuleN;
#elif ((YY_N_RULES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYRuleN;
#else
  #error Type YYRuleN cannot be represented.
#endif


/* typedef YYState to represent values in 0, ..., (YY_N_STATES - 1). */
#if ((YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYState;
#elif ((YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYState;
#else
  #error Type YYState cannot be represented.
#endif


/* typedef YYCheck to represent values in 0, ..., ((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS). */
#if (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_UCHAR_MAX)
typedef YYUChar YYCheck;
#elif (((YY_N_STATES > YY_N_TERMS) ? YY_N_STATES : YY_N_TERMS) <= YY_USHRT_MAX)
typedef YYUShrt YYCheck;
#else
  #error Type YYCheck cannot be represented.
#endif


/* typedef YYTok to represent values in 0, ..., (YY_N_TOKS - 1). */
#if ((YY_N_TOKS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTok;
#elif ((YY_N_TOKS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTok;
#else
  #error Type YYTok cannot be represented.
#endif


/* typedef YYBase to represent values in 0, ..., (YY_N_NEXT - 1). */
#if ((YY_N_NEXT - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYBase;
#elif ((YY_N_NEXT - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYBase;
#else
  #error Type YYBase cannot be represented.
#endif


/* typedef YYTest to represent values in 0, ..., (YY_N_TESTS - 1). */
#if ((YY_N_TESTS - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYTest;
#elif ((YY_N_TESTS - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYTest;
#else
  #error Type YYTest cannot be represented.
#endif


/* typedef YYAct to represent values in 0, ..., (YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1). */
#if ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_UCHAR_MAX)
typedef YYUChar YYAct;
#elif ((YY_N_RULES + YY_TESTS_SIZE + YY_N_STATES - 1) <= YY_USHRT_MAX)
typedef YYUShrt YYAct;
#else
  #error Type YYAct cannot be represented.
#endif


/* Combine YY_CMD_LINE_DEBUG and YYDEBUG into YYDEBUG. */
#if YY_CMD_LINE_DEBUG == 1
#undef YYDEBUG
#define YYDEBUG 1
#endif

#if YYDEBUG

#include <stdio.h>

typedef enum {
  YY_TOKEN_SYM= 0,		/* A token symbol. */
  YY_NON_TERM_SYM= 1,		/* A non-terminal symbol. */
  YY_RULE_SYM= 2		/* Rule symbol --- used only rule end. */
} YYSymType;

#define YY_SYM_TYPE_BIT 2	/* Min. # of bits for YYSymType. */

#define YY_SYM_TYPE(sym)						\
  ((YYSymType) ((sym) & ((1L << YY_SYM_TYPE_BIT) - 1)))
#define YY_SYM_NUM(sym)		((sym) >> YY_SYM_TYPE_BIT)
#define YY_MAKE_SYM(symType, symNum)	 				\
  ((((symNum) << YY_SYM_TYPE_BIT)) | (symType))

#define YY_MAX_SYM \
((( /* max(YY_N_NON_TERMS, YY_N_TOKS, YY_N_RULES) */ \
    (YY_N_NON_TERMS > YY_N_TOKS \
     ? (YY_N_NON_TERMS > YY_N_RULES ? YY_N_NON_TERMS : YY_N_RULES) \
     : (YY_N_TOKS > YY_N_RULES ? YY_N_TOKS : YY_N_RULES)) \
   - 1) \
  << YY_SYM_TYPE_BIT) \
 | ((1 << YY_SYM_TYPE_BIT) - 1))



/* typedef YYSym to represent values in 0, ..., YY_MAX_SYM. */
#if (YY_MAX_SYM <= YY_UCHAR_MAX)
typedef YYUChar YYSym;
#elif (YY_MAX_SYM <= YY_USHRT_MAX)
typedef YYUShrt YYSym;
#else
  #error Type YYSym cannot be represented.
#endif


#endif /* ifdef YYDEBUG */

/* 		NAMES FOR EXTERN PARSER OBJECTS.			*/
/* Default names provided, if macros not defined in section 1. 		*/

#ifndef YY_CHAR
#define YY_CHAR yychar
#endif

#ifndef YY_DEBUG
#define YY_DEBUG yydebug
#endif

#ifndef YY_ERROR
#define YY_ERROR yyerror
#endif

#ifndef YY_LEX
#define YY_LEX yylex
#endif

#ifndef YY_LVAL
#define YY_LVAL yylval
#endif

#ifndef YY_NERRS
#define YY_NERRS yynerrs
#endif

#ifndef YY_PARSE
#define YY_PARSE yyparse
#endif

#line 424 "parse.c"


/*                           GRAMMAR TABLES.                            */

/*

#if YYDEBUG					#Grammar info. for debugging.

static char *yyTokenNames[YY_N_TOKS];		#Token names. 
static char *yyNonTermNames[YY_N_NONTERMS];	#NonTerminal names.
static YYRHS yyRule[YY_N_RULES];		#Start of each rule in yySyms.
static YYSym yySyms[YY_N_RHS];			#Rule right-hand sides.
static YYSym yyAccess[YY_N_STATES]		#Access symbols for each state.

#endif

static YYTok yyTranslate[YY_MAX_TOK];		#Xlate ext. to internal tokens.

static YYLen yyLength[YY_N_RULES];		#Rule lengths.
static YYNonTerm yyLHS[YY_N_RULES];		#Rule LHS non-terminal numbers.

static YYBase yyActBase[YY_N_STATES];		#Base array for acts.
static YYRuleN yyActDef[YY_N_STATES];		#Default reduce rule.

static YYBase yyGotoBase[YY_N_NONTERMS];	#Base array for gotos.
static YYState yyGotoDef[YY_N_NONTERMS];	#Default state for gotos.

static YYAct yyNext[YY_N_NEXT];			#Action.
static YYCheck yyCheck[YY_N_CHECK];	 	#Action check array.



*/

#if YYDEBUG

static char *yyTokenNames[42]= {
  "error", "<EOF>", "'('", "')'", 
  "','", "':'", "';'", "'{'", 
  "'|'", "'}'", "EXPECT_TOK", "ID_TOK", 
  "ID_VAR_TOK", "IN_TOK", "LEFT_TOK", "LEX_ERR_TOK", 
  "LHS_VAR_TOK", "LIT_TOK", "MARK_TOK", "NOLOOK_TOK", 
  "NONASSOC_TOK", "NOWARN_TOK", "NUM_TOK", "NUM_VAR_TOK", 
  "OPTION_TOK", "OPTION_VAL_TOK", "OUT_TOK", "PREC_TOK", 
  "PURE_TOK", "RIGHT_TOK", "SHORT_TEXT_TOK", "START_TOK", 
  "TEST_TOK", "TEXT_TOK", "TOKEN_TOK", "TYPE_TOK", 
  "TYPE_ID_TOK", "UNION_TOK", "XID_TOK", "'='", 
  "$yyBadTok", "$yyEmptyTok"
};
static char *yyNonTermNames[45]= {
  "$S", "act", "altElements", "idOrLit", 
  "optTokVal", "attrDecs", "attrDecList", "spec", 
  "options", "defs", "rules", "optionVals", 
  "optSemi", "def", "startIDList", "type", 
  "nonTermList", "termDecDir", "termType", "termList", 
  "optNowarn", "nonTermDec", "termDec", "YY_23", 
  "attrDec", "attrType", "attrPrefix", "idVar", 
  "attrSuffix", "attrTextTok", "rule", "ruleLHS", 
  "alts", "altBody", "YY_34", "rhsElement", 
  "attrVals", "testExp", "attrExp", "YY_39", 
  "attrExpList", "attrExpTok", "numVar", "actVars", 
  "$Err"
};
static YYRHS yyRule[100]= {
      0,     3,     8,     9,    14,    16,    19,    23,    25,    26, 
     29,    33,    36,    40,    44,    49,    52,    55,    57,    60, 
     64,    67,    70,    73,    76,    78,    79,    82,    83,    85, 
     88,    92,    94,    96,    99,   103,   106,   109,   114,   119, 
    124,   125,   126,   128,   132,   137,   139,   142,   144,   147, 
    148,   151,   153,   157,   160,   164,   166,   170,   173,   174, 
    177,   178,   181,   184,   187,   189,   191,   196,   198,   203, 
    204,   205,   207,   211,   213,   216,   218,   220,   222,   224, 
    228,   229,   232,   235,   238,   240,   241,   243,   245,   246, 
    248,   250,   251,   253,   255,   257,   259,   261,   263,   265
};
static YYSym yySyms[266]= {
     29,     4,     2,    33,    37,    72,    41,     6,    10,    33, 
     96,    45,    49,    14,   100,    18,    45,   100,    22,    45, 
     16,   100,    26,     0,    30,    34,    37,    53,    38,   124, 
     57,    49,    42,   112,    49,    46,    40,    88,    49,    50, 
    140,    61,    65,    54,    69,    73,    77,    49,    58,   148, 
     49,    62,     0,    49,    66,    44,    70,    57,    44,    74, 
     57,    16,    44,    78,   136,    81,    82,    56,    81,    86, 
    116,    81,    90,    80,    81,    94,    84,    98,   102,    61, 
     21,   106,   110,    85,   114,    65,    85,   118,    65,    16, 
     85,   122,    44,   126,    89,   130,    77,    89,   134,    77, 
     16,    89,   138,    44,    17,   142,    68,    17,   146,    44, 
    156,    68,    17,   150,    68,   156,    44,    17,   154,     8, 
     93,    25,    12,   158,   162,   166,    97,   170,    25,    16, 
     97,   174,   101,   105,   109,   113,   178,     0,   182,   105, 
    117,   186,   117,   190,   113,   117,   194,   198,    41,   121, 
    202,   121,   206,   125,   129,    49,   210,     0,    49,   214, 
    152,    21,    20,   218,   133,   222,   129,    32,   133,   226, 
    137,     9,   230,   234,     9,   141,   238,   242,    44,   145, 
    246,    68,   145,   250,   108,    13,   254,    76,   258,     5, 
    262,   128,     8,   149,    12,   266,   153,   270,     8,   157, 
    161,    12,   274,   278,   282,   153,   286,   161,    16,   153, 
    290,   165,   294,   153,   165,   298,     0,   302,   109,   306, 
    169,   310,   117,   314,    28,   173,    36,   318,   322,   173, 
    109,   326,   173,    92,   330,   173,    64,   334,    88,   338, 
    342,   144,   346,    24,   350,   354,    52,   358,   104,   362, 
    366,   132,   370,   120,   374,    92,   378,    64,   382,    48, 
    386,    44,   390,    68,   394,   398
};
static YYSym yyAccess[144]= {
      1,    29,    33,     4,    96,    37,   100,     0,    45,    72, 
    124,   112,    40,   140,   148,     0,   136,    56,   116,    80, 
     53,    69,   100,    16,    24,    49,     0,   152,    41,   121, 
    125,    44,    57,    49,    88,   144,    61,    49,    49,    84, 
     81,    81,    81,    81,    73,    61,   100,    49,     8,    21, 
    121,   129,   133,   137,    44,    16,    49,    49,    44,    65, 
     85,    44,    68,    77,    89,    21,    93,    20,    32,    49, 
      9,    44,    16,    85,   156,    88,    17,   156,    17,    16, 
     49,    89,     0,    52,   104,    25,    97,   101,   133,    28, 
     44,    68,   108,    76,   128,   141,     5,    85,    68,    44, 
     89,    12,    16,   132,   120,   105,   117,   173,     8,   145, 
    145,    44,    68,    13,     8,    17,    17,    97,    48,   109, 
    117,    36,    92,    64,   109,   157,     0,    92,    64,   149, 
    153,   165,   109,   169,   117,   113,   161,   153,    12,   165, 
    117,    12,    16,   153
};
#endif /* #if YYDEBUG */

static YYTok yyTranslate[288]= {
      1,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
      2,     3,    40,    40,     4,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,     5,     6, 
     40,    39,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,     7,     8,     9,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,    40,    40,    40,    40, 
     40,    40,    40,    40,    40,    40,     0,    10,    11,    12, 
     13,    14,    15,    16,    17,    18,    19,    20,    21,    22, 
     23,    24,    25,    26,    27,    28,    29,    30,    31,    32, 
     33,    34,    35,    36,    37,    38,    40,    41
};
static YYLen yyLength[100]= {
      2,     4,     0,     4,     1,     2,     3,     1,     0,     2, 
      3,     2,     3,     3,     4,     2,     2,     1,     2,     3, 
      2,     2,     2,     2,     1,     0,     2,     0,     1,     2, 
      3,     1,     1,     2,     3,     2,     2,     4,     4,     4, 
      0,     0,     1,     3,     4,     1,     2,     1,     2,     0, 
      2,     1,     3,     2,     3,     1,     3,     2,     0,     2, 
      0,     2,     2,     2,     1,     1,     4,     1,     4,     0, 
      0,     1,     3,     1,     2,     1,     1,     1,     1,     3, 
      0,     2,     2,     2,     1,     0,     1,     1,     0,     1, 
      1,     0,     1,     1,     1,     1,     1,     1,     1,     0
};
static YYNonTerm yyLHS[100]= {
      0,     7,     8,     8,    11,    11,    11,    11,     9,     9, 
     13,    13,    13,    13,    13,    13,    13,    14,    14,    14, 
     17,    17,    17,    17,    20,    20,    18,    18,    16,    16, 
     16,    21,    19,    19,    19,    22,    22,    22,    22,     5, 
     23,     5,     6,     6,    24,    24,    26,    26,    28,    28, 
     10,    10,    30,    30,    31,    32,    32,    33,    34,     2, 
      2,    35,    35,    35,    35,    35,    35,    37,    36,    39, 
     36,    40,    40,    38,    38,    38,    41,    41,    41,     1, 
     43,    43,    43,    43,     4,     4,    15,    12,    12,    25, 
     25,    25,    29,    29,    42,    42,    27,     3,     3,    44
};
static YYBase yyActBase[144]= {
      1,    15,   316,     1,     5,   342,     1,     1,    90,     7, 
     22,   194,    26,    11,   194,   194,    95,    95,    95,    95, 
      1,     8,     1,    47,     1,     1,   194,   115,     2,     1, 
      1,     1,   129,     1,   194,     1,    62,     1,     1,     1, 
      1,     1,     1,     1,     4,   115,     1,     1,     1,     3, 
      1,   168,     1,     1,     1,    65,     1,     1,     1,   304, 
      1,     0,    32,    64,     1,     1,   348,     1,     1,     1, 
    247,     1,    66,     1,    63,     1,     1,    68,     1,     4, 
      1,     1,     1,     1,     1,     9,     1,    25,     1,     1, 
    233,   233,    40,     1,    81,     1,     1,     1,   272,   272, 
      1,     1,   348,     1,     1,    29,     1,   161,     1,     1, 
      1,     1,     1,     1,   122,     1,     1,     1,     1,     1, 
      1,     1,     1,     1,     1,   122,     1,     1,     1,     6, 
    377,     1,     1,     1,     1,    23,    20,   265,     1,     1, 
      1,     1,   122,   379
};
static YYRuleN yyActDef[144]= {
      2,    99,     8,     0,    99,    99,     4,     7,    88,    99, 
     99,    88,    99,    99,    88,    88,    25,    25,    25,    25, 
      9,    27,     5,    99,    87,     3,    88,    41,    99,    51, 
     58,    17,    88,    11,    88,    86,    99,    15,    16,    24, 
     20,    21,    22,    23,    99,    41,     6,    53,    40,    99, 
     50,    88,    55,    60,    18,    99,    10,    12,    31,    13, 
     28,    85,    85,    88,    32,    26,    99,    54,    58,    52, 
     57,    19,    99,    29,    99,    84,    35,    99,    36,    99, 
     14,    33,    45,    89,    90,    99,    42,    99,    56,    80, 
     70,    70,    99,    64,    99,    59,    65,    30,    85,    85, 
     34,    39,    99,    92,    93,    99,    47,    99,    69,    61, 
     62,    97,    98,    63,    99,    37,    38,    43,    96,    49, 
     46,    79,    82,    83,    81,    99,    75,    94,    95,    99, 
     67,    73,    76,    77,    78,    44,    99,    71,    66,    74, 
     48,    68,    99,    72
};
static YYBase yyGotoBase[45]= {
      1,     1,     1,     1,    89,    58,     1,     1,     1,     1, 
      1,     1,   390,     1,     1,    74,     1,     1,     1,     1, 
    163,    50,    93,     1,    31,     1,     1,    37,     1,    36, 
     80,     1,     1,    73,     1,     1,    17,     1,    34,     1, 
      1,    84,     1,     1,     1
};
static YYState yyGotoDef[45]= {
      0,    96,    70,   113,   116,    65,    85,     1,     2,     5, 
     28,     8,    80,    20,    32,    45,    59,    21,    44,    63, 
     43,    97,   100,    66,   117,    87,   105,   132,   135,   134, 
     50,    30,    51,    88,    53,    95,   110,   129,   143,   125, 
    136,   139,   133,   107,     0
};
static YYAct yyNext[442]= {
    229,     0,    26,   145,   229,     7,   229,    26,    67,   138, 
    229,   229,   101,   102,   229,    61,     3,   229,   229,   171, 
    229,    62,    75,   141,   142,   171,   188,   188,   229,   229, 
      6,   229,   229,    31,   229,   229,   229,   229,   229,    74, 
     27,   118,   229,   229,    35,    27,   229,    35,    34,   229, 
    229,   111,   229,   104,    75,   104,   103,   112,   103,   104, 
    229,   229,   103,   229,   232,   232,   229,   229,    79,   229, 
     24,    77,    46,    58,   232,    61,    71,    58,   232,    99, 
     98,    62,   232,   114,   232,    49,    60,    36,   232,    29, 
    232,   232,   232,   232,    23,   232,    24,    86,   232,   232, 
    232,   232,   232,    52,   232,     0,   169,   109,   232,    73, 
    232,     0,   169,     0,   232,    22,    39,    48,   232,   232, 
    185,   232,   126,   106,   232,   232,   185,   232,   232,   232, 
    232,   169,   185,    55,   118,    24,     0,    64,   128,   232, 
     54,   120,   119,   232,   124,   127,     0,   232,   130,   232, 
     76,    78,   104,   232,     0,   103,    81,   232,   232,   137, 
    232,     0,     0,   232,   232,     0,   232,   232,   232,   232, 
    121,   140,     0,   118,    24,     0,    68,   123,   232,    40, 
     41,    42,   232,     0,   122,     0,   232,   115,   232,     0, 
      0,     0,   232,     0,   232,   232,   232,   232,   131,   232, 
     24,     0,   232,   232,   232,   232,   232,     0,   232,   131, 
      0,     0,   232,     0,   232,     0,     0,     0,   232,     0, 
      0,     0,   232,   232,     0,   232,   131,     0,   232,   232, 
      0,   232,   232,   214,   214,   108,     0,     0,     0,   214, 
    214,   214,     0,     0,   214,     0,     0,   201,   201,     0, 
    214,     0,   214,   201,    89,   201,     0,     0,    90,     0, 
    214,     0,     0,     0,    91,   214,    93,     0,   215,   215, 
      0,   214,   229,     0,    92,     0,   229,   118,   229,    94, 
      0,   128,   229,   229,     0,   201,   229,     0,   127,   229, 
    229,     0,   229,     0,    75,   104,     0,     0,   103,     0, 
    229,   229,     0,   229,   157,     0,   229,   229,    72,   229, 
      0,     0,     0,     0,   157,    58,   152,     0,   157,     0, 
      0,     0,   157,     0,   157,     0,   152,     0,     0,     0, 
    152,     0,   157,   157,   152,   157,   152,     0,   157,   157, 
      4,   157,    15,     0,   152,   152,     0,   152,    82,     0, 
    152,   152,    12,   152,     0,     0,    17,     0,     0,     0, 
      9,    83,    19,     0,     0,     0,     0,     0,     0,     0, 
     11,    18,     0,    10,    84,     0,    16,    13,   235,    14, 
    211,   235,   216,   216,     0,     0,     0,     0,     0,   118, 
      0,   118,     0,   128,     0,   128,     0,     0,    25,     0, 
    127,    33,   127,     0,    37,    38,     0,   104,     0,   104, 
    103,     0,   103,     0,     0,     0,    47,     0,     0,     0, 
      0,     0,    56,     0,    57,     0,     0,     0,     0,     0, 
      0,     0,     0,     0,     0,     0,     0,     0,     0,     0, 
      0,    69
};
static YYCheck yyCheck[534]= {
      0,   144,     0,     1,     4,     0,     6,     0,     5,     3, 
     10,    11,     3,     4,    14,    11,     1,    17,    18,    11, 
     20,    17,    22,     3,     4,    17,     3,     4,    28,    29, 
     25,    31,     0,    11,    34,    35,     4,    37,     6,    39, 
     38,    12,    10,    11,    36,    38,    14,    36,    22,    17, 
     18,    11,    20,    30,    22,    30,    33,    17,    33,    30, 
     28,    29,    33,    31,     0,     1,    34,    35,     4,    37, 
      6,    39,    25,    11,    10,    11,    11,    11,    14,    11, 
     17,    17,    18,     2,    20,    27,    36,    13,    24,     9, 
      0,     1,    28,    29,     4,    31,     6,    66,    34,    35, 
     10,    37,    38,    30,    14,   144,    11,    90,    18,    59, 
     20,   144,    17,   144,    24,    25,    21,     2,    28,    29, 
      5,    31,     0,    87,    34,    35,    11,    37,    38,     0, 
      1,    36,    17,     4,    12,     6,   144,    44,    16,    10, 
     11,   105,   105,    14,   107,    23,   144,    18,   114,    20, 
     61,    62,    30,    24,   144,    33,    63,    28,    29,   125, 
     31,   144,   144,    34,    35,   144,    37,    38,     0,     1, 
      9,   135,   144,    12,     6,   144,     8,    16,    10,    16, 
     17,    18,    14,   144,    23,   144,    18,    98,    20,   144, 
    144,   144,    24,   144,     0,     1,    28,    29,   114,    31, 
      6,   144,    34,    35,    10,    37,    38,   144,    14,   125, 
    144,   144,    18,   144,    20,   144,   144,   144,    24,   144, 
    144,   144,    28,    29,   144,    31,   142,   144,    34,    35, 
    144,    37,    38,     0,     1,     2,   144,   144,   144,     6, 
      7,     8,   144,   144,    11,   144,   144,     0,     1,   144, 
     17,   144,    19,     6,     7,     8,   144,   144,    11,   144, 
     27,   144,   144,   144,    17,    32,    19,   144,     3,     4, 
    144,    38,     0,   144,    27,   144,     4,    12,     6,    32, 
    144,    16,    10,    11,   144,    38,    14,   144,    23,    17, 
     18,   144,    20,   144,    22,    30,   144,   144,    33,   144, 
     28,    29,   144,    31,     0,   144,    34,    35,     4,    37, 
    144,   144,   144,   144,    10,    11,     0,   144,    14,   144, 
    144,   144,    18,   144,    20,   144,    10,   144,   144,   144, 
     14,   144,    28,    29,    18,    31,    20,   144,    34,    35, 
     24,    37,     0,   144,    28,    29,   144,    31,     0,   144, 
     34,    35,    10,    37,   144,   144,    14,   144,   144,   144, 
     18,    13,    20,   144,   144,   144,   144,   144,   144,   144, 
     28,    29,   144,    31,    26,   144,    34,    35,    30,    37, 
      3,    33,     3,     4,   144,   144,   144,   144,   144,    12, 
    144,    12,   144,    16,   144,    16,   144,   144,     8,   144, 
     23,    11,    23,   144,    14,    15,   144,    30,   144,    30, 
     33,   144,    33,   144,   144,   144,    26,   144,   144,   144, 
    144,   144,    32,   144,    34,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,    51,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144,   144,   144,   144,   144,   144,   144, 
    144,   144,   144,   144
};
#line 754 "parse.c"

/*                PUBLIC MACROS NOT REDEFINABLE BY USER.                */

#define	YYACCEPT	do { yyRetVal= 0; goto yyTerminate; } while (0)
#define YYABORT		do { yyRetVal= 1; goto yyTerminate; } while (0)
#define YYEMPTY		YY_EMPTY_TOK
#define YYERROR		goto yyError
#define YYFAIL		goto yyFail
#define yyclearin	(YY_CHAR= YYEMPTY)
#define yyerrok		(yyErrShift= 0)
#define YYRECOVERING	(YY_CHAR == YY_ERR_TOK_VAL)
#define YY_ACCEPT_RULE	0

/*                        PRIVATE TYPES & MACROS                        */

/* Resynchronize after YY_CHAR is changed. */
#define YY_CHAR_SYNC							\
  do { yyTok= YY_TRANSLATE(YY_CHAR); } while (0)

/* Pseudo-error rule used to shift to error processing. */
#ifndef YY_ERR_RULE
#define YY_ERR_RULE (YY_N_RULES - 1)
#endif

/* Min. # of tokens shifted after an error before resignalling an error. */
#ifndef YY_ERR_SHIFT
#define YY_ERR_SHIFT 3
#endif

/* Max. size of stack before overflow. */
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Initial stack size.  Also used for stack increment. */
#ifndef YYINITDEPTH
#define YYINITDEPTH 200
#endif

#if (YY_HAS_LOC)
#ifndef YY_LOC
/* Default struct to maintain location information. */
#define YY_LOC 								\
  struct {								\
    int first_line;							\
    int last_line;							\
    int first_column;							\
    int last_column;							\
  }
#endif

typedef YY_LOC YYLoc;

#endif /* if (YY_HAS_LOC) */

typedef YYSTYPE YYSType;	/* Type for semantic values. */

typedef struct {		/* Stack type. */
  YYState state;		/* State stored in stack entry. */
  YYSType outVals;		/* Semantic value. */
#if (YY_HAS_IN_ATTRIBS)
  YYIn inVals;
#endif
#if (YY_HAS_LOC)
  YYLoc loc;			/* Location information. */
#endif
} YYStk;

#if YY_IS_TYPED
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals.type)
#else
#define YY_NUM_VAR(offset, type)	(yySP[offset].outVals)
#endif

#define YY_IN_VAR(offset, selector)	(yySP[offset].inVals.selector)
#define YY_OUT_VAR(offset, selector)	(yySP[offset].outVals.selector)
#if (YY_HAS_LOC)
#define YY_LOC_VAR(offset)		(yySP[offset].loc)
#endif

/*                      EXTERN SCANNER VARIABLES.                       */

#if (!YY_IS_PURE)
YYSTYPE YY_LVAL;		/* Semantic value of current token. */
int YY_CHAR= 0;			/* Current lookahead token (actual value). */
int YY_NERRS= 0;		/* Number of errors so far. */
#if (YY_HAS_LOC)
YYLoc yylloc;			/* Location information for current token. */
#endif
#if YYDEBUG
int YY_DEBUG= 0;		/* Flag to turn debug messages on/off. 	*/
#endif
#endif



/*                      CODE MACROS FOR YY_PARSE().                   */

/* Defines how yylex() is called. */
#ifndef YY_LEX_CALL
#if YY_IS_PURE
#if YY_HAS_LOC
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL, &yylloc)
#else
#define YY_LEX_CALL()	YY_LEX(&YY_LVAL)
#endif
#else
#define YY_LEX_CALL()	YY_LEX()
#endif
#endif /* ifndef YY_LEX_CALL */

/* Translate external tokens from yylex() to internal tokens. */
#define YY_TRANSLATE(t)							\
  (((0 <= t) && (t) <= YY_MAX_TOK_VAL) ? yyTranslate[t] : YY_BAD_TOK)

/* Macros to decode acts stored in yyActNext[] & yyActDef[] tables. */
#define YY_IS_SHIFT(act)	((act) < YY_N_STATES)
#define YY_IS_REDUCE(act)	((act) >= YY_N_STATES)
#define YY_ACT_RULEN(act)	((act) - YY_N_STATES)
#define YY_ACT_STATE(act)	(act)

#define YY_GOTO_STATE(s, n)						\
  do {									\
    unsigned i= yyGotoBase[n] + (s);					\
    s= (yyCheck[i] == (s)) ? yyNext[i] : yyGotoDef[n];			\
  } while (0)

#define YY_SHIFT_LHS  yyState= (yySP++)->state

/* Stack size check & growing. */
#define YY_STK_CHK(mainBase, mainSP, size, inc)				\
  do {									\
    if ((mainSP - mainBase) >= (size))					\
      if (!(size= yyGrowStk(&mainBase, &mainSP, size + inc))) YYABORT;	\
  } while (0)

#if (YY_HAS_LOC)

/* Location info for disp from stack top. */
#define YY_STK_LOC(disp)	(yySP[disp].loc)

/* Location info for element on rule RHS with index rhsIndex (0= 1st, etc)
 * given that rule has length ruleLen.  Valid only at reduction.
 */
#define YY_RHS_LOC(rhsIndex, ruleLen)					\
  YY_STK_LOC(rhsIndex - ruleLen - 1)

#ifndef YY_UPDATE_LOC

/* Default method of computing location information in locZ, after
 * reducing by a rule having rule length ruleLen.
 */
#define YY_UPDATE_LOC(ruleLen, locZ)					\
  do {									\
    if (ruleLen) {							\
      YY_CONST YYLoc *YY_CONST locFirstP= &YY_RHS_LOC(0, ruleLen);	\
      YY_CONST YYLoc *YY_CONST locLastP= 				\
	&YY_RHS_LOC(ruleLen - 1, ruleLen);				\
      (locZ).first_line= locFirstP->first_line;				\
      (locZ).first_column= locFirstP->first_column;			\
      (locZ).last_line= locLastP->last_line; 				\
      (locZ).last_column= locLastP->last_column;			\
    }									\
    else { /* Use location of previous element. */			\
      (locZ)= YY_STK_LOC(-1);						\
    }									\
  } while (0)

#endif /* #ifndef YY_UPDATE_LOC */
#endif /* #if YY_HAS_LOC */


/*                        STACK GROWING ROUTINE.                        */
#if YY_PROTO
static YYUInt yyGrowStk (YYStk **mainBase, YYStk **mainSP, YYUInt newSize)
#else
static YYUInt yyGrowStk (mainBase, mainSP, newSize)
  YYStk **mainBase;
  YYStk **mainSP;
  YYUInt newSize;
#endif /* #if YY_PROTO */
{ 
  if (newSize > YYMAXDEPTH) {
    YY_ERROR("stack overflow"); 
    return 0;
  }
  else {
    YYUInt disp= *mainSP - *mainBase;
    if (!(*mainBase= (YYStk *)realloc(*mainBase, newSize * sizeof(YYStk)))) {
      YY_ERROR("out of memory");
      return 0;
    }
    *mainSP= *mainBase + disp;
    return newSize;
  }
}


/*                         DEBUG HELPER ROUTINES.                       */

#if YYDEBUG



#if YY_PROTO
static YY_CONST char *yySymName (YYUInt sym) 
#else
static YY_CONST char *yySymName (sym) 
  YYUInt sym;
#endif /* #if YY_PROTO */
{
  return ((YY_SYM_TYPE(sym) == YY_NON_TERM_SYM) 
	  ? yyNonTermNames 
	  : yyTokenNames)
	  [YY_SYM_NUM(sym)];	
}

#if YY_PROTO
static YY_VOID yyPrintRule (YYUInt ruleN) 
#else
static YY_VOID yyPrintRule (ruleN) 
  YYUInt ruleN;
#endif /* #if YY_PROTO */
{
  unsigned i;
  fprintf(stderr, "%s: ", yyNonTermNames[yyLHS[ruleN]]);
  for (i= yyRule[ruleN]; YY_SYM_TYPE(yySyms[i]) != YY_RULE_SYM; i++) {
    fprintf(stderr, "%s ",  yySymName(yySyms[i]));
  }
}

#endif /* #if YYDEBUG */


/*			DECLARATION FOR YY_PARSE.			*/

/* Name of formal parameter used to pass start non-terminal. */
#ifndef YY_START
#define YY_START yyStart
#endif

#ifndef YY_DECL

/* Define K&R declaration for YY_PARSE. */
#if YY_HAS_MULTI_START

#ifdef YYPARSE_PARAM
#define YY_DECL \
  int YY_PARSE(YY_START, YYPARSE_PARAM) int YY_START; YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE(YY_START) int YY_START;
#endif /* else !defined YYPARSE_PARAM */

#else /* !YY_HAS_MULTI_START */

#ifdef YYPARSE_PARAM
#define YY_DECL int YY_PARSE(YYPARSE_PARAM) YY_VOIDP YYPARSE_PARAM;
#else /* !defined YYPARSE_PARAM */
#define YY_DECL int YY_PARSE()
#endif /* else !defined YYPARSE_PARAM */

#endif /* else !YY_HAS_MULTI_START */

#endif /* #ifndef YY_DECL */


/*			MAIN PARSER FUNCTION.				*/

YY_DECL
{
  enum { YY_STK_INC= YYINITDEPTH };
  /* malloc() initially, as some reallocs have problems with NULL 1st arg. */
  YYStk *yyStk= (YYStk *)malloc(YY_STK_INC * sizeof(YYStk)); /* Stack base. */	
  YYStk *yySP= yyStk;					/* Main stk. ptr. */
  YYUInt yyStkSize= YY_STK_INC;	/* Current size of main & location stks. */
#if YY_HAS_MULTI_START
  YYState yyState= YY_START;	/* Current parser state. */
#else
  YYState yyState= 0;		/* Current parser state. */
#endif
  YYTok yyTok= YYEMPTY;		/* Translated value of current lookahead. */
  int yyCharSave= 0;		/* Saved value of yyChar in error processing. */
  YY_CONST YYTok yyErrTok= 	/* Token error. */
    YY_TRANSLATE(YY_ERR_TOK_VAL);
  YYUChar yyErrShift= 0;	/* # of tokens to be shifted when error. */
  YYUChar yyRetVal;		/* Value to be returned by yyparse(). */
#if YY_IS_PURE
  YYSType YY_LVAL;		/* Lexical semantic value. */
  int YY_CHAR;			/* Current lookahead token (actual value). */
  int YY_NERRS= 0;		/* Number of errors. */
#if (YY_HAS_LOC)
  YYLoc yylloc;			/* Lexical location value. */
#endif
#endif
  /* Local definitions from user. */
#line 1050 "parse.c"
  /* Confirm initial stack allocation ok. */
  if (!yyStk) 
    YY_ERROR("Out of memory.");	/* Initial stk. allocation failed. */

  yySP->state= yyState; yySP++;		/* Push initial state. */

  while (1) {				/* Terminate only via return. */
    YYUInt yyRuleN;			/* Rule # used for reduction. */

    assert(yyState == yySP[-1].state);	/* yyState mirrors state on TOS. */

    /* yyTok & YY_CHAR must agree. */
    assert(yyTok == YYEMPTY || yyTok == YY_TRANSLATE(YY_CHAR)); 

#if YYDEBUG
    if (YY_DEBUG != 0) {
      YYStk *p;	/* Spew out stack. */
      fprintf(stderr, "[ ");
      for (p= (YY_DEBUG > 0 || yySP + YY_DEBUG < yyStk) 
              ? yyStk 
	      : yySP + YY_DEBUG;
	   p < yySP; p++) {
	YY_CONST YYUInt s= p->state;
	fprintf(stderr, "%d/%s ", s, yySymName(yyAccess[s]));
      }
      fprintf(stderr, "] ");
    }
#endif
    /* Ensure space for at least 1 more stack entry. */
    YY_STK_CHK(yyStk, yySP, yyStkSize, YY_STK_INC);
#if YY_HAS_IN_ATTRIBS
    switch (yyState) { /* Don't check for non-empty reduction. */
#line 1083 "parse.c"
    }	
#endif /* #if YY_HAS_IN_ATTRIBS */
    { /* Lookup action table & branch either to yyShift or yyReduce. */
      YY_CONST YYUInt base= yyActBase[yyState];
      if (base == YY_BAD_BASE) { 
	yyRuleN= yyActDef[yyState];		/* Use default entry */
	goto yyReduce;
      }
      else { /* Use lookahead to consult yyNext[] & yyCheck[]. */
	YYUInt index;
	if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	  YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
	}
	index= base + yyTok;
	if (yyCheck[index] == yyTok) {
	  YY_CONST YYUInt act= yyNext[index];
	  if (YY_IS_REDUCE(act)) {
            yyRuleN= YY_ACT_RULEN(act); goto yyReduce;
	  }
	  else {
	    yyState= YY_ACT_STATE(act); goto yyShift;
	  }
	}
	else {
	  yyRuleN= yyActDef[yyState]; goto yyReduce;
	}
      }
    }

  yyShift:	/* Begin shift action. */
#if YYDEBUG
    if (YY_DEBUG != 0) {
      fprintf(stderr, "%s: SHIFT %d\n", yyTokenNames[yyTok], yyState);
    }
#endif
    /* Push state on stack. */
    yySP->state= yyState; yySP->outVals= YY_LVAL; 
#if (YY_HAS_LOC)
    yySP->loc= yylloc;
#endif
    yySP++;

    if (yyErrShift) {	/* Error processing in shift action. */
      if (yyTok == yyErrTok) { 	/* We successfully shifted error. */
	assert(yyErrShift == YY_ERR_SHIFT); /* No normal tokens shifted. */
	YY_CHAR= yyCharSave; YY_CHAR_SYNC; /* Restore original lookahead. */
      }
      else {			/* Successful shift of normal token. */
	yyErrShift--;		/* 1 fewer token to shift before resignal. */
	yyTok= YYEMPTY;
      }
    }
    else {
      yyTok= YYEMPTY;	/* Clear shifted token. */
    }
    continue;	/* End shift action. Continue while(1) loop.  */

  yyReduce: 	/* Begin reduce action. */
#if YY_N_TESTS > 0
    if (yyRuleN >= YY_N_RULES) { /* Test action. */
      int yyResult= 0; 	/* Or of tests tested so far. */
      YYUInt yyT;	/* Indexes yyTests[] and yyTestActs[]. */	
      if (yyTok == YYEMPTY) { /* No lookahead --- read input. */
	YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
      }
      for (yyT= yyRuleN - YY_N_RULES; yyTests[yyT] > 0; yyT++) {
	switch (yyTests[yyT]) {
#line 1151 "parse.c"
	}
	if (yyResult) break;
      }
      { YY_CONST YYUInt act= yyTestActs[yyT];
        if (YY_IS_SHIFT(act)) {
	  yyState= YY_ACT_STATE(act); goto yyShift;
        }
        else {
	  yyRuleN= YY_ACT_RULEN(act);
	  assert(yyRuleN < YY_N_RULES);
        }
      }
    }
#endif /* if YY_N_TESTS > 0 */
    { YYUInt yyDefault= 0;	/* 1 if default action. */

#if YYDEBUG
      if (YY_DEBUG != 0) {
        fprintf(stderr, "%s: ", yyTokenNames[yyTok]);
        if (yyRuleN == YY_ERR_RULE || yyTok == yyErrTok) {
	  fprintf(stderr, "ERROR");
        }
        else if (yyRuleN == YY_ACCEPT_RULE) {
	  fprintf(stderr, "ACCEPT." );
        }
        else {
	  fprintf(stderr, "REDUCE %d ", yyRuleN);
	  yyPrintRule(yyRuleN); 
        }
        fprintf(stderr, "\n");
      }
#endif
      if (yyTok == yyErrTok) goto yyFail; /* error triggered a default redn. */
      switch (yyRuleN) {	/* Perform relevant user or default action. */
	/* Use yySP->outVals as temporary to store new semantic value. */
	case YY_ACCEPT_RULE:	/* Accepting rule. */
	  YYACCEPT; break;
	/* User actions go here. */
	case 4:
#line 144 "parse.y"
{ setOptions(YY_NUM_VAR(-1, text)); }
	break;
	case 5:
#line 145 "parse.y"
{ setOptions(YY_NUM_VAR(-1, text)); }
	break;
	case 6:
#line 146 "parse.y"
{ setOptions(YY_NUM_VAR(-1, text)); }
	break;
	case 11:
#line 155 "parse.y"
{ G.isPure= TRUE; }
	break;
	case 12:
#line 156 "parse.y"
{ setExpect(YY_NUM_VAR(-2, num)); }
	break;
	case 15:
#line 159 "parse.y"
{ dclTyped(); }
	break;
	case 17:
#line 164 "parse.y"
{ addStartNonTerm(YY_NUM_VAR(-1, id)); }
	break;
	case 18:
#line 166 "parse.y"
{ addStartNonTerm(YY_NUM_VAR(-1, id)); }
	break;
	case 19:
#line 168 "parse.y"
{ addStartNonTerm(YY_NUM_VAR(-1, id)); }
	break;
	case 20:
#line 172 "parse.y"
{ G.assocPrec= NIL;  }
	break;
	case 21:
#line 174 "parse.y"
{ G.assocPrec= MAKE_ASSOC_PREC(LEFT_ASSOC, G.precLevel++); }
	break;
	case 22:
#line 176 "parse.y"
{ G.assocPrec= MAKE_ASSOC_PREC(RIGHT_ASSOC, G.precLevel++); }
	break;
	case 23:
#line 178 "parse.y"
{ G.assocPrec= MAKE_ASSOC_PREC(NON_ASSOC, G.precLevel++); }
	break;
	case 24:
#line 182 "parse.y"
{ G.nowarn= TRUE; }
	break;
	case 25:
#line 184 "parse.y"
{ G.nowarn= FALSE; }
	break;
	case 26:
#line 188 "parse.y"
{ G.decCount= YY_NUM_VAR(-1, count); }
	break;
	case 27:
#line 190 "parse.y"
{ G.type= NIL; G.decCount= 0; }
	break;
	case 31:
#line 198 "parse.y"
{ dclNonTermAttribs(YY_NUM_VAR(-1, id), G.type); }
	break;
	case 35:
#line 207 "parse.y"
{ dclTermAttribs(YY_NUM_VAR(-2, id), NIL, NIL, YY_NUM_VAR(-1, num), G.assocPrec, 
		       G.type, G.decCount, G.nowarn); 
      }
	break;
	case 36:
#line 211 "parse.y"
{ dclTermAttribs(NIL, YY_NUM_VAR(-2, lit).id, YY_NUM_VAR(-2, lit).val, YY_NUM_VAR(-1, num), G.assocPrec, 
		       G.type, G.decCount, G.nowarn); 
      }
	break;
	case 37:
#line 215 "parse.y"
{ dclTermAttribs(YY_NUM_VAR(-4, id), YY_NUM_VAR(-2, lit).id, YY_NUM_VAR(-2, lit).val, YY_NUM_VAR(-1, num), G.assocPrec, 
		       G.type, G.decCount, G.nowarn); 
      }
	break;
	case 38:
#line 219 "parse.y"
{ dclTermAttribs(YY_NUM_VAR(-2, id), YY_NUM_VAR(-4, lit).id, YY_NUM_VAR(-4, lit).val, YY_NUM_VAR(-1, num), G.assocPrec, 
		       G.type, G.decCount, G.nowarn); 
      }
	break;
	case 40:
#line 224 "parse.y"
{ G.lineN= YY_NUM_VAR(-1, lineN); }
	break;
	case 39:
#line 225 "parse.y"
{ YY_NUM_VAR(0, count)= YY_NUM_VAR(-2, count); }
	break;
	case 41:
#line 227 "parse.y"
{ YY_NUM_VAR(0, count)= 0; }
	break;
	case 42:
#line 230 "parse.y"
{ addAttribSeq(G.lineN); YY_NUM_VAR(0, count)= 1; }
	break;
	case 43:
#line 231 "parse.y"
{ addAttribSeq(YY_NUM_VAR(-2, lineN)); YY_NUM_VAR(0, count)= YY_NUM_VAR(-3, count) + 1; }
	break;
	case 45:
#line 235 "parse.y"
{ setAttribParseError(); }
	break;
	case 54:
#line 256 "parse.y"
{ dclNonTermAttribs(YY_NUM_VAR(-3, id), NIL); }
	break;
	case 58:
#line 263 "parse.y"
{ beginRuleAttribs(); }
	break;
	case 57:
#line 265 "parse.y"
{ endRuleAttribs(YY_NUM_VAR(-1, count)); }
	break;
	case 59:
#line 269 "parse.y"
{ YY_NUM_VAR(0, count)= YY_NUM_VAR(-2, count) + 1; }
	break;
	case 60:
#line 271 "parse.y"
{ YY_NUM_VAR(0, count)= 0; }
	break;
	case 61:
#line 275 "parse.y"
{ addRHSAttribs(YY_NUM_VAR(-2, id), NIL); }
	break;
	case 62:
#line 277 "parse.y"
{ addRHSAttribs(YY_NUM_VAR(-2, lit).id, YY_NUM_VAR(-2, lit).val); }
	break;
	case 63:
#line 279 "parse.y"
{ setRulePrec(YY_NUM_VAR(-1, lit).id); }
	break;
	case 64:
#line 281 "parse.y"
{ setRuleNoLook(); }
	break;
	case 65:
#line 283 "parse.y"
{ addActAttribs(YY_NUM_VAR(-1, actN)); }
	break;
	case 66:
#line 285 "parse.y"
{ addTestAttribs(); }
	break;
	case 67:
#line 288 "parse.y"
{ addAttribSeq(G.lineN); }
	break;
	case 69:
#line 291 "parse.y"
{ G.lineN= YY_NUM_VAR(-1, lineN); }
	break;
	case 71:
#line 295 "parse.y"
{ addAttribSeq(G.lineN); }
	break;
	case 72:
#line 296 "parse.y"
{ addAttribSeq(YY_NUM_VAR(-2, lineN)); }
	break;
	case 75:
#line 301 "parse.y"
{ setAttribParseError(); }
	break;
	case 85:
#line 320 "parse.y"
{ YY_NUM_VAR(0, num)= NIL; }
	break;
	case 86:
#line 324 "parse.y"
{ G.type= YY_NUM_VAR(-1, type); }
	break;
	case 89:
#line 331 "parse.y"
{ addAttribTok(IN_ATOK, NULL);  }
	break;
	case 90:
#line 332 "parse.y"
{ addAttribTok(OUT_ATOK, NULL);  }
	break;
	case 91:
#line 333 "parse.y"
{ addAttribTok(OUT_ATOK, NULL); }
	break;
	case 92:
#line 336 "parse.y"
{ addAttribTok(TEXT_ATOK, (VOIDP)YY_NUM_VAR(-1, text)); }
	break;
	case 93:
#line 337 "parse.y"
{ addAttribTok(SHORT_TEXT_ATOK, (VOIDP)YY_NUM_VAR(-1, shortText)); }
	break;
	case 94:
#line 340 "parse.y"
{ addAttribTok(NUM_VAR_ATOK, (VOIDP)&YY_NUM_VAR(-1, numVar)); }
	break;
	case 95:
#line 341 "parse.y"
{ addAttribTok(NUM_VAR_ATOK, (VOIDP)&YY_NUM_VAR(-1, numVar)); }
	break;
	case 96:
#line 344 "parse.y"
{ addAttribTok(ID_VAR_ATOK, (VOIDP)&YY_NUM_VAR(-1, id)); }
	break;
	case 97:
#line 346 "parse.y"
{ YY_NUM_VAR(0, lit).id= YY_NUM_VAR(-1, id); YY_NUM_VAR(0, lit).val= NIL; }
	break;
#line 1418 "parse.c"
	case YY_ERR_RULE:	/* "Rule" used to break to a parse error. */
	  goto yyError;
	default:		/* Perform default action. */
	  yyDefault= 1;		/* Set flag to indicate no semantic copy. */
	  break;
      }
      {	YYLen yyLen= yyLength[yyRuleN];	/* Length of reducing rule. */
      	YYNonTerm yyN= yyLHS[yyRuleN];	/* LHS nonTerm #. */
      	YYStk *yyReduceP= yySP - yyLen;	/* Point to stack entry for rule LHS. */
#if YY_HAS_LOC
	YY_UPDATE_LOC(yyLen, yySP->loc); /* Use yySP->loc as temp. entry. */
#endif
        /* Update semantic value and location info. for LHS stk. location. */
        if (yyLen > 0) { /* Stack location for rule LHS not at yySP. */
#if YY_HAS_LOC
	  yyReduceP->loc= yySP->loc; 	/* Copy tmp. loc. entry to loc. stk. */
#endif
	  if (!yyDefault) {		/* Semantic copy definitely required. */
	    yyReduceP->outVals= yySP->outVals;	/* Do semantic copy. */
	  }
        } /* if (yyLen > 0) */
        /* Compute new state. */
        assert(yyStk < yyReduceP);
        yyState= yyReduceP[-1].state;	/* Set yyState to uncovered state. */
        YY_GOTO_STATE(yyState, yyN);	
        yyReduceP->state= yyState;
        yySP= yyReduceP + 1;		/* Pop stack. */
      } /* YYLen yyLen= yyLeng[yyRuleN]; */
    } /* Reduce action: YYUInt yyDefault= 0; */
    continue;	/* End reduce action. Continue with while(1) loop.  */
  yyError:
    if (!yyErrShift) { YY_ERROR("parse error"); YY_NERRS++; }
  yyFail:
    if (!yyErrShift) { 		/* Must have just gotten an error. */
      yyErrShift= YY_ERR_SHIFT;	/* # of tokens to shift before next error. */
      yyCharSave= YY_CHAR;
      YY_CHAR= YY_ERR_TOK_VAL; YY_CHAR_SYNC;
    }
    else if (yyTok == yyErrTok) { /* We need to pop current state. */
      yySP--; 
      if (yySP == yyStk) YYABORT;
      yyState= yySP[-1].state; 
    }
    else if (yyErrShift == YY_ERR_SHIFT) { /* No tokens shifted after error. */
      if (YY_CHAR == 0) YYABORT;	/* Quit at EOF. */
      YY_CHAR= YY_LEX_CALL(); YY_CHAR_SYNC;
    }
    else { /* We got a second error within YY_ERR_SHIFT tokens. */
      yyErrShift= 0; goto yyFail;
    }
    continue;	/* End error processing. */
  }  /* while (1) */
yyTerminate:
  free(yyStk);
  return yyRetVal;
}

/* 			SECTION 3 CODE					*/

#line 350 "parse.y"


int 
yyerror(s)
  char *s;
{
  error("%s at `%s'", s, yytext);  
  return 0;
}

Boolean 
hasLookahead()
{
  return yychar != YYEMPTY;
}

Count 
outParseParams(outFile)
  FILE *outFile;
{
  Count lineCount= 0;
  fprintf(outFile, "#define YY_IS_PURE %d\n", G.isPure); lineCount++;
  return lineCount;
}

#ifdef TEST_GRAM

VOID 
printAssocPrec(assocPrec1)
  Index assocPrec1;
{
  Index2 assocPrec= (Index2) assocPrec1;
  if (assocPrec != NIL) {
    printf(" ");
    switch (ASSOC(assocPrec)) {
      case NON_ASSOC:
        printf("NON_ASSOC");
	break;
      case LEFT_ASSOC:
        printf("LEFT");
	break;
      case RIGHT_ASSOC:
        printf("RIGHT");
	break;
      default:
	INTERNAL_ERROR();
    }
    printf(" %d", PREC(assocPrec));
  }
  VOID_RET();
}


#endif

#line 1533 "parse.c"
