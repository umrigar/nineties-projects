/*
 * DO NOT EDIT: This file was produced automatically by m4 from zyaccskl.cm4.
 */

#define OUT_FNS_INIT \
  outParams, \
  outToks, \
  outDefs, \
  outUnion, \
  outPrefixedNames, \
  outGramTabs, \
  outLocals, \
  outInAttribExps, \
  outTestCases, \
  outActCases, \
  outSec3, \

