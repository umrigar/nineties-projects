/*

File:	 zparse.h
Purpose: Parser interface.

Copyright (C) 1995 Zerksis D. Umrigar

See the file LICENSE for copying and distribution conditions.
THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.

*/

/*

File:	zParse.h
Backend interface to parser.

COPYRIGHT_M4

*/
#ifndef _PARSE_H
#define _PARSE_H

#include "port.h"

#include <stdio.h>

int yyparse PROTO((VOID_ARGS));
Boolean hasLookahead PROTO((VOID_ARGS));
Count outParseParams PROTO((FILE *outFile));

#ifdef TEST_GRAM

VOID printAssocPrec PROTO((Index assocPrec));

#endif

#endif /* ifndef _PARSE_H. */
