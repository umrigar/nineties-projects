/*
 * DO NOT EDIT: This file produced automatically by m4 from zlexSkl.cm4.
 */

#define OUT_FNS_INIT \
  outParams, \
  outDefs, \
  outPrefixedNames, \
  outSS, \
  outDFATabs, \
  outActionTabs, \
  outLocalDecs, \
  outDFACode, \
  outActCases, \
  outSec3, \

