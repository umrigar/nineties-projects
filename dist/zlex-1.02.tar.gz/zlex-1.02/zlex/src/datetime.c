/*

File:	 datetime.c
Purpose: Record compilation date and time.

Copyright (C) 1995 Zerksis D. Umrigar

See the file LICENSE for copying and distribution conditions.
THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.

*/

#include "datetime.h"

DateTime dateTime= { __DATE__, __TIME__ };

